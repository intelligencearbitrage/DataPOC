#!/usr/bin/env python3
"""
convert_transformations.py

Reads agent-output/parsed/parsed_mapping.json (or all files listed in
agent-output/parsed/index.json) and converts each Informatica transformation
to SQL-ready CTE definitions, writing a structured conversion plan to
agent-output/converted/{mapping_name}_plan.json.

The output is a structured plan dict — NOT SQL strings. SQL rendering is
handled downstream by generate_dbt_models.py.

Usage:
    python convert_transformations.py
"""

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
PARSED_DIR = PROJECT_ROOT / "agent-output" / "parsed"
CONVERTED_DIR = PROJECT_ROOT / "agent-output" / "converted"


# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------

def to_snake_case(name: str) -> str:
    """Convert any string to snake_case lowercase."""
    name = name.strip()
    # Replace spaces, hyphens, dots with underscores
    name = re.sub(r"[\s\-\.]+", "_", name)
    # Insert underscore between CamelCase boundaries
    name = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)
    return name.lower()


def normalize_prefix(name: str, prefix: str) -> str:
    """
    Ensure name has exactly one copy of the given prefix.
    E.g. normalize_prefix('SQ_orders', 'sq_') -> 'sq_orders'
         normalize_prefix('orders', 'sq_')    -> 'sq_orders'
    """
    snake = to_snake_case(name)
    low_prefix = prefix.lower()
    if snake.startswith(low_prefix):
        return snake
    return low_prefix + snake


def translate_isnull(expr: str) -> str:
    """Translate Informatica ISNULL / NOT ISNULL to SQL IS NULL / IS NOT NULL."""
    if not expr:
        return expr
    # NOT ISNULL(col) = FALSE  ->  col IS NULL
    expr = re.sub(
        r"NOT\s+ISNULL\s*\(\s*([^)]+)\s*\)\s*=\s*FALSE",
        r"\1 IS NULL",
        expr,
        flags=re.IGNORECASE,
    )
    # NOT ISNULL(col)  ->  col IS NOT NULL
    expr = re.sub(
        r"NOT\s+ISNULL\s*\(\s*([^)]+)\s*\)",
        r"\1 IS NOT NULL",
        expr,
        flags=re.IGNORECASE,
    )
    # Enhancement: handle ISNULL(col) = FALSE/TRUE BEFORE the catch-all ISNULL pattern
    # ISNULL(col) = FALSE  ->  col IS NOT NULL
    expr = re.sub(
        r"ISNULL\s*\(\s*([^)]+)\s*\)\s*=\s*FALSE",
        r"\1 IS NOT NULL",
        expr,
        flags=re.IGNORECASE,
    )
    # ISNULL(col) = TRUE  ->  col IS NULL
    expr = re.sub(
        r"ISNULL\s*\(\s*([^)]+)\s*\)\s*=\s*TRUE",
        r"\1 IS NULL",
        expr,
        flags=re.IGNORECASE,
    )
    # ISNULL(col)  ->  col IS NULL
    expr = re.sub(
        r"ISNULL\s*\(\s*([^)]+)\s*\)",
        r"\1 IS NULL",
        expr,
        flags=re.IGNORECASE,
    )
    return expr


def normalize_join_condition(
    condition: str,
    table_to_cte: Dict[str, str],
) -> str:
    """Replace bare source table name prefixes in join conditions with CTE names.

    For example: "orders.customer_id = customers.customer_id"
    with table_to_cte = {"orders": "sq_orders", "customers": "sq_customers"}
    becomes: "sq_orders.customer_id = sq_customers.customer_id"
    """
    if not condition:
        return condition
    result = condition
    # Sort by length descending to replace longest matches first (avoid partial replacement)
    for table_name, cte_name in sorted(table_to_cte.items(), key=lambda x: -len(x[0])):
        # Replace "table_name." with "cte_name." (word-boundary-safe)
        result = re.sub(
            r"\b" + re.escape(table_name) + r"\.",
            cte_name + ".",
            result,
        )
    return result


def translate_expression(expr: str) -> str:
    """
    Apply standard Informatica -> Snowflake SQL expression translations.
    Handles IIF, ISNULL, DECODE, TRUNC (numeric), FIRST, LAST, CONCAT, SUBSTR.
    Returns the translated expression string.
    """
    if not expr:
        return expr

    result = translate_isnull(expr)

    # IIF(cond, val1, val2) -> IFF(cond, val1, val2)
    # (Snowflake supports both IFF and CASE WHEN; use IFF for simple binary)
    result = re.sub(
        r"\bIIF\s*\(",
        "IFF(",
        result,
        flags=re.IGNORECASE,
    )

    # FIRST(col) -> MIN(col)  with approximation comment
    result = re.sub(
        r"\bFIRST\s*\(\s*([^)]+)\s*\)",
        r"MIN(\1) -- APPROXIMATION: Informatica FIRST/LAST has no exact Snowflake equivalent",
        result,
        flags=re.IGNORECASE,
    )

    # LAST(col) -> MAX(col) with approximation comment
    result = re.sub(
        r"\bLAST\s*\(\s*([^)]+)\s*\)",
        r"MAX(\1) -- APPROXIMATION: Informatica FIRST/LAST has no exact Snowflake equivalent",
        result,
        flags=re.IGNORECASE,
    )

    # TRUNC(col, n) — numeric context -> TRUNCATE(col, n)
    # (We apply this globally; generate_dbt_models.py can refine by datatype)
    result = re.sub(
        r"\bTRUNC\s*\(",
        "TRUNCATE(",
        result,
        flags=re.IGNORECASE,
    )

    return result


# ---------------------------------------------------------------------------
# Source vs ref() resolution
# ---------------------------------------------------------------------------

def resolve_table_ref(table_name: str, source_name_set: Set[str]) -> str:
    """
    Return the Jinja call for a table reference.
    If the table name (snake_case) is in the source_name_set, use source().
    Otherwise use ref().
    """
    sn = to_snake_case(table_name)
    if sn in source_name_set:
        return f"{{{{ source('raw', '{sn}') }}}}"
    return f"{{{{ ref('{sn}') }}}}"


# ---------------------------------------------------------------------------
# Connector graph helpers
# ---------------------------------------------------------------------------

def build_connector_map(parsed: Dict[str, Any]) -> Dict[str, List[str]]:
    """
    Build a dict: transformation_name -> list of upstream transformation names.
    Reads parsed['connectors'] array, each entry has from_instance / to_instance.
    Only includes edges where both endpoints are transformations (not sources/targets).
    """
    connectors = parsed.get("connectors", [])
    sources_set: Set[str] = {s["name"] for s in parsed.get("sources", [])}
    targets_set: Set[str] = {t["name"] for t in parsed.get("targets", [])}

    upstream_map: Dict[str, List[str]] = {}
    for conn in connectors:
        frm = conn.get("from_instance", "")
        to = conn.get("to_instance", "")
        if not frm or not to:
            continue
        if frm in sources_set or frm in targets_set:
            continue
        if to in sources_set or to in targets_set:
            continue
        if to not in upstream_map:
            upstream_map[to] = []
        if frm not in upstream_map[to]:
            upstream_map[to].append(frm)

    return upstream_map


def get_upstream_ctes(
    trans_name: str,
    connector_map: Dict[str, List[str]],
    cte_name_map: Dict[str, str],
) -> List[str]:
    """
    Return the list of CTE names that feed into trans_name.
    cte_name_map maps original transformation name -> CTE name.
    """
    upstreams = connector_map.get(trans_name, [])
    result = []
    for up in upstreams:
        if up in cte_name_map:
            result.append(cte_name_map[up])
    return result


def get_first_upstream_cte(
    trans_name: str,
    connector_map: Dict[str, List[str]],
    cte_name_map: Dict[str, str],
) -> Optional[str]:
    """Return the first (and usually only) upstream CTE name, or None."""
    ctes = get_upstream_ctes(trans_name, connector_map, cte_name_map)
    return ctes[0] if ctes else None


# ---------------------------------------------------------------------------
# Source table lookup for SQ
# ---------------------------------------------------------------------------

def find_source_table_for_sq(
    sq_name: str,
    parsed: Dict[str, Any],
    source_name_set: Set[str],
) -> Optional[str]:
    """
    Determine which SOURCE table feeds this SQ transformation.
    Searches connectors for: from_instance in source_name_set AND to_instance == sq_name.
    Falls back to stripping sq_ prefix and checking source_name_set.
    """
    connectors = parsed.get("connectors", [])
    for conn in connectors:
        frm = conn.get("from_instance", "")
        to = conn.get("to_instance", "")
        frm_snake = to_snake_case(frm)
        if to == sq_name and frm_snake in source_name_set:
            return frm_snake
        # Also check by original name
        if to == sq_name and frm in source_name_set:
            return to_snake_case(frm)

    # Fallback: strip sq_ prefix and check
    for prefix in ("sq_", "SQ_"):
        if sq_name.startswith(prefix):
            candidate = to_snake_case(sq_name[len(prefix):])
            if candidate in source_name_set:
                return candidate
            break

    # Last fallback: first source
    if source_name_set:
        first = next(iter(source_name_set))
        print(
            f"WARNING: Could not find source table for SQ '{sq_name}'. "
            f"Defaulting to '{first}'.",
            file=sys.stderr,
        )
        return first

    return None


# ---------------------------------------------------------------------------
# EXPRESSION port resolution helpers
# ---------------------------------------------------------------------------

def _topo_sort_output_ports(
    output_ports: List[Dict[str, Any]],
    variable_port_names: Set[str],
) -> List[Dict[str, Any]]:
    """
    Topologically sort OUTPUT ports so that if port B's expression references
    port A's name, port A comes before port B in the sorted list.
    Falls back to original order if a cycle is detected.
    """
    port_names = {p["name"] for p in output_ports}
    # Build adjacency: port -> list of ports it depends on (among output ports)
    deps: Dict[str, Set[str]] = {}
    for port in output_ports:
        expr = port.get("expression", "") or ""
        deps[port["name"]] = set()
        for other in output_ports:
            if other["name"] == port["name"]:
                continue
            # Simple word-boundary check for reference
            if re.search(r"\b" + re.escape(other["name"]) + r"\b", expr):
                deps[port["name"]].add(other["name"])

    # Kahn's algorithm
    in_degree: Dict[str, int] = {p["name"]: 0 for p in output_ports}
    for pname, dep_set in deps.items():
        for dep in dep_set:
            in_degree[pname] = in_degree.get(pname, 0) + 1

    queue = [p for p in output_ports if in_degree[p["name"]] == 0]
    sorted_ports: List[Dict[str, Any]] = []
    port_map = {p["name"]: p for p in output_ports}
    visited: Set[str] = set()

    while queue:
        cur = queue.pop(0)
        sorted_ports.append(cur)
        visited.add(cur["name"])
        for other in output_ports:
            if other["name"] in visited:
                continue
            if cur["name"] in deps[other["name"]]:
                deps[other["name"]].remove(cur["name"])
                in_degree[other["name"]] -= 1
                if in_degree[other["name"]] == 0:
                    queue.append(port_map[other["name"]])

    if len(sorted_ports) != len(output_ports):
        # Cycle detected — fall back to original order
        print(
            "WARNING: Cycle detected in EXP OUTPUT port references. "
            "Using original port order.",
            file=sys.stderr,
        )
        return output_ports

    return sorted_ports


def _inline_variable_refs(
    expr: str,
    variable_port_map: Dict[str, str],
) -> str:
    """Replace references to VARIABLE ports with their expressions."""
    for var_name, var_expr in variable_port_map.items():
        pattern = r"\b" + re.escape(var_name) + r"\b"
        if re.search(pattern, expr):
            expr = re.sub(pattern, f"({var_expr})", expr)
    return expr


def _inline_output_refs(
    expr: str,
    resolved_output_map: Dict[str, str],
    current_port_name: str,
) -> str:
    """Replace references to already-resolved OUTPUT ports with their expressions."""
    for out_name, out_expr in resolved_output_map.items():
        if out_name == current_port_name:
            continue
        pattern = r"\b" + re.escape(out_name) + r"\b"
        if re.search(pattern, expr):
            expr = re.sub(pattern, f"({out_expr})", expr)
    return expr


# ---------------------------------------------------------------------------
# Transformation handlers
# ---------------------------------------------------------------------------

def handle_sq(
    trans: Dict[str, Any],
    parsed: Dict[str, Any],
    source_name_set: Set[str],
    connector_map: Dict[str, List[str]],
    cte_name_map: Dict[str, str],
    source_refs: List[Dict[str, str]],
) -> Tuple[str, Dict[str, Any]]:
    """
    SOURCE_QUALIFIER -> sq_{name} CTE.
    Returns (cte_name, cte_definition).
    """
    trans_name: str = trans["name"]
    cte_name = normalize_prefix(trans_name, "sq_")
    attrs: Dict[str, str] = trans.get("attributes", {})

    # Locate the source table
    source_table = find_source_table_for_sq(trans_name, parsed, source_name_set)
    source_table = source_table or to_snake_case(trans_name.replace("sq_", "", 1))

    dbt_source_call = f"{{{{ source('raw', '{source_table}') }}}}"

    # Register source ref (avoid duplicates)
    existing_refs = {sr["table_name"] for sr in source_refs}
    if source_table not in existing_refs:
        source_refs.append(
            {
                "source_name": "raw",
                "table_name": source_table,
                "dbt_source_call": dbt_source_call,
            }
        )

    # Check for verbatim SQL query
    sql_query = attrs.get("Sql Query", "").strip()
    verbatim_sql = bool(sql_query)

    if verbatim_sql:
        select_columns = [
            {
                "name": "sql_query_passthrough",
                "expression": sql_query,
                "alias": "",
                "is_passthrough": False,
                "original_expression": sql_query,
            }
        ]
    else:
        # Build SELECT from OUTPUT ports
        output_ports = [
            f for f in trans.get("fields", [])
            if f.get("port_type", "").upper() == "OUTPUT"
        ]
        select_columns = [
            {
                "name": to_snake_case(f["name"]),
                "expression": "",
                "alias": "",
                "is_passthrough": True,
                "original_expression": "",
            }
            for f in output_ports
        ]

    # Optional WHERE filter (only when not using verbatim SQL)
    filter_val = attrs.get("Filter", "").strip()
    where_clause: Optional[str] = None
    if filter_val and not verbatim_sql:
        where_clause = translate_isnull(filter_val)

    cte_def: Dict[str, Any] = {
        "transformation_type": "source_qualifier",
        "verbatim_sql": verbatim_sql,
        "upstream_ctes": [],  # SQ reads from source(), not another CTE
        "source_table": source_table,
        "dbt_source_call": dbt_source_call,
        "select_columns": select_columns,
        "where_clause": where_clause,
        "group_by_cols": [],
        "join_type": None,
        "join_on": None,
        "master_cte": None,
        "detail_cte": None,
        "lookup_table_ref": None,
        "lookup_on": None,
        "router_strategy": None,
        "route_groups": [],
    }
    return cte_name, cte_def


def handle_exp(
    trans: Dict[str, Any],
    parsed: Dict[str, Any],
    source_name_set: Set[str],
    connector_map: Dict[str, List[str]],
    cte_name_map: Dict[str, str],
    source_refs: List[Dict[str, str]],
) -> Tuple[str, Dict[str, Any]]:
    """
    EXPRESSION -> exp_{name} CTE.
    Inlines VARIABLE port references and OUTPUT-to-OUTPUT references.
    Returns (cte_name, cte_definition).
    """
    trans_name: str = trans["name"]
    cte_name = normalize_prefix(trans_name, "exp_")
    fields: List[Dict[str, Any]] = trans.get("fields", [])

    # Separate port types
    variable_ports = [f for f in fields if f.get("port_type", "").upper() == "VARIABLE"]
    output_ports = [f for f in fields if f.get("port_type", "").upper() == "OUTPUT"]
    input_ports = [f for f in fields if f.get("port_type", "").upper() == "INPUT"]

    # Build variable_port_map: name -> translated expression
    variable_port_map: Dict[str, str] = {}
    for vp in variable_ports:
        raw_expr = vp.get("expression", "") or ""
        translated = translate_expression(raw_expr)
        variable_port_map[vp["name"]] = translated

    variable_port_names = set(variable_port_map.keys())

    # Sort output ports topologically
    sorted_output_ports = _topo_sort_output_ports(output_ports, variable_port_names)

    # Resolve OUTPUT ports in topological order
    resolved_output_map: Dict[str, str] = {}
    select_columns = []

    for op in sorted_output_ports:
        raw_expr = op.get("expression", "") or ""
        original_expression = raw_expr
        translated = translate_expression(raw_expr)
        # Inline VARIABLE port references
        translated = _inline_variable_refs(translated, variable_port_map)
        # Inline previously-resolved OUTPUT port references
        translated = _inline_output_refs(translated, resolved_output_map, op["name"])
        resolved_output_map[op["name"]] = translated

        col_name = to_snake_case(op["name"])
        is_passthrough = (translated == "" or translated == col_name or translated == op["name"])
        select_columns.append(
            {
                "name": col_name,
                "expression": translated,
                "alias": "",
                "is_passthrough": is_passthrough,
                "original_expression": original_expression,
            }
        )

    # Enhancement: do NOT add INPUT ports as passthrough columns.
    # INPUT ports are upstream references, not output columns. Adding them caused
    # duplicate select_columns when input and output ports share names (FAIL-1).
    # Pass-through is already captured when an OUTPUT port expression == port name.

    upstream_ctes = get_upstream_ctes(trans_name, connector_map, cte_name_map)

    cte_def: Dict[str, Any] = {
        "transformation_type": "expression",
        "verbatim_sql": False,
        "upstream_ctes": upstream_ctes,
        "select_columns": select_columns,
        "where_clause": None,
        "group_by_cols": [],
        "join_type": None,
        "join_on": None,
        "master_cte": None,
        "detail_cte": None,
        "lookup_table_ref": None,
        "lookup_on": None,
        "router_strategy": None,
        "route_groups": [],
    }
    return cte_name, cte_def


def handle_agg(
    trans: Dict[str, Any],
    parsed: Dict[str, Any],
    source_name_set: Set[str],
    connector_map: Dict[str, List[str]],
    cte_name_map: Dict[str, str],
    source_refs: List[Dict[str, str]],
) -> Tuple[str, Dict[str, Any]]:
    """
    AGGREGATOR -> agg_{name} CTE.
    Returns (cte_name, cte_definition).
    """
    trans_name: str = trans["name"]
    cte_name = normalize_prefix(trans_name, "agg_")
    fields: List[Dict[str, Any]] = trans.get("fields", [])

    group_by_cols: List[str] = []
    select_columns: List[Dict[str, Any]] = []
    # Enhancement: deduplicate using seen sets — INPUT+OUTPUT ports both carry
    # group_by=true for the same columns, causing duplicates without this guard (FAIL-2).
    seen_gb: set = set()
    seen_agg: set = set()

    for field in fields:
        port_type = field.get("port_type", "").upper()
        # Skip input ports entirely — only process OUTPUT ports
        if port_type not in ("OUTPUT", "O"):
            continue
        group_by = field.get("group_by", False)
        col_name = to_snake_case(field["name"])

        if group_by:
            if col_name not in seen_gb:
                seen_gb.add(col_name)
                group_by_cols.append(col_name)
                select_columns.append(
                    {
                        "name": col_name,
                        "expression": "",
                        "alias": "",
                        "is_passthrough": True,
                        "original_expression": "",
                    }
                )
        else:
            if col_name not in seen_agg:
                seen_agg.add(col_name)
                raw_expr = field.get("expression", "") or ""
                original_expression = raw_expr
                translated = translate_expression(raw_expr)
                select_columns.append(
                    {
                        "name": col_name,
                        "expression": translated,
                        "alias": "",
                        "is_passthrough": False,
                        "original_expression": original_expression,
                    }
                )

    upstream_ctes = get_upstream_ctes(trans_name, connector_map, cte_name_map)

    cte_def: Dict[str, Any] = {
        "transformation_type": "aggregator",
        "verbatim_sql": False,
        "upstream_ctes": upstream_ctes,
        "select_columns": select_columns,
        "where_clause": None,
        "group_by_cols": group_by_cols,
        "join_type": None,
        "join_on": None,
        "master_cte": None,
        "detail_cte": None,
        "lookup_table_ref": None,
        "lookup_on": None,
        "router_strategy": None,
        "route_groups": [],
    }
    return cte_name, cte_def


def handle_lkp(
    trans: Dict[str, Any],
    parsed: Dict[str, Any],
    source_name_set: Set[str],
    connector_map: Dict[str, List[str]],
    cte_name_map: Dict[str, str],
    source_refs: List[Dict[str, str]],
) -> Tuple[str, Dict[str, Any]]:
    """
    LOOKUP -> lkp_{name} CTE — ALWAYS LEFT JOIN.
    Returns (cte_name, cte_definition).
    """
    trans_name: str = trans["name"]
    cte_name = normalize_prefix(trans_name, "lkp_")
    attrs: Dict[str, str] = trans.get("attributes", {})
    fields: List[Dict[str, Any]] = trans.get("fields", [])

    # Lookup table reference
    lookup_table_raw = attrs.get("Lookup table name", "").strip()
    lookup_table_sn = to_snake_case(lookup_table_raw) if lookup_table_raw else ""

    if lookup_table_sn:
        lookup_table_ref = resolve_table_ref(lookup_table_sn, source_name_set)
    else:
        # Fallback: derive from transformation name
        lookup_table_sn = to_snake_case(trans_name.replace("lkp_", "", 1))
        lookup_table_ref = resolve_table_ref(lookup_table_sn, source_name_set)

    # Lookup condition (ON clause)
    lookup_condition = attrs.get("Lookup condition", "").strip()
    lookup_on: Optional[str] = translate_isnull(lookup_condition) if lookup_condition else None

    # Normalize lookup condition: replace bare source/lookup table names with CTE names
    # e.g. "dim_customer.customer_id = customer_id"
    #   -> "lkp.customer_id = base.customer_id"  (handled in generate_dbt_models rendering)
    # For now normalize any sq_ source references:
    table_to_cte_lkp: Dict[str, str] = {
        src["name"]: f"sq_{src['name']}"
        for src in parsed.get("sources", [])
    }
    # Also map the lookup table itself to the lkp alias used in the SQL template
    if lookup_table_sn:
        table_to_cte_lkp[lookup_table_sn] = "lkp"
        table_to_cte_lkp[lookup_table_raw] = "lkp"
    if lookup_on:
        lookup_on = normalize_join_condition(lookup_on, table_to_cte_lkp)

    # Output columns: all OUTPUT ports
    output_ports = [f for f in fields if f.get("port_type", "").upper() == "OUTPUT"]
    select_columns = [
        {
            "name": to_snake_case(f["name"]),
            "expression": "",
            "alias": "",
            "is_passthrough": True,
            "original_expression": "",
        }
        for f in output_ports
    ]

    upstream_ctes = get_upstream_ctes(trans_name, connector_map, cte_name_map)
    upstream_ref = upstream_ctes[0] if upstream_ctes else None

    cte_def: Dict[str, Any] = {
        "transformation_type": "lookup",
        "verbatim_sql": False,
        "upstream_ctes": upstream_ctes,
        "upstream_ref": upstream_ref,
        "lookup_table_ref": lookup_table_ref,
        "lookup_table_name": lookup_table_sn,
        "lookup_on": lookup_on,
        "join_type": "LEFT JOIN",  # ALWAYS LEFT JOIN for LKP
        "join_on": lookup_on,
        "select_columns": select_columns,
        "where_clause": None,
        "group_by_cols": [],
        "master_cte": None,
        "detail_cte": None,
        "router_strategy": None,
        "route_groups": [],
    }
    return cte_name, cte_def


def handle_fil(
    trans: Dict[str, Any],
    parsed: Dict[str, Any],
    source_name_set: Set[str],
    connector_map: Dict[str, List[str]],
    cte_name_map: Dict[str, str],
    source_refs: List[Dict[str, str]],
) -> Tuple[str, Dict[str, Any]]:
    """
    FILTER -> fil_{name} CTE.
    Returns (cte_name, cte_definition).
    """
    trans_name: str = trans["name"]
    cte_name = normalize_prefix(trans_name, "fil_")
    attrs: Dict[str, str] = trans.get("attributes", {})
    fields: List[Dict[str, Any]] = trans.get("fields", [])

    # WHERE condition from Filter Condition attribute
    filter_condition = attrs.get("Filter Condition", "").strip()
    where_clause: Optional[str] = translate_isnull(filter_condition) if filter_condition else None

    # All INPUT ports pass through unchanged
    input_ports = [f for f in fields if f.get("port_type", "").upper() == "INPUT"]
    select_columns = [
        {
            "name": to_snake_case(f["name"]),
            "expression": "",
            "alias": "",
            "is_passthrough": True,
            "original_expression": "",
        }
        for f in input_ports
    ]

    upstream_ctes = get_upstream_ctes(trans_name, connector_map, cte_name_map)

    cte_def: Dict[str, Any] = {
        "transformation_type": "filter",
        "verbatim_sql": False,
        "upstream_ctes": upstream_ctes,
        "select_columns": select_columns,
        "where_clause": where_clause,
        "group_by_cols": [],
        "join_type": None,
        "join_on": None,
        "master_cte": None,
        "detail_cte": None,
        "lookup_table_ref": None,
        "lookup_on": None,
        "router_strategy": None,
        "route_groups": [],
    }
    return cte_name, cte_def


def handle_jnr(
    trans: Dict[str, Any],
    parsed: Dict[str, Any],
    source_name_set: Set[str],
    connector_map: Dict[str, List[str]],
    cte_name_map: Dict[str, str],
    source_refs: List[Dict[str, str]],
) -> Tuple[str, Dict[str, Any]]:
    """
    JOINER -> jnr_{name} CTE.
    Determines MASTER/DETAIL CTEs from INPUTTYPE on TRANSFORMFIELD (field.input_type).
    Returns (cte_name, cte_definition).
    """
    trans_name: str = trans["name"]
    cte_name = normalize_prefix(trans_name, "jnr_")
    attrs: Dict[str, str] = trans.get("attributes", {})
    fields: List[Dict[str, Any]] = trans.get("fields", [])
    connectors = parsed.get("connectors", [])

    # Build a map: field_name -> input_type for this JNR transformation
    field_input_type: Dict[str, str] = {}
    for f in fields:
        it = f.get("input_type", "").upper()
        if it in ("MASTER", "DETAIL"):
            field_input_type[f["name"]] = it

    # Find master_cte and detail_cte by looking up connectors:
    # For each CONNECTOR where to_instance == trans_name,
    # look up to_field in field_input_type to determine if it's master or detail.
    master_cte: Optional[str] = None
    detail_cte: Optional[str] = None

    for conn in connectors:
        if conn.get("to_instance") != trans_name:
            continue
        frm = conn.get("from_instance", "")
        to_field = conn.get("to_field", "")
        input_type = field_input_type.get(to_field, "").upper()
        frm_cte = cte_name_map.get(frm)
        if frm_cte is None:
            continue
        if input_type == "MASTER" and master_cte is None:
            master_cte = frm_cte
        elif input_type == "DETAIL" and detail_cte is None:
            detail_cte = frm_cte

    # Fallback: if we couldn't determine from field input_type, use connector order
    if master_cte is None or detail_cte is None:
        all_upstreams = get_upstream_ctes(trans_name, connector_map, cte_name_map)
        if len(all_upstreams) >= 2:
            if master_cte is None:
                master_cte = all_upstreams[0]
            if detail_cte is None:
                detail_cte = all_upstreams[1]
        elif len(all_upstreams) == 1:
            if master_cte is None:
                master_cte = all_upstreams[0]
            if detail_cte is None:
                detail_cte = all_upstreams[0]

    # Join type mapping
    join_type_raw = attrs.get("Join Type", "Normal Join").strip()
    join_type_mapping: Dict[str, str] = {
        "Normal Join": "INNER JOIN",
        "Left Outer Join": "LEFT JOIN",
        "Right Outer Join": "RIGHT JOIN",
        "Full Outer Join": "FULL OUTER JOIN",
        "Master Outer Join": "RIGHT JOIN",
        "Detail Outer Join": "LEFT JOIN",
    }
    join_type = join_type_mapping.get(join_type_raw, "INNER JOIN")

    join_condition = attrs.get("Join Condition", "").strip()
    join_on: Optional[str] = translate_isnull(join_condition) if join_condition else None

    # Normalize join condition: replace bare source table names with CTE names
    # e.g. "orders.customer_id = customers.customer_id"
    #   -> "sq_orders.customer_id = sq_customers.customer_id"
    table_to_cte: Dict[str, str] = {
        src["name"]: f"sq_{src['name']}"
        for src in parsed.get("sources", [])
    }
    if join_on:
        join_on = normalize_join_condition(join_on, table_to_cte)

    # Select columns: MASTER input ports + DETAIL input ports
    master_cols = [
        f for f in fields
        if f.get("input_type", "").upper() == "MASTER"
        and f.get("port_type", "").upper() == "INPUT"
    ]
    detail_cols = [
        f for f in fields
        if f.get("input_type", "").upper() == "DETAIL"
        and f.get("port_type", "").upper() == "INPUT"
    ]

    # Fallback: if no input_type breakdown, use all INPUT ports
    if not master_cols and not detail_cols:
        all_input = [f for f in fields if f.get("port_type", "").upper() == "INPUT"]
        master_cols = all_input

    select_columns = []
    for f in master_cols:
        select_columns.append(
            {
                "name": to_snake_case(f["name"]),
                "expression": "",
                "alias": "",
                "is_passthrough": True,
                "original_expression": "",
                "source_side": "master",
            }
        )
    for f in detail_cols:
        select_columns.append(
            {
                "name": to_snake_case(f["name"]),
                "expression": "",
                "alias": "",
                "is_passthrough": True,
                "original_expression": "",
                "source_side": "detail",
            }
        )

    upstream_ctes: List[str] = []
    if master_cte and master_cte not in upstream_ctes:
        upstream_ctes.append(master_cte)
    if detail_cte and detail_cte not in upstream_ctes:
        upstream_ctes.append(detail_cte)

    cte_def: Dict[str, Any] = {
        "transformation_type": "joiner",
        "verbatim_sql": False,
        "upstream_ctes": upstream_ctes,
        "master_cte": master_cte,
        "detail_cte": detail_cte,
        "join_type": join_type,
        "join_on": join_on,
        "select_columns": select_columns,
        "where_clause": None,
        "group_by_cols": [],
        "lookup_table_ref": None,
        "lookup_on": None,
        "router_strategy": None,
        "route_groups": [],
    }
    return cte_name, cte_def


def handle_rtr(
    trans: Dict[str, Any],
    parsed: Dict[str, Any],
    source_name_set: Set[str],
    connector_map: Dict[str, List[str]],
    cte_name_map: Dict[str, str],
    source_refs: List[Dict[str, str]],
    model_name: str,
) -> Tuple[str, Dict[str, Any], List[Dict[str, Any]]]:
    """
    ROUTER -> rtr_{name} CTE.
    Determines Strategy A (CASE WHEN) or Strategy B (split models).
    Returns (cte_name, cte_definition, router_split_models).
    """
    trans_name: str = trans["name"]
    cte_name = normalize_prefix(trans_name, "rtr_")

    fields: List[Dict[str, Any]] = trans.get("fields", [])
    groups: List[Dict[str, Any]] = trans.get("groups", [])
    connectors = parsed.get("connectors", [])
    targets_set: Set[str] = {t["name"] for t in parsed.get("targets", [])}

    # Determine Router strategy:
    # Inspect downstream connectors (where from_instance == trans_name)
    # Group them by from_group; check which to_instance (TARGET) each group feeds.
    group_to_targets: Dict[str, Set[str]] = {}
    for conn in connectors:
        if conn.get("from_instance") != trans_name:
            continue
        from_group = conn.get("from_group", "") or ""
        to_instance = conn.get("to_instance", "")
        if from_group not in group_to_targets:
            group_to_targets[from_group] = set()
        group_to_targets[from_group].add(to_instance)

    # Collect all distinct target instances reached
    all_targets: Set[str] = set()
    for tgts in group_to_targets.values():
        all_targets.update(tgts)

    # Strategy A: all groups lead to same target (or no explicit from_group)
    # Strategy B: different groups lead to different targets
    if len(all_targets) <= 1:
        router_strategy = "case_when"
    else:
        router_strategy = "split"

    # Build route_groups from parsed groups
    route_groups = []
    for grp in groups:
        grp_name = grp.get("name", "")
        condition = grp.get("expression", "") or grp.get("condition", "") or ""
        translated_condition = translate_isnull(condition)
        route_groups.append(
            {
                "name": grp_name,
                "condition": translated_condition,
                "target": next(
                    iter(group_to_targets.get(grp_name, set())), None
                ),
            }
        )

    # Fallback: if no groups parsed, create placeholder
    if not route_groups:
        route_groups = [
            {"name": "DEFAULT", "condition": "", "target": None}
        ]

    # All INPUT ports pass through
    input_ports = [f for f in fields if f.get("port_type", "").upper() == "INPUT"]
    select_columns = [
        {
            "name": to_snake_case(f["name"]),
            "expression": "",
            "alias": "",
            "is_passthrough": True,
            "original_expression": "",
        }
        for f in input_ports
    ]

    upstream_ctes = get_upstream_ctes(trans_name, connector_map, cte_name_map)
    upstream_ref = upstream_ctes[0] if upstream_ctes else None

    # Strategy B: build router_split_models
    router_split_models: List[Dict[str, Any]] = []
    if router_strategy == "split":
        non_default_groups = [g for g in route_groups if g["condition"]]
        all_conditions = [g["condition"] for g in non_default_groups]
        for grp in route_groups:
            grp_name_snake = to_snake_case(grp["name"])
            if grp["condition"]:
                where_cond = grp["condition"]
            else:
                # DEFAULT group: NOT (all other conditions)
                if all_conditions:
                    other_conds = " OR ".join(f"({c})" for c in all_conditions if c)
                    where_cond = f"NOT ({other_conds})" if other_conds else ""
                else:
                    where_cond = ""
            split_model_name = f"rtr_{to_snake_case(trans_name.replace('rtr_', '', 1))}_{grp_name_snake}"
            router_split_models.append(
                {
                    "model_name": split_model_name,
                    "group_name": grp["name"],
                    "where_condition": where_cond,
                    "upstream_cte": model_name,  # ref() to the primary model
                    "materialization": "view",
                }
            )

    cte_def: Dict[str, Any] = {
        "transformation_type": "router",
        "verbatim_sql": False,
        "upstream_ctes": upstream_ctes,
        "upstream_ref": upstream_ref,
        "router_strategy": router_strategy,
        "route_groups": route_groups,
        "select_columns": select_columns,
        "where_clause": None,
        "group_by_cols": [],
        "join_type": None,
        "join_on": None,
        "master_cte": None,
        "detail_cte": None,
        "lookup_table_ref": None,
        "lookup_on": None,
    }
    return cte_name, cte_def, router_split_models


# ---------------------------------------------------------------------------
# Handler dispatch table (all except RTR which has extra return value)
# ---------------------------------------------------------------------------

HANDLERS: Dict[str, Any] = {
    "source_qualifier": handle_sq,
    "expression": handle_exp,
    "aggregator": handle_agg,
    "lookup": handle_lkp,
    "filter": handle_fil,
    "joiner": handle_jnr,
    # "router" handled separately in convert_mapping
}

# Normalise transformation type strings from parsed JSON to our keys
_TYPE_ALIASES: Dict[str, str] = {
    "source_qualifier": "source_qualifier",
    "expression": "expression",
    "aggregator": "aggregator",
    "lookup": "lookup",
    "filter": "filter",
    "joiner": "joiner",
    "router": "router",
    # common variants that may appear
    "source qualifier": "source_qualifier",
    "lookup procedure": "lookup",
}


def normalise_type(raw_type: str) -> str:
    return _TYPE_ALIASES.get(raw_type.strip().lower(), raw_type.strip().lower())


# ---------------------------------------------------------------------------
# Target / model name helpers
# ---------------------------------------------------------------------------

def derive_model_name(parsed: Dict[str, Any]) -> str:
    """Derive the primary DBT model name from TARGET.name (snake_case)."""
    targets = parsed.get("targets", [])
    if targets:
        return to_snake_case(targets[0]["name"])
    # Fallback: use mapping name with m_ stripped
    mapping_name = parsed.get("mapping_name", "unknown_model")
    if mapping_name.startswith("m_"):
        mapping_name = mapping_name[2:]
    return to_snake_case(mapping_name)


def derive_model_materialization(model_name: str) -> str:
    """'table' if model_name starts with fact_ or dim_, else 'view'."""
    if model_name.startswith("fact_") or model_name.startswith("dim_"):
        return "table"
    return "view"


def extract_output_columns(parsed: Dict[str, Any], final_cte_name: str) -> List[Dict[str, Any]]:
    """
    Build output_columns from TARGET TARGETFIELD definitions.
    """
    targets = parsed.get("targets", [])
    if not targets:
        return []
    target = targets[0]
    output_cols = []
    for field in target.get("fields", []):
        output_cols.append(
            {
                "name": to_snake_case(field.get("name", "")),
                "source_cte": final_cte_name,
                "datatype": field.get("datatype", ""),
                "key_type": field.get("key_type", ""),
                "null_type": field.get("null_type", ""),
            }
        )
    return output_cols


def extract_pk_columns(parsed: Dict[str, Any]) -> List[str]:
    """Extract PRIMARY KEY column names from TARGET TARGETFIELD."""
    targets = parsed.get("targets", [])
    if not targets:
        return []
    return [
        to_snake_case(f["name"])
        for f in targets[0].get("fields", [])
        if f.get("key_type", "").upper() == "PRIMARY KEY"
    ]


def extract_fk_columns(
    parsed: Dict[str, Any], model_name: str
) -> List[Dict[str, Any]]:
    """Extract FOREIGN KEY relationship definitions from TARGET TARGETFIELD."""
    targets = parsed.get("targets", [])
    if not targets:
        return []
    fk_list = []
    for f in targets[0].get("fields", []):
        if f.get("key_type", "").upper() == "FOREIGN KEY":
            fk_list.append(
                {
                    "column_name": to_snake_case(f["name"]),
                    "references_model": f.get("references_model", ""),
                    "references_column": f.get("references_column", ""),
                }
            )
    return fk_list


# ---------------------------------------------------------------------------
# Core conversion: one parsed mapping -> one conversion plan
# ---------------------------------------------------------------------------

def convert_mapping(parsed: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert a single parsed mapping dict to a conversion plan dict.
    """
    mapping_name: str = parsed.get("mapping_name", "unknown_mapping")

    # Build source name set (snake_case)
    sources: List[Dict[str, Any]] = parsed.get("sources", [])
    source_name_set: Set[str] = {to_snake_case(s["name"]) for s in sources}

    # Connector map: transformation_name -> [upstream transformation names]
    connector_map = build_connector_map(parsed)

    # Build transformation lookup
    transformations: List[Dict[str, Any]] = parsed.get("transformations", [])
    trans_lookup: Dict[str, Dict[str, Any]] = {t["name"]: t for t in transformations}

    # Use dag_order if available, otherwise fall back to array order
    dag_order: List[str] = parsed.get("dag_order", [])
    if not dag_order:
        print(
            f"WARNING: dag_order missing in parsed JSON for '{mapping_name}'. "
            f"Falling back to transformation array order.",
            file=sys.stderr,
        )
        dag_order = [t["name"] for t in transformations]

    # Derive model name before processing RTR (needed for split model refs)
    model_name = derive_model_name(parsed)
    model_materialization = derive_model_materialization(model_name)

    # Process transformations in DAG order
    cte_name_map: Dict[str, str] = {}  # original_name -> cte_name
    ctes: Dict[str, Dict[str, Any]] = {}
    cte_order: List[str] = []
    source_refs: List[Dict[str, str]] = []
    router_split_models: List[Dict[str, Any]] = []
    global_router_strategy: Optional[str] = None

    for trans_name in dag_order:
        trans = trans_lookup.get(trans_name)
        if trans is None:
            print(
                f"WARNING: Transformation '{trans_name}' in dag_order not found in transformations list.",
                file=sys.stderr,
            )
            continue

        raw_type = trans.get("type", "")
        norm_type = normalise_type(raw_type)

        if norm_type == "router":
            cte_name, cte_def, split_models = handle_rtr(
                trans, parsed, source_name_set, connector_map, cte_name_map, source_refs, model_name
            )
            router_split_models.extend(split_models)
            if global_router_strategy is None:
                global_router_strategy = cte_def.get("router_strategy")
        elif norm_type in HANDLERS:
            handler = HANDLERS[norm_type]
            cte_name, cte_def = handler(
                trans, parsed, source_name_set, connector_map, cte_name_map, source_refs
            )
        else:
            print(
                f"WARNING: Unknown transformation type '{raw_type}' for '{trans_name}'. Skipping.",
                file=sys.stderr,
            )
            continue

        cte_name_map[trans_name] = cte_name
        ctes[cte_name] = cte_def
        cte_order.append(cte_name)

    # Determine final select CTE (last in cte_order that isn't a router with strategy B)
    final_select_cte = cte_order[-1] if cte_order else ""

    # Build output columns from TARGET
    output_columns = extract_output_columns(parsed, final_select_cte)
    pk_columns = extract_pk_columns(parsed)
    fk_columns = extract_fk_columns(parsed, model_name)

    # Model files: primary + any split models
    model_files = [f"{model_name}.sql"]
    for sm in router_split_models:
        model_files.append(f"{sm['model_name']}.sql")

    # Determine target name
    targets_list = parsed.get("targets", [])
    target_name = to_snake_case(targets_list[0]["name"]) if targets_list else model_name

    conversion_plan: Dict[str, Any] = {
        "mapping_name": mapping_name,
        "model_name": model_name,
        "model_materialization": model_materialization,
        "source_refs": source_refs,
        "cte_order": cte_order,
        "ctes": ctes,
        "final_select_cte": final_select_cte,
        "output_columns": output_columns,
        "router_split_models": router_split_models,
        "router_strategy": global_router_strategy,
        "target_name": target_name,
        "pk_columns": pk_columns,
        "fk_columns": fk_columns,
        "model_files": model_files,
    }
    return conversion_plan


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """
    Main entry point.
    Reads parsed_mapping.json (or all mappings via index.json) and writes
    conversion_plan.json to agent-output/converted/.
    """
    CONVERTED_DIR.mkdir(parents=True, exist_ok=True)

    # Determine which parsed files to process
    index_path = PARSED_DIR / "index.json"
    parsed_path = PARSED_DIR / "parsed_mapping.json"

    mapping_files: List[Path] = []

    if index_path.exists():
        try:
            index_data = json.loads(index_path.read_text(encoding="utf-8"))
            # index.json may be a list of mapping entries or a dict with a "mappings" key
            if isinstance(index_data, list):
                entries = index_data
            else:
                entries = [{"mapping_name": m} for m in index_data.get("mappings", [])]
            for entry in entries:
                mapping_name = entry.get("mapping_name") if isinstance(entry, dict) else entry
                if not mapping_name:
                    continue
                candidate = PARSED_DIR / f"{mapping_name}.json"
                if candidate.exists():
                    mapping_files.append(candidate)
                else:
                    print(
                        f"WARNING: Index references '{mapping_name}' but '{candidate}' not found.",
                        file=sys.stderr,
                    )
        except json.JSONDecodeError as exc:
            print(f"ERROR: Failed to parse index.json: {exc}", file=sys.stderr)

    # Fall back to parsed_mapping.json if no index or no files found via index
    if not mapping_files and parsed_path.exists():
        mapping_files.append(parsed_path)

    if not mapping_files:
        print(
            "ERROR: No parsed mapping files found. "
            "Run parse_informatica_xml.py first.",
            file=sys.stderr,
        )
        sys.exit(1)

    any_error = False
    for mapping_file in mapping_files:
        try:
            parsed_data = json.loads(mapping_file.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            print(
                f"ERROR: Failed to parse '{mapping_file}': {exc}",
                file=sys.stderr,
            )
            any_error = True
            continue

        mapping_name = parsed_data.get("mapping_name", mapping_file.stem)
        print(f"Converting mapping: {mapping_name}")

        conversion_plan = convert_mapping(parsed_data)

        # Determine output filename
        # The spec says conversion_plan.json for the primary file,
        # but also supports {mapping_name}_plan.json per component plan.
        # We write both for compatibility.
        output_filename = f"{to_snake_case(mapping_name)}_plan.json"
        output_path = CONVERTED_DIR / output_filename

        try:
            output_path.write_text(
                json.dumps(conversion_plan, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            print(f"  Written: {output_path}")
        except IOError as exc:
            print(f"ERROR: Failed to write '{output_path}': {exc}", file=sys.stderr)
            any_error = True
            continue

        # Note: conversion_plan.json alias removed — only {mapping_name}_plan.json is written.
        # The alias caused duplicate model issues downstream in generate_dbt_models.py.

    if any_error:
        sys.exit(1)

    print("convert_transformations.py: done.")


if __name__ == "__main__":
    main()
