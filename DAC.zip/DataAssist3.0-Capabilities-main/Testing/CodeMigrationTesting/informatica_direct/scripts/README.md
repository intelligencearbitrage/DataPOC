# Informatica Direct — Scripts

Python test scripts for validating Informatica PowerCenter to Snowflake direct 2-stage migrations across 12 test dimensions.

## Overview

This directory contains the complete testing framework for a 2-stage direct conversion pipeline (RE Input -> FE Output, no intermediate RE Output). Scripts use `strategies.json` to resolve which source mapping produced which target table (1:N fan-out via Router groups). All scripts read configuration from `config.yaml` (co-located in this directory) and write results to `output/`.

- **Source Platform**: Informatica PowerCenter
- **Target Platform**: Snowflake
- **Migration Mode**: One-to-one (direct conversion)
- **Pipeline Shape**: Linear (2 stages — RE Input -> FE Output)
- **FE Output Layout**: Flat (all DDL/DML/procedures at top level, no per-mapping subdirectories)
- **Cross-Reference**: `strategies.json` maps target tables back to source XML mappings
- **Artifact Unit**: Mapping (one Informatica XML mapping = one unit under test)

This pipeline has only 2 stages — there is no intermediate RE Output stage. The critical cross-reference file `strategies.json` resolves the 1:N fan-out — a single XML mapping can produce multiple target tables.

This directory plus `inputs/` is a fully portable test suite -- copy both to any machine and run `cd scripts && python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt && python cli.py`.

## Test Dimensions

| Dimension | Prefix | Scope | Severity | Description |
|-----------|--------|-------|----------|-------------|
| Direct Mapping Coverage | `DMC` | RE | Critical | Validates that every source XML mapping connects to at least one FE Output DDL/DML artifact via `strategies.json` |
| Transformation Fidelity | `TFD` | RE | Critical | Validates that Informatica transformation logic (Expression ports, Filter conditions, Lookup JOINs) is correctly translated to Snowflake SQL |
| Syntax Validation | `SYN` | FE | Medium | Detects Informatica source residue (`$$`, `SESSSTARTTIME`, `:LKP.`, `IIF(`, etc.) in target SQL and validates Snowflake syntax |
| Parameter Resolution | `PRM` | FE | Medium | Validates that `$$Param_*` and `$Param_*` references from `.prm` parameter files are resolved in target SQL |
| Source Schema Validation | `SSV` | RE | High | Validates that source DDL column definitions are preserved in target DDL — column names, data types, and constraints |
| Conversion Manifest | `CMV` | FE | High | Validates `strategies.json` and `conversion_summary.yaml` consistency — every target table must trace back to a source mapping |
| Column-Level Lineage | `CLL` | E2E | Critical | Traces column lineage from Informatica XML source fields through to target DDL/DML — validates every source column reaches the target |
| Expression Accuracy | `EXA` | FE | Critical | Validates function translations (IIF->IFF, DECODE, SUBSTR->SUBSTRING), join conditions, and expression port logic accuracy |
| Transformation-Type Validation | `XTV` | FE | Critical | Validates Informatica transformation types (Router groups, Normalizer, Mapplet ports) are correctly mapped to Snowflake SQL patterns |
| Artifact Consistency | `ACN` | FE | High | Validates 3-way alignment between DDL, DML, and stored procedure artifacts — column lists, table names, and types must match |
| Workflow Orchestration | `WFO` | FE | Medium | Validates execution dependency order — workflow links and session sequences produce correct Snowflake Task/procedure ordering |
| Regression | `REG` | Meta | Low | Compares current run against previous baseline — excluded in fresh mode |

## Prerequisites

- Python 3.9+
- pip (Python package manager)

## Installation

```bash
# From the scripts/ directory
python -m venv .venv
source .venv/bin/activate            # Linux/macOS
# .venv\Scripts\activate             # Windows

pip install -r requirements.txt
```

Dependencies: `PyYAML>=6.0`, `openpyxl>=3.1.0`, `litellm>=1.40.0`, `jinja2>=3.1.0`, `python-dotenv>=1.0.0`

### API Key Setup (Agentic Mode)

Copy the example env file and add your API key:

```bash
cp .env.example .env
# Edit .env and set your API key
```

The `.env` file is gitignored. Supported keys: `ANTHROPIC_API_KEY`, `ANTHROPIC_FOUNDRY_API_KEY`, `OPENAI_API_KEY`, `GEMINI_API_KEY`, `AZURE_API_KEY`, `COHERE_API_KEY`.

## How to Run

```bash
# Activate the virtual environment first
source .venv/bin/activate

# --- Layer 1: Deterministic Tests ---
python cli.py                                    # Full deterministic run
python cli.py --scope re_only                    # RE dimensions only (DMC, TFD, SSV)
python cli.py --scope fe_only                    # FE dimensions only (SYN, PRM, CMV, EXA, XTV, ACN, WFO)
python cli.py --run-mode incremental             # Compare against previous run
python cli.py --list-dimensions                  # List active test dimensions

# --- Layer 2: Agentic Validation + Refinement (requires API key) ---
python cli.py --mode agentic                     # Layer 1 + Layer 2 interactive
python cli.py --mode agentic --skip-build        # Layer 2 on existing output
python cli.py --mode agentic --non-interactive   # Full pipeline, no prompts
python cli.py --mode validate-only               # Validator only, no refinement
python cli.py --mode validate-only --skip-build  # Validate existing output only
```

### Environment Variables

| Variable | Values | Default | Description |
|----------|--------|---------|-------------|
| `MT_RUN_MODE` | `fresh`, `incremental` | `fresh` | Controls whether to compare against a previous baseline |
| `MT_TEST_SCOPE` | `full`, `re_only`, `fe_only` | `full` | Filters which dimensions execute |
| `MT_INPUT_DIR` | Absolute path | Auto-resolved | Override the input directory path |
| `SCENARIO_ROOT` | Absolute path | Auto-resolved | Override the scenario root directory |
| `MT_CONFIG_PATH` | Absolute path | Auto-resolved | Override config file path |
| `ANTHROPIC_API_KEY` | API key string | (none) | Required for agentic mode LLM calls |
| `ANTHROPIC_FOUNDRY_API_KEY` | API key string | (none) | Alternative: auto-bridged to `ANTHROPIC_API_KEY` |

## Input Directory Structure

```
inputs/
└── fresh/
    ├── re-input/                        # RE Input — Informatica source artifacts
    │   ├── source_mappings/             # Informatica POWERMART XML mapping exports
    │   │   └── *.XML                    # One file per mapping (drives discovery)
    │   ├── source_workflows/            # Informatica workflow XML exports
    │   │   └── *.XML
    │   ├── parameter_files/             # Informatica .prm parameter files
    │   │   └── *.prm
    │   └── source_ddls/                 # Source platform DDL files
    │       └── *.sql
    └── fe-output/                       # FE Output — generated Snowflake SQL (flat layout)
        ├── strategies.json              # Required: target table -> source mapping cross-reference
        ├── conversion_summary.yaml      # Optional: conversion summary metadata
        ├── ddl/                         # Snowflake DDL files
        │   └── *.sql
        ├── dml/                         # Snowflake DML files
        │   └── *.sql
        └── procedures/                  # Snowflake stored procedures
            └── *.sql
```

| Stage | Folder | Required Files | Formats |
|-------|--------|----------------|---------|
| RE Input | `inputs/fresh/re-input/source_mappings/` | Informatica POWERMART XML mapping exports | `.XML` |
| RE Input | `inputs/fresh/re-input/source_workflows/` | Informatica workflow XML exports (optional) | `.XML` |
| RE Input | `inputs/fresh/re-input/parameter_files/` | Informatica `.prm` parameter files (optional) | `.prm` |
| RE Input | `inputs/fresh/re-input/source_ddls/` | Source DDL definitions (optional, used by SSV) | `.sql` |
| FE Output | `inputs/fresh/fe-output/` | `strategies.json` + Snowflake SQL in `ddl/`, `dml/`, `procedures/` | `.json`, `.sql` |

For incremental mode, also provide `inputs/rerun/` (updated artifacts) and `inputs/previous/` (prior run's artifacts for SCD3 comparison).

**Flat layout**: FE Output has no per-mapping subdirectories. All DDL, DML, and procedure files are in shared top-level directories. Use `strategies.json` to determine which mapping produced which target table.

**1:N Fan-out**: A single XML mapping can produce multiple target tables via Router transformation groups. Always use `strategies.json` to resolve target-to-mapping associations.

## Output Location and Report Format

All generated outputs are stored in the `output/` directory:

| Report | File(s) | Description |
|--------|---------|-------------|
| Dimension Results | `{dimension}_results.yaml` | Per-dimension YAML with pass/fail/warn status per mapping |
| Per-Mapping Reports | `reports/{MAPPING}/{MAPPING}_test_report_{ts}.xlsx` + `.json` | Detailed XLSX workbook with test results |
| Integration Test Report | `INTEGRATION_TEST_REPORT.md` + `.html` + `.json` + `.xlsx` | Consolidated summary in multiple formats |
| Test Cases | `integration_test_cases.yaml` | Test case catalog |
| Root Cause Analysis | `rca_report.yaml` | Failure pattern analysis |
| Conversion Reports | `conversion_reports/conversion_report_{ts}.md` + `.xlsx` | Overall conversion quality assessment |
| Rerun Comparison | `reports/rerun_{MAPPING}_{ts}.xlsx` + `.json` | SCD Type 3 comparison (incremental mode only) |

The HTML report is self-contained with executive summary, per-dimension results, RCA analysis, fix suggestions, and color-coded status badges (green=PASS, red=FAIL, yellow=WARN, gray=SKIP).

## Scripts Reference

### Test Dimension Scripts

Each validator extends `BaseValidator` and implements a `validate(procedure_name)` method. Target table discovery uses `strategies.json` to map tables back to source XML mappings.

| Script | Dimension | Prefix |
|--------|-----------|--------|
| `test_direct_mapping_coverage.py` | Direct Mapping Coverage | `DMC` |
| `test_transformation_fidelity.py` | Transformation Fidelity | `TFD` |
| `test_syntax_validation.py` | Syntax Validation | `SYN` |
| `test_parameter_resolution.py` | Parameter Resolution | `PRM` |
| `test_source_schema_validation.py` | Source Schema Validation | `SSV` |
| `test_conversion_manifest.py` | Conversion Manifest | `CMV` |
| `test_column_level_lineage.py` | Column-Level Lineage | `CLL` |
| `test_expression_accuracy.py` | Expression Accuracy | `EXA` |
| `test_xform_type_validation.py` | Xform-Type Validation | `XTV` |
| `test_artifact_consistency.py` | Artifact Consistency | `ACN` |
| `test_workflow_orchestration.py` | Workflow Orchestration | `WFO` |
| `test_regression.py` | Regression | `REG` |

### Direct Scenario Parsers

| Script | Purpose |
|--------|---------|
| `direct_xml_parser.py` | Parses Informatica POWERMART XML — extracts source/target definitions, transformation types/fields/expressions, connectors, Router groups, Joiner conditions, and Mapplet ports |
| `direct_strategies_parser.py` | Parses `strategies.json` — maps target tables to source mapping names, resolves 1:N fan-out from Router transformation groups |
| `direct_param_parser.py` | Parses `.prm` parameter files — extracts `$$Param_*` and `$Param_*` parameter key-value pairs for resolution validation |

**DDL parsing note**: DDLs in this scenario use single-line column format (all columns on one line). Column extraction regex patterns use `(?:^|,|\()` anchors instead of line-start `^`.

### Framework Scripts

| Script | Purpose |
|--------|---------|
| `cli.py` | CLI entry point — parses arguments (scope, run-mode), sets environment variables, invokes `build_all.py` |
| `build_all.py` | Master orchestrator — discovers test scripts in execution order, runs each script's `main()`, generates summary YAML, handles fresh/incremental mode |
| `execute_test_run.py` | Test execution coordinator |
| `migration_config.py` | Configuration loader — reads `config.yaml`, exports constants, dimension filtering |

### Report Generators

| Script | Purpose | Output |
|--------|---------|--------|
| `generate_test_cases.py` | Creates test case catalog | `integration_test_cases.yaml` |
| `generate_procedure_report.py` | Per-mapping XLSX+JSON reports | `reports/{MAPPING}/{MAPPING}_test_report_{ts}.xlsx` + `.json` |
| `generate_md_report.py` | Consolidated Markdown report | `INTEGRATION_TEST_REPORT.md` |
| `generate_html_report.py` | Self-contained HTML report with inline CSS | `INTEGRATION_TEST_REPORT.html` |
| `generate_report_formats.py` | Structured JSON and formatted Excel workbook | `INTEGRATION_TEST_REPORT.json` + `.xlsx` |
| `root_cause_analyzer.py` | Analyzes test failure patterns and generates root cause report | `rca_report.yaml` |
| `rerun_comparison.py` | Baseline comparison (incremental mode) | Baseline data |
| `generate_rerun_report.py` | SCD Type 3 comparison XLSX | `reports/rerun_{MAPPING}_{ts}.xlsx` |

### Base Classes and Utilities

| Script | Purpose |
|--------|---------|
| `base_validator.py` | Abstract base class for validators |
| `base_parser.py` | Abstract base class for parsers |
| `base_generator.py` | Abstract base class for generators |
| `utils.py` | Shared utilities — YAML I/O, logging, timestamp, file discovery |
| `artifact_indexer.py` | File-to-mapping mapper using longest-prefix matching |
| `dedup_utils.py` | Deduplication helpers |

### Other

| Script | Purpose |
|--------|---------|
| `validator.py` | Post-run validation framework |
| `refiner.py` | Optional refinement layer for agentic mode |
| `prompts.py` | Prompt generation for agentic mode |
| `tests/test_contracts.py` | Unit tests for framework contracts |

## Configuration

The primary configuration file is `config.yaml` in this directory. Resolution order:

1. `MT_CONFIG_PATH` environment variable (if set)
2. `scripts/config.yaml` (co-located — **primary**)

| Setting | Description |
|---------|-------------|
| `project.source_platform` | Source platform identifier (Informatica) |
| `project.target_platform` | Target platform identifier (Snowflake) |
| `project.artifact_unit_label` | Unit label (`mapping`) |
| `testing.scope` | Default test scope (`full`, `re_only`, `fe_only`) |
| `dimensions` | 12 dimensions with prefixes, scopes, severities |
| `source_residue.keywords` | Informatica keywords to detect in Snowflake output |
| `fe_output_layout` | Flat layout — `ddl/`, `dml/`, `procedures/` at top level |
| `sttm_thresholds.column_coverage_pass` | Minimum column coverage (default: 85%) |
| `sttm_thresholds.transformation_coverage_min` | Minimum transformation coverage (default: 85%) |
| `sttm_thresholds.fan_out_coverage_min` | Required fan-out coverage (default: 100%) |
| `artifact_patterns` | Discovery folder (`source_mappings/`), file glob (`*.XML`), variant suffixes |
