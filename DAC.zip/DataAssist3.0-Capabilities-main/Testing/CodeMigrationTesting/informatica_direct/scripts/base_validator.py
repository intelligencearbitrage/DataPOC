"""
Base Validator -- Abstract base class for test validation.

All test dimension validators extend this class. Provides common patterns
for file checks, YAML validation, result formatting, and test execution.

In the hybrid architecture, this class lives in core/ and contains NO
platform-specific logic. Scenario adapters subclass it and provide
concrete validate() implementations without conditional branching.
"""

import logging
import py_compile
from abc import ABC, abstractmethod
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

logger = logging.getLogger(__name__)


class BaseValidator(ABC):
    """Abstract base class for migration test validators."""

    def __init__(
        self,
        input_dir: str = "inputs",
        output_dir: str = "output",
        dimension: str = "UNKNOWN",
    ):
        # Resolve input_dir through config so that inputs/fresh/ is
        # auto-detected even when callers pass the bare "inputs" default.
        resolved = Path(input_dir)
        if resolved.name == "inputs":
            from migration_config import resolve_input_dir
            resolved = resolve_input_dir(resolved.parent if resolved.is_absolute() else Path.cwd())
        self.input_dir = resolved
        self.output_dir = Path(output_dir)
        self.dimension = dimension
        self.output_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Abstract methods -- must be implemented by each test dimension
    # ------------------------------------------------------------------

    @abstractmethod
    def validate(self, procedure_name: str) -> Dict[str, Any]:
        """Run validation for a single procedure.

        Args:
            procedure_name: Name of the stored procedure to validate.

        Returns:
            Standardised result dict with keys: test_id, procedure,
            dimension, status, assertions, errors, warnings.
        """

    # ------------------------------------------------------------------
    # Utility: file existence checks
    # ------------------------------------------------------------------

    def check_files_exist(self, paths: List[str]) -> Dict[str, Any]:
        """Check that all required files exist.

        Returns:
            Dict with 'passed' and 'missing' lists.
        """
        passed, missing = [], []
        for p in paths:
            (passed if Path(p).exists() else missing).append(p)
        return {"passed": passed, "missing": missing}

    # ------------------------------------------------------------------
    # Utility: YAML validation
    # ------------------------------------------------------------------

    def check_yaml_valid(self, file_path: str) -> bool:
        """Return True if a YAML file parses without errors."""
        try:
            with open(file_path, "r", encoding="utf-8") as fh:
                yaml.safe_load(fh)
            return True
        except (yaml.YAMLError, OSError) as exc:
            logger.warning("Invalid YAML %s: %s", file_path, exc)
            return False

    # ------------------------------------------------------------------
    # Utility: Python syntax check
    # ------------------------------------------------------------------

    @staticmethod
    def check_python_syntax(file_path: str) -> bool:
        """Return True if a Python file compiles without syntax errors."""
        try:
            py_compile.compile(file_path, doraise=True)
            return True
        except py_compile.PyCompileError:
            return False

    # ------------------------------------------------------------------
    # Utility: normalize procedure/artifact name
    # ------------------------------------------------------------------

    @staticmethod
    def _normalize_procedure_name(raw_name: str, variant_suffixes: Optional[List[str]] = None) -> str:
        """Normalize an artifact filename to its base procedure name.

        Strips known variant suffixes and trailing version numbers.
        """
        import re as _re

        if variant_suffixes is None:
            from migration_config import VARIANT_SUFFIXES
            variant_suffixes = VARIANT_SUFFIXES

        name = raw_name
        sorted_suffixes = sorted(variant_suffixes, key=len, reverse=True)
        prev = None
        while name != prev:
            prev = name
            name = _re.sub(r'\s+\d+$', '', name)
            for suffix in sorted_suffixes:
                if name.lower().endswith(suffix.lower()):
                    name = name[: -len(suffix)]
        return name.strip()

    # ------------------------------------------------------------------
    # Utility: required fields check
    # ------------------------------------------------------------------

    @staticmethod
    def check_required_fields(
        data: Dict[str, Any], required: List[str]
    ) -> Dict[str, Any]:
        """Check that a dict contains all required keys.

        Returns:
            Dict with 'valid' bool and list of 'missing' keys.
        """
        missing = [k for k in required if k not in data]
        return {"valid": len(missing) == 0, "missing": missing}

    # ------------------------------------------------------------------
    # Procedure discovery
    # ------------------------------------------------------------------

    def discover_procedures(self) -> List[str]:
        """Discover procedure/workflow names from the inputs directory.

        Recursively scans subdirectories so that scenarios with nested
        input layouts (e.g. ``re-input/Source Mappings/*.xml``) are
        discovered correctly.  Only files with known extensions are
        treated as procedures; pure subdirectories are traversed but
        their names are not added.

        Uses ArtifactIndex prefix-match for canonical resolution,
        then falls back to _normalize_procedure_name for unmatched items.
        """
        from migration_config import DISCOVERY_SUBDIRS, UNIT_NAME_STRIP_SUFFIXES, EXCLUDE_NAMES
        from artifact_indexer import get_index

        idx = get_index(self.input_dir)

        procedures: set = set()
        _KNOWN_EXTENSIONS = {".sql", ".csv", ".xlsx", ".json", ".xml"}

        def _scan_dir(directory: Path) -> None:
            """Scan a directory, recursing into subdirectories."""
            if not directory.exists():
                return
            for item in directory.iterdir():
                name = item.name
                if name.startswith(".") or name.startswith("_"):
                    continue
                # Recurse into subdirectories instead of treating them as procedures
                if item.is_dir():
                    _scan_dir(item)
                    continue
                if item.suffix.lower() not in _KNOWN_EXTENSIONS:
                    continue
                raw = item.stem

                if idx._canonical:
                    matched = idx._match(raw)
                    if matched:
                        procedures.add(matched)
                        continue

                name = self._normalize_procedure_name(raw)
                if UNIT_NAME_STRIP_SUFFIXES:
                    changed = True
                    while changed:
                        changed = False
                        for suffix in UNIT_NAME_STRIP_SUFFIXES:
                            if name.endswith(suffix):
                                name = name[: -len(suffix)]
                                changed = True
                if name:
                    procedures.add(name)

        for subdir in DISCOVERY_SUBDIRS:
            stage_dir = self.input_dir / subdir
            _scan_dir(stage_dir)

        # Remove excluded names (e.g., conversion_summary)
        if EXCLUDE_NAMES:
            procedures -= set(EXCLUDE_NAMES)

        # Deduplicate wf_/m_ pairs via cross-reference
        procedures = self._dedup_wf_m(procedures)

        return sorted(procedures)

    # ------------------------------------------------------------------
    # Pluggable xref helper
    # ------------------------------------------------------------------

    @staticmethod
    def _get_xref_module():
        """Return the cross-reference module if configured, else None."""
        import importlib
        from migration_config import XREF_MODULE
        if not XREF_MODULE:
            return None
        try:
            return importlib.import_module(XREF_MODULE)
        except ImportError:
            return None

    # ------------------------------------------------------------------
    # Deduplication helper (wf_ / m_ naming mismatch)
    # ------------------------------------------------------------------

    def _dedup_wf_m(self, procedures: set) -> set:
        """Remove wf_ names that are redundant with their m_ equivalents.

        Delegates to the shared ``core.dedup_utils.dedup_wf_m()`` which
        proactively expands wf_ names to their m_ children (even if children
        are not yet in the set), removes utility mappings, and performs a
        final cleanup pass.
        """
        from dedup_utils import dedup_wf_m
        return dedup_wf_m(self.input_dir, procedures)

    # ------------------------------------------------------------------
    # Artifact resolution
    # ------------------------------------------------------------------

    def resolve_artifact(self, stage_subdir: str, procedure: str,
                         extensions: tuple = (".xml", ".XML", ".sql", ".xlsx", ".csv")) -> Optional[Path]:
        """Find a file for *procedure* inside *stage_subdir*, recursively.

        Searches ``self.input_dir / stage_subdir`` and all its
        subdirectories for a file whose stem starts with *procedure*
        and has one of the given *extensions*.  Returns the first match
        or ``None``.
        """
        base_dir = self.input_dir / stage_subdir
        if not base_dir.exists():
            return None
        proc_upper = procedure.upper()
        for ext in extensions:
            # Exact name match first (fastest)
            for candidate in base_dir.rglob(f"{procedure}{ext}"):
                return candidate
        # Prefix match (e.g. m_FOO matches m_FOO_lineage.xlsx)
        for ext in extensions:
            for candidate in base_dir.rglob(f"{procedure}*{ext}"):
                if candidate.stem.upper().startswith(proc_upper):
                    return candidate
        return None

    # ------------------------------------------------------------------
    # Stage-existence helpers
    # ------------------------------------------------------------------

    def _get_index(self):
        """Return cached ArtifactIndex for self.input_dir (lazy init)."""
        if not hasattr(self, "_artifact_index"):
            from artifact_indexer import get_index
            self._artifact_index = get_index(self.input_dir)
        return self._artifact_index

    def resolve_stage_dir(self, unit_name: str, stage_key: str) -> Optional[Path]:
        """Return actual directory Path for unit in stage, or None."""
        subdir_map = {
            "re_output": "re-output",
            "fe_output": "fe-output",
            "fe_input":  "fe-input",
            "re_input":  "re-input",
        }
        subdir_name = subdir_map.get(stage_key, stage_key)
        exact = self.input_dir / subdir_name / unit_name
        if exact.is_dir():
            return exact
        return self._get_index().resolve_stage_dir(unit_name, stage_key)

    def has_re_output(self, workflow_name: str) -> bool:
        """Return True if RE Output artifacts exist for *workflow_name*.

        Checks for a subdirectory ``inputs/re-output/{workflow_name}/``
        containing at least one file.  Falls back to checking the parent
        wf_ directory via the mapping cross-reference for m_ names.
        Falls back further to ArtifactIndex for any suffix-variant files.
        """
        re_out_dir = self.input_dir / "re-output" / workflow_name
        if re_out_dir.is_dir() and any(re_out_dir.iterdir()):
            return True

        # Fallback: resolve m_ -> wf_ via xref
        resolved = self.resolve_re_output_name(workflow_name)
        if resolved and resolved != workflow_name:
            re_out_dir = self.input_dir / "re-output" / resolved
            if re_out_dir.is_dir() and any(re_out_dir.iterdir()):
                return True

        # ArtifactIndex fallback
        return self._get_index().has_unit_in_stage(workflow_name, "re_output")

    def has_fe_output(self, workflow_name: str) -> bool:
        """Return True if FE Output artifacts exist for *workflow_name*.

        Checks for a subdirectory ``inputs/fe-output/{workflow_name}/``
        containing at least one file.  For wf_ names, also checks whether
        any of the child m_ mappings have FE output.
        Falls back to ArtifactIndex for suffix-variant dirs.
        """
        fe_out_dir = self.input_dir / "fe-output" / workflow_name
        if fe_out_dir.is_dir() and any(fe_out_dir.iterdir()):
            return True

        # Fallback: for wf_ names, check child m_ mappings
        xref_mod = self._get_xref_module()
        if xref_mod is not None:
            re_output_dir = self.input_dir / "re-output"
            m_names = xref_mod.resolve_mappings_for_wf(re_output_dir, workflow_name)
            for m_name in m_names:
                m_dir = self.input_dir / "fe-output" / m_name
                if m_dir.is_dir() and any(m_dir.iterdir()):
                    return True

        # ArtifactIndex fallback
        return self._get_index().has_unit_in_stage(workflow_name, "fe_output")

    def has_re_input(self, workflow_name: str) -> bool:
        """Return True if an RE Input artifact exists for *workflow_name*.

        Falls back to checking the parent wf_ name via xref for m_ names.
        """
        re_in = self.input_dir / "re-input"
        for ext in (".xml", ".sql"):
            if (re_in / f"{workflow_name}{ext}").exists():
                return True

        # Fallback: resolve m_ -> wf_ via xref
        resolved = self.resolve_re_output_name(workflow_name)
        if resolved and resolved != workflow_name:
            for ext in (".xml", ".sql"):
                if (re_in / f"{resolved}{ext}").exists():
                    return True

        return False

    def resolve_re_output_name(self, name: str) -> Optional[str]:
        """Return the wf_ name that has the actual re-output directory.

        For wf_ names, returns the name as-is.  For m_ names, resolves to
        the parent wf_ name via the mapping cross-reference.  Returns None
        if no mapping is found.
        """
        # Direct directory exists?
        if (self.input_dir / "re-output" / name).is_dir():
            return name

        # Try xref resolution via pluggable module
        xref_mod = self._get_xref_module()
        if xref_mod is not None:
            return xref_mod.resolve_wf_for_mapping(self.input_dir / "re-output", name)
        return None

    # ------------------------------------------------------------------
    # Result helpers
    # ------------------------------------------------------------------

    def make_result(
        self,
        test_id: str,
        procedure: str,
        status: str,
        assertions: Optional[List[Dict]] = None,
        errors: Optional[List[str]] = None,
        warnings: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Create a standardised test result dict.

        Normalises each assertion dict so both ``name``/``check`` and
        ``detail``/``expected``+``actual`` keys are always present,
        preventing schema-inconsistency issues downstream (RCA, validator,
        Markdown report).
        """
        normalised: List[Dict[str, Any]] = []
        for a in (assertions or []):
            entry = dict(a)
            # Normalise key names: prefer "check" over "name" for assertions.
            # Keep output clean — only check/expected/actual/passed.
            if "check" not in entry and "name" in entry:
                entry["check"] = entry.pop("name")
            elif "name" in entry:
                entry.pop("name", None)
            # Remove "detail" — downstream consumers use expected/actual directly
            entry.pop("detail", None)
            normalised.append(entry)

        return {
            "test_id": test_id,
            "procedure": procedure,
            "dimension": self.dimension,
            "status": status,
            "assertions": normalised,
            "errors": errors or [],
            "warnings": warnings or [],
        }

    # ------------------------------------------------------------------
    # Save results
    # ------------------------------------------------------------------

    def save_results(
        self,
        results: List[Dict[str, Any]],
        filename: Optional[str] = None,
    ) -> Path:
        """Save test results to YAML in the output directory.

        Before saving, runs a defensive dedup pass to remove any duplicate
        procedures that slipped through an overridden discovery method.
        This acts as a safety net so that even dimension scripts that bypass
        ``discover_procedures()`` produce deduplicated results.
        """
        if filename is None:
            filename = f"{self.dimension.lower()}_results.yaml"

        # --- Defensive dedup: remove duplicate procedures ---
        seen_procedures: set = set()
        deduped: List[Dict[str, Any]] = []
        for r in results:
            proc = r.get("procedure", "")
            if proc and proc in seen_procedures:
                logger.debug(
                    "Defensive dedup: dropping duplicate result for '%s' in %s",
                    proc, self.dimension,
                )
                continue
            seen_procedures.add(proc)
            deduped.append(r)
        results = deduped

        summary = {
            "total": len(results),
            "passed": sum(1 for r in results if r["status"] == "PASS"),
            "failed": sum(1 for r in results if r["status"] == "FAIL"),
            "warnings": sum(1 for r in results if r["status"] == "WARN"),
            "skipped": sum(1 for r in results if r["status"] == "SKIP"),
        }
        effective = max(summary["total"] - summary["skipped"], 1)
        summary["pass_rate"] = round(summary["passed"] / effective * 100, 1)

        output = {
            "dimension": self.dimension,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "summary": summary,
            "tests": results,
        }

        output_path = self.output_dir / filename
        with open(output_path, "w", encoding="utf-8") as fh:
            yaml.dump(output, fh, default_flow_style=False, sort_keys=False)

        logger.info(
            "Saved %d results to %s (pass rate: %.1f%%)",
            len(results),
            output_path,
            summary["pass_rate"],
        )

        # Also write per-procedure result files for test_case_link references
        dim_subdir = self.output_dir / self.dimension.lower()
        dim_subdir.mkdir(parents=True, exist_ok=True)
        for result in results:
            proc = result.get("procedure", "")
            if not proc:
                continue
            proc_file = dim_subdir / f"{proc}_result.yaml"
            with open(proc_file, "w", encoding="utf-8") as fh:
                yaml.dump(result, fh, default_flow_style=False, sort_keys=False)

        return output_path
