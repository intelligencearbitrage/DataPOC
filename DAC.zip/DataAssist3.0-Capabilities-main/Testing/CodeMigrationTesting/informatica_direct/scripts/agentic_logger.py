"""
Agentic Audit Logger — per-stage YAML log files for the refinement loop.

Creates a timestamped run directory under thoughts/logs/agentic/ and writes
one YAML file per stage: validation, refinement, human review, feedback
validation, accuracy progression, and run summary.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


class AgenticLogger:
    """Manages a single run directory and writes per-stage log files."""

    def __init__(self, scenario_root: Path, log_dir_rel: str = "thoughts/logs/agentic"):
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        self.run_dir = scenario_root / log_dir_rel / f"run_{ts}"
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self._stage_counter = 0
        self.start_time = datetime.now(timezone.utc)
        self.accuracy_progression: List[Dict[str, Any]] = []

    def _next_prefix(self) -> str:
        self._stage_counter += 1
        return f"{self._stage_counter:02d}"

    def _write(self, filename: str, data: Any) -> Path:
        path = self.run_dir / filename
        with open(path, "w", encoding="utf-8") as fh:
            yaml.dump(data, fh, default_flow_style=False, sort_keys=False, width=120)
        return path

    def log_validation(self, iteration: int, report: Dict[str, Any]) -> Path:
        prefix = self._next_prefix()
        return self._write(
            f"{prefix}_iteration_{iteration}_validation.yaml",
            {
                "stage": "validation",
                "iteration": iteration,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "overall_accuracy": report.get("overall_accuracy"),
                "issue_count": len(report.get("issues", [])),
                "passed_checks": report.get("passed_checks", []),
                "issues": report.get("issues", []),
            },
        )

    def log_refinement(self, iteration: int, result: Dict[str, Any]) -> Path:
        prefix = self._next_prefix()
        return self._write(
            f"{prefix}_iteration_{iteration}_refiner.yaml",
            {
                "stage": "refinement",
                "iteration": iteration,
                "timestamp": result.get("timestamp"),
                "patches_applied": result.get("patches_applied"),
                "files_modified": result.get("files_modified"),
                "issues_addressed": result.get("issues_addressed"),
                "flagged_for_review": result.get("flagged_for_review"),
                "diffs": result.get("diffs"),
                "feedback_applied": result.get("feedback_applied"),
            },
        )

    def log_human_review(self, iteration: int, choice: str, feedback: Optional[str] = None) -> Path:
        prefix = self._next_prefix()
        return self._write(
            f"{prefix}_human_review_{iteration}.yaml",
            {
                "stage": "human_review",
                "iteration": iteration,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "choice": choice,
                "feedback": feedback,
            },
        )

    def log_feedback_validation(
        self, iteration: int, feedback: str, is_valid: bool, explanation: str,
    ) -> Path:
        prefix = self._next_prefix()
        return self._write(
            f"{prefix}_feedback_validation_{iteration}.yaml",
            {
                "stage": "feedback_validation",
                "iteration": iteration,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "feedback": feedback,
                "valid": is_valid,
                "explanation": explanation,
            },
        )

    def record_accuracy(self, iteration: int, accuracy: float, label: str) -> None:
        self.accuracy_progression.append({
            "iteration": iteration,
            "accuracy": accuracy,
            "label": label,
        })

    def write_accuracy_progression(self) -> Path:
        if not self.accuracy_progression:
            return self.run_dir / "accuracy_progression.yaml"

        initial = self.accuracy_progression[0]["accuracy"]
        final = self.accuracy_progression[-1]["accuracy"]
        trend = "improved" if final > initial else ("regressed" if final < initial else "unchanged")

        return self._write(
            "accuracy_progression.yaml",
            {
                "initial_accuracy": initial,
                "final_accuracy": final,
                "trend": trend,
                "delta": round(final - initial, 2),
                "entries": self.accuracy_progression,
            },
        )

    def write_run_summary(
        self,
        total_iterations: int,
        final_accuracy: float,
        exit_reason: str,
        stale_issues: Optional[set] = None,
    ) -> Path:
        elapsed = (datetime.now(timezone.utc) - self.start_time).total_seconds()
        return self._write(
            "run_summary.yaml",
            {
                "start_time": self.start_time.isoformat(),
                "end_time": datetime.now(timezone.utc).isoformat(),
                "elapsed_seconds": round(elapsed, 1),
                "total_iterations": total_iterations,
                "final_accuracy": final_accuracy,
                "exit_reason": exit_reason,
                "stale_issues": sorted(stale_issues) if stale_issues else [],
                "log_directory": str(self.run_dir),
            },
        )
