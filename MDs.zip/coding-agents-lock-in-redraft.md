# Coding Agents Are Sold as a Productivity Story. The Renewal Is Where They Become a Lock-In Story.

If you read the coverage of Snowflake's Cortex Code and Databricks' Genie Code, you would think the story is faster pipelines, fewer hours, and happier engineers. All of that is true. None of it is the part that matters. The part that matters does not show up in a productivity benchmark. It shows up at renewal.

So I want to set the productivity framing aside and talk about what these agents are actually doing to the economics of staying on a platform. The pattern I keep seeing is the same on both sides, and it points the same direction.

These agents move the switching math from both ends at once. They lower the cost of moving onto a platform, and they raise the cost of leaving it. Cheaper to move in. Costlier to walk out. A team that adopts one is not buying a developer feature. It is quietly converting a vendor choice into infrastructure.

Snowflake and Databricks are both running this play. They are not benefiting from it in the same way, and the difference is worth understanding before you commit your own data estate to either one.

## Databricks needed this more.

Databricks has always rewarded teams that could write transformations in PySpark and orchestrate their own clusters. That is real power when you have the talent for it. Most organizations cannot staff for it, and that requirement has been the company's growth ceiling for years. It wins with the data engineering elite and stalls everywhere else.

Genie Code goes straight at that ceiling. It absorbs the Spark complexity, the cluster configuration, and the pipeline orchestration, so the platform becomes reachable for teams that could never staff their way in. The companies that walked away from a deep Databricks commitment usually did so because they could not find the people, not because they did not want to spend. Take that constraint away and the conversation shifts from "can we staff this" to "what can we build."

That shift shows up in the numbers. In February, Databricks reported crossing a $5.4 billion revenue run-rate, growing more than 65% year over year, with net retention above 140%. For a company at that scale, growth accelerating rather than flattening is the unusual part. Genie Code's job is to keep that door open for the teams that were locked out.

## Snowflake benefits from it more.

CoCo was never about developer access. SQL-native teams were never the thing holding Snowflake back. What CoCo does is take a governance model Snowflake has been building since 2012 and extend it into a new place, with a meter attached.

Here is the mechanism, and it is the part the coverage skips. CoCo does not just help someone write SQL faster. Every operation it runs executes under the customer's existing Snowflake role-based access controls, inside the security perimeter, and consumes Snowflake credits. As a team puts CoCo to work across more of its pipeline, its baseline consumption forecast moves up. At the next renewal, the customer commits to a higher credit floor to protect its pricing. That floor is contracted future revenue. It lands directly in remaining performance obligations.

Snowflake reported RPO of $9.77 billion in its most recent quarter, up 42% year over year, against net retention of 125%. RPO is the number that tells you how much future revenue is already locked under contract. When an agent is the thing driving baseline consumption up, it is also, indirectly, the thing pushing that number higher.

## Why this is a valuation event, not a productivity one.

The reported time savings from these agents are real, and they are not incremental. They look less like engineers working faster and more like a change in what one engineer can own. That is genuinely useful. It is also not what moves the people who decide whether a platform commitment grows or gets unwound.

> [INSERT RENEWAL SCENE HERE. One real engagement, anonymized. The renewal where CoCo or Genie adoption was already in production and you watched the lock-in argument land on a CFO or CDO. What they said. What number moved. This is the paragraph that makes the piece yours instead of analysis anyone could write. Without it, the section below is true but theoretical.]

The pattern I keep seeing in renewal conversations is that the question that actually moves a CFO is never the productivity benchmark. It is one question: what happens to us if we leave? When an agent has been encoding the schemas, managing the lineage, and writing the governance model into every automated workflow for a year or more, that question stops having a clean answer. The commitment stops reading like a purchase and starts reading like infrastructure. You do not rip out infrastructure to save a line item.

For Databricks, the same logic runs through the IPO it is widely expected to file later this year. With net retention above 140% and a $5.4 billion run-rate growing 65%, Genie Code's job in that story is to show the AI revenue is durable rather than a spike. Durable revenue is worth a real multiple in a pricing conversation.

## The same agents are lowering the cost of moving in.

The other half of the switching math is migration, and this is where the pressure on legacy platforms is about to get uncomfortable.

The reason legacy migration always stalled was the timeline. A multi-year program, a large integrator team, real execution risk at every step, and a budget committee that approves the assessment and then sits on the program. The slowest, most expensive phase was always the conversion work, and everyone built their schedule around it.

Both platforms have now built that conversion into their own tooling. Snowflake's SnowConvert AI converts from Oracle, Teradata, Redshift, and Sybase. Databricks' Lakebridge translates T-SQL, Redshift, Teradata, and Oracle into Databricks-compatible ANSI SQL. I am cautious about the percentage-faster claims the vendors publish, so I will say what I see in the field instead: the conversion work that used to define the critical path is no longer the part that takes the time.

When the slowest phase of a migration becomes one of the quickest, the case for staying on legacy stops holding. The cost of moving drops. The cost of waiting, paid in AI capability you cannot deliver, climbs. If your modernization program is still scoped on last year's numbers, it is probably already wrong, and probably too cautious. The pressure is no longer coming from a vendor account team. It is coming from your own AI roadmap running into the data foundation underneath it.

## Which is not a contest. Most enterprises run both.

The framing everyone reaches for is Snowflake versus Databricks. That is not what I see in the accounts. Most large enterprises run both. Snowflake holds the governed analytics and the regulated sharing. Databricks holds the ML engineering and the heavy Python work. Both have been true at once for years.

What the agents change is not who wins. It is how deep each one sits in the companies running both. A team using CoCo for governed SQL and Genie Code for ML pipelines is not picking a side. It is encoding both platforms into every workflow it automates. The switching cost compounds on two fronts at the same time. The threat almost nobody is watching is Microsoft, which does not need to win the open market. It needs to win the renewal conversation inside the companies already living in its productivity stack, and that is a very different game.

## The governance gap nobody is pricing yet.

I have written before that agentic AI did not create the governance problem. It removed the buffer that was hiding it. This is where that shows up next.

In its Lakebase service, Databricks reports that AI agents now create roughly four times more databases than human users. Read that as a leading indicator rather than a universal statistic, but the direction is the point. Agents are producing data assets at a rate no catalog steward, no data contract process, and no lineage tool was built to keep up with.

This is where the two governance models diverge, and where the difference will be felt at the worst possible moment. In Snowflake, agents run under the same access controls as humans, with visibility into every active agent and its policy status, because that model was there from the start. Databricks is building Unity Catalog toward the same place. Where the governance came from matters when a CISO has to sit in an incident review and explain exactly what an agent touched, with what permission, and what the audit trail says.

Which platform you choose is the easy question. The harder one is whether the data underneath it is ready for what these agents are about to do to it, at a speed and volume your current controls were never designed to absorb.

That is the question worth taking into your next renewal. Not how fast the agent codes. What it is quietly making impossible to walk away from, and whether you can defend the data it is building on when someone finally asks.
