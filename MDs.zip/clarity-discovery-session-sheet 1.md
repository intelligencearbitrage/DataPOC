# Project Clarity — Discovery Session Sheet
**60 minutes · one mock client · one job: leave with three things**

> **Revised after reviewing the actual CVS data.** The sample set is 31 *customer advocacy testimonials* (not internal training videos), all positive, mostly under a minute, already transcribed, with topic tags applied upstream. That reading changes three things below — flagged with **▸ data-driven**. The disarm, the skepticism block, and the kill switch are unchanged.

You succeed if you walk out able to state, in one sentence each:
1. **What they are skeptical about, and why.**
2. **What the minimum credible prototype is** — the smallest build that honestly answers their question.
3. **The data decision** — whether to supplement a tiny, all-positive set, and what that does to credibility.

Everything below serves those three. If a question does not, cut it in the room.

---

## Open (first ~3 min) — disarm before anything else

Say a version of this out loud, early:

> "Before we dig in, we want to be clear what this hour is for. We are not here to convince you AI works. We are here to find out whether it actually works for your library and your people. A 'no' is a real result we would report honestly. So we are going to spend most of our time asking you where you think this is most likely to fall short."

This is the single highest-leverage thing you do all session. A skeptic opens up when they hear you are not selling.

---

## Establish the room (~5 min)

- Who owns the go/no-go decision on a production investment?
- What is each of you closest to — the budget, the library, or the staff who use it?

You have three names and no roles. Find the economic buyer, the user voice, and the skeptic fast. They may not be the same person.

---

## ▸ Reconcile the content (~3 min) — *data-driven; do this before scoping anything*

We have already reviewed the sample set. Say so, then confirm the use case rather than assume it:

- "The videos we received are customer testimonials — people describing good experiences at CVS. Is that the content this tool is really for, or is there a separate library of staff training videos we haven't seen?"
- "Who actually goes looking for these, and why — someone building a campaign, or a rep mid-shift?"

If the content really is testimonials for advocacy/marketing use, the brief's "customer service staff find training" framing shifts — and so does every question below. Resolve this first.

---

## Block 1 — The skepticism (~20 min, the heart of the hour)

- If you had to bet, where do you think this is most likely to fall short?
- Has anyone tried to solve this before? What happened?
- What would make you trust a result the tool gives you?
- What result, at the end of this, would tell you it is *not* worth funding? *(makes "no" safe, surfaces the real bar)*

## Block 2 — Minimum credible prototype (~15 min)

- Walk me through the last time someone could not find a video they needed. What happened next?
- If the prototype did only one thing well, what is the one search scenario that would convince you?
- The 15-minutes-to-an-hour figure — is that measured, or is it a sense people have? *(the data shows no usage telemetry behind it — find out if a baseline even exists)*
- Which users can we actually talk to or watch?

## ▸ Block 3 — Data reality & ground truth (~9 min) — *data-driven; rewritten*

We have seen the set: 31 curated testimonials, all positive, mostly under a minute, already transcribed, with topic tags applied somewhere upstream. Don't ask what's in it — pressure-test what it means:

- "Some of these already carry topic tags — *Empathy & Personalization*, *Ownership & Follow-Through*. Who applied those, and would the people searching actually agree with them?" *(this is your eval ground truth — its credibility lives or dies here)*
- "The set is entirely positive stories. Is that what staff search for, or do they also need to find harder or negative cases?"
- "Thirty-one videos — is that the whole library, a sample, or a curated highlight reel?" *(governs whether any result generalizes)*
- "If we supplemented with outside video to show scale, would that mean anything to you, or would you discount a non-CVS result?"

## Close (~5 min)

Recap the three things back to them. Say the minimum-prototype definition out loud and get a nod or a correction. Confirm who you contact next and for what.

---

## STOP doing these

- **Stop re-asking the scope boundaries and that search is broken.** The brief settled those. **▸ But *do* confirm who the users actually are** — the content suggests the brief's "two user groups" may be wrong, and that's worth the airtime.
- **Stop asking what's in the data set.** ▸ You've already reviewed it. Asking makes you look like you didn't open the files. Validate your reading instead.
- **Stop selling AI.** The moment you pitch capability, a skeptic closes.
- **Stop collecting requirements you will not build.** This is a POC scoped to one question.
- **Stop running the list.** If they say something real, drop the script and follow it. The script is a safety net, not the plan.

---

## Kill switch

At the **25-minute mark**, if you still cannot say in one sentence what they are skeptical about and why, **abandon Blocks 2 and 3** and spend the rest of the hour only on the skepticism. Scoping a prototype without understanding the skepticism is the documented failure mode of this engagement. Better to leave with one thing fully understood than three things half-guessed.

---

## Timing check

3 (open) + 5 (room) + 3 (reconcile) + 20 (skepticism) + 15 (prototype) + 9 (data) + 5 (close) = **60 min.** The reconcile probe is paid for by tightening Block 3 — validation runs faster than blind discovery.

---

*One page on purpose. The brief warns against over-building the prototype. A forty-question script is the over-built prototype of a discovery call.*
