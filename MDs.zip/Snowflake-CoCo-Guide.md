# Snowflake CoCo — A Complete Guide

*Snowflake's data-native AI coding agent. Current as of June 2026 (post–Snowflake Summit 26).*

---

## 0. Read this first: what changed

If you've read an older write-up, two facts upend most of it:

1. **The product was renamed.** "Cortex Code" is now **CoCo**. Same architecture, same workflows, new name — the rename signals a broader push into AI-powered development inside Snowflake. The official documentation at `docs.snowflake.com` still uses the "Cortex Code" path and labels in many places, so treat the two names as interchangeable. CoCo, paired with Snowflake CoWork, is positioned as an *agentic control plane* for managing and orchestrating agent behavior.

2. **The standalone desktop app is real.** Older guides insisted there was "no standalone Cortex Code Desktop application" and that the desktop experience was just the CLI running inside VS Code. That is no longer true. **CoCo Desktop** is a native macOS/Windows IDE, now in **open preview** and available to all accounts, with direct download links from Snowflake. It is a distinct surface, not a wrapper around the terminal.

Both points were confirmed at **Snowflake Summit 26 (June 2, 2026)**, where CoCo expanded from "an AI coding agent" into a full AI development platform spanning desktop, CLI, browser, IDE extensions, Slack and mobile (the last two coming soon), plus a programmatic SDK.

---

## 1. What CoCo actually is

CoCo is an AI coding agent purpose-built for the data lifecycle — data engineering, analytics engineering, ML, and agent-building — that runs *inside* the Snowflake security and governance perimeter. The pitch is simple to state and hard to build: a coding agent that knows your data the way a generic coding agent knows your codebase.

The distinction that matters: generic coding agents (Claude Code, Codex, etc.) can produce SQL and pipeline code that *looks* correct but fails in production because it has no grounding in your live schemas, permissions, lineage, or compute. CoCo is grounded from the first prompt because it reads your catalog, lineage, and RBAC policies, so the code it generates references real objects with the correct permissions. Snowflake calls this an "agent harness designed for data, not just code" — meaning native tooling such as semantic catalog search, data diffing, and sandboxed runtimes rather than a thin wrapper that falls back to bash for everything.

On dbt Labs' **ADE-Bench** (a benchmark for AI agents on real analytics/data-engineering tasks), Snowflake reports CoCo passing 72.1% of tasks versus 65.1% for both Claude Code and OpenAI Codex, while using roughly half the tokens and slightly less time than Claude Code on Opus. Two design choices drive the efficiency: targeted navigation to relevant data instead of scanning everything, and a native-tools approach (Snowflake, dbt, Airflow) instead of bash-based workflows. Treat vendor benchmarks as directional, not gospel — but the architectural reasoning behind them is sound.

Snowflake reports more than 7,100 customers building with CoCo, with named references including Thomson Reuters, Fanatics, WHOOP, Shelter Mutual Insurance, and United Rentals.

---

## 2. The surfaces: where CoCo runs

CoCo is deliberately multi-surface. The same core agent — same grounding, same governance — is exposed through several entry points so you can work where you already are.

| Surface | Status | What it is | Best for |
|---|---|---|---|
| **CoCo Desktop** | Open preview | Native macOS/Windows IDE: file editor, integrated terminal, agentic AI loop, agentic browser, agentic notebook | Full end-to-end development on data in one governed surface |
| **CoCo CLI** | Generally available | Terminal-native agentic shell connecting your local environment to Snowflake | Local dev, scripting, automation, CI/CD |
| **CoCo in Snowsight** | Generally available | Persistent web agent inside Workspaces, Notebooks, and Admin pages | SQL/notebook work, data discovery, account admin — zero install |
| **CoCo Extensions** | Available / preview | CoCo inside your existing IDE (VS Code extension, Claude Code plugin, or any of 30+ editors via ACP) | Staying in your current toolchain |
| **Cloud Agents** | GA in Snowsight | Snowflake-managed cloud containers that give Snowsight sessions full CLI-grade power with no local setup | Long-running, autonomous, browser-based agentic work |
| **Slackbot** | Coming soon | Governed CoCo interface inside Slack | Asking questions, triggering workflows, sharing results in chat |
| **Mobile app (iOS/Android)** | Coming soon | Agent interface for monitoring, review, and approval on the go | Data leaders/managers approving workflows and inspecting pipelines away from the desk |

A useful mental model: **Cloud Agents** are the engine for the platform's expansion. Automations, the Slackbot, and the mobile app are all powered by Cloud Agents — long-running, autonomous workflows running in isolated Snowflake-managed containers rather than on your laptop.

---

## 3. CoCo Desktop (the part most older guides got wrong)

CoCo Desktop is a native application for macOS and Windows that brings CoCo's full agentic capability into an IDE-like surface. It is in **open preview, available to all accounts**.

### What's in it

- **Agent mode and Editor mode.** Switch between an autonomous agent that completes multi-step tasks and a focused editor mode for reviewing and applying AI suggestions.
- **Plan mode.** Plan a multi-step or higher-risk operation before implementing it, confirming actions before they run.
- **Local file access.** Read and write local repositories — ideal for dbt projects, Streamlit apps, and other local codebases.
- **SQL Playground.** Run and explore SQL interactively.
- **Data visualization.** Inline charts generated directly from query results.
- **Agentic browser.** Browse and interact with web content from inside the IDE (e.g., pulling external context).
- **Agentic notebook.** Jupyter-style notebooks with AI assistance.
- **Building apps.** Scaffold and deploy Streamlit and Snowflake App Runtime apps.
- **dbt integration.** Build, test, and deploy dbt models.
- **Automations.** Schedule recurring agent workflows (pipeline refreshes, data-quality checks, model retraining, operational investigations) — governed by RBAC and backed by audit trails.
- **Extensibility.** Plugins, Skills, Hooks, Instruction files, and MCP support (covered in §7).
- **Permission modes.** Control what the agent can do without asking.
- **Usage history view.** Monitor usage and token consumption.
- **Managed settings.** Central configuration for an organization-wide rollout.

### Models

The Desktop app uses the Cortex LLMs your account can access. A **model picker** in the chat input shows what's currently available to you and is the authoritative, always-current list. The lineup includes Claude and OpenAI GPT models and changes as new models ship, so rely on the picker rather than memorizing a list. Availability depends on your region, your `CORTEX_MODELS_ALLOWLIST`, and your cross-region inference setting (see §9).

### Installation

Download installers from Snowflake's limited-access page (`snowflake.com/en/product/limited-access/cortex-code/`). Direct builds exist for:

- **macOS** — Apple Silicon (`arm64`) and Intel (`x64`) `.dmg`
- **Windows** — Intel/AMD (`x64`) and ARM (`arm64`), each in **User** and **System** installer variants

You need a Snowflake account with Cortex Code enabled. On first launch, choose **Sign in with SSO** and authenticate through your organization's identity provider; CoCo establishes the secure connection automatically with no config-file editing. Sessions run locally — closing the app pauses active sessions, and you resume them on reopen.

---

## 4. CoCo CLI

The CLI is **generally available** and is the agentic shell for power users — it bridges your local environment (VS Code, Cursor, a bare terminal) to your Snowflake account.

### Installation

**macOS, Linux, and WSL:**
```bash
curl -LsS https://ai.snowflake.com/static/cc-scripts/install.sh | sh
```
Installs the `cortex` executable to `~/.local/bin` and adds it to your PATH.

**Windows (native PowerShell):**
```powershell
irm https://ai.snowflake.com/static/cc-scripts/install.ps1 | iex
```
Installs to `%LOCALAPPDATA%\cortex` and adds it to your PATH. Invoke it from Run (Win+R), `cmd.exe`, or PowerShell.

### Connect

Run `cortex`. A setup wizard walks you through connecting to Snowflake. The first prompt offers existing connections from `~/.snowflake/connections.toml` or lets you create a new one. This is the **same `connections.toml` the Snowflake CLI (`snow`) uses** — if you've already configured `snow`, that connection works here.

### Prerequisites

- A Snowflake user with permissions on the data you'll use, **plus the `SNOWFLAKE.CORTEX_USER` database role** (granted to `PUBLIC` by default, but your org may have revoked it for stricter control).
- Network access to your Snowflake server.
- The **Snowflake CLI** installed on your workstation.
- A supported platform: macOS (arm64/x64), Linux (x64/arm64), WSL on x64, or Windows native on x64.
- Local access to `bash`, `zsh`, or `fish`.

### Key features

Direct Snowflake integration (execute SQL, browse tables, validate Cortex Analyst semantic models, manage multiple connections); local file read/write; tool orchestration (`bash`, `git`, SQL); agent customization via `AGENTS.md` and Skills; built-in Snowflake skills for agent creation, ML, data engineering, and governance; extensibility via custom tools, skills, subagents, hooks, and profiles; and developer-friendly touches — session persistence, `git` worktree support, compact/expanded display modes, color themes, and `vim`-style navigation.

### Security in the CLI specifically

RBAC enforcement, **OS-level sandboxing**, a **three-tier approval system**, and **automatic risk assessment**. In plan mode, the agent asks you to confirm each action.

### Try-it-now prompts

```text
What databases do I have access to?
List every table tagged PII = TRUE in ANALYTICS_DB
Show the lineage from RAW_DB.ORDERS to downstream dashboards
Write a query for top 10 customers by revenue, then add a 7-day moving average
Build a Streamlit dashboard on SALES_MART.REVENUE with filters for date and region
Use the @models/revenue.yaml semantic model to answer "What was revenue last month?"
```

---

## 5. CoCo in Snowsight (+ Cloud Agents)

CoCo in Snowsight is **generally available** to Commercial (non-Gov), FedRAMP (Moderate/High), and KSA sovereign accounts with cross-region inference enabled. It's the persistent, zero-install web entry point, integrated into Workspaces and Admin pages.

Capabilities: generate SQL and Python from natural language, or explain/optimize existing code; take action and answer questions on credit consumption, query performance, governance, and permissions (account administration); context awareness of the SQL file or notebook you're viewing; and a visual **diff view** to review and accept changes before they apply.

**Cloud Agents** upgrade this from a chat panel into a full runtime. When enabled, each Snowsight session can spin up an isolated, Snowflake-managed container behind the scenes — giving you CLI-grade power from any browser with no local setup, dependency management, or infrastructure. The container can run shell commands and Python, install packages, read/write files, perform dbt builds and tests using a dynamically generated Snowflake profile, and search the web for context.

---

## 6. Extensions and IDE integration

CoCo no longer depends on you opening a terminal inside your editor. It plugs into your existing tools three ways:

- **CoCo extension for VS Code** — data-native agentic coding inside VS Code.
- **CoCo plugin for Claude Code** — run CoCo from within Claude Code.
- **Agent Client Protocol (ACP)** *(preview)* — an open standard that lets editors and IDEs (Zed, JetBrains, VS Code, Neovim, and 30+ editors total) embed CoCo as a local agent backend. The editor drives the session; CoCo streams responses, tool calls, and file diffs back.

This is a meaningful shift from the old "just run the CLI in the integrated terminal" story. The CLI-in-terminal pattern still works, but it's now one option among several.

---

## 7. Customization and extensibility

CoCo's behavior is shaped by a layered set of mechanisms. Same concepts work across CLI and Desktop.

### Instruction files (`AGENTS.md`)

A Markdown file (with optional YAML frontmatter) at your project root that gives the agent persistent, project-specific rules it follows for every interaction in that project. Use it to set coding/naming conventions, define a persona ("act as a senior data engineer"), document directory structure and key data sources, and point the agent at available Skills. You can place `AGENTS.md` files in subdirectories; they merge with the root file for granular control in a monorepo.

Keep it tight. Too many rules dilute compliance — combine soft guidance in `AGENTS.md` with hard enforcement through Hooks and Snowflake's native RBAC.

A representative structure:
```markdown
---
name: dbt-finance-expert
description: Assists with the finance dbt project.
tools:
  - snowflake_sql_execute
  - file_read
  - file_write
---

# Agent guidelines for the finance dbt project

You are an expert data engineer specializing in dbt and financial data modeling.

## What to do
- Staging models: cast all timestamps, rename columns to snake_case.
- Add not_null and unique tests to all primary-key columns.
- Generate a description for every new model and column in the .yml file.

## What not to do
- Never hardcode table names — always use ref() or source().
- Avoid giant CTEs in one model; split into intermediate models.
```

### Skills

Reusable instruction packs (Markdown, typically `SKILL.md`) that encode the "right way" to do a recurring, multi-step task. CoCo ships **built-in Snowflake skills** — catalog search, generating and running SQL, parsing dbt projects, dataset comparison and output validation — and selects/coordinates them automatically; you describe what you want in natural language and rarely invoke them by hand. You can also author custom Skills. A Skill's instructions are injected into the main conversation and run sequentially within your session.

### Subagents

Specialized, autonomous agents that run in their **own isolated context** — the key difference from a Skill, which runs inline. Subagents are good for parallelizing focused work (profile a source, optimize a model, and check credit consumption at once). Define them as Markdown + YAML frontmatter in a project-local `.cortex/agents/` directory or a global `~/.snowflake/cortex/agents/`. List them in a session with `/agents`; launch one with an explicit instruction like *"Launch a data-quality-inspector agent to profile all tables in FINANCE_DEMO.RAW."*

### Hooks

Scripts that run on lifecycle events (e.g., session start) — the mechanism for hard, deterministic enforcement that complements the soft guidance of instruction files.

### Plugins *(preview)*

A self-contained package bundling Skills, subagents, slash commands, hooks, and MCP servers under a single manifest (`plugin.json` under a `.cortex-plugin/` path). Share them across a team from a Git repo, install from the official marketplace, or ship them in a Snowflake connection profile. CoCo auto-discovers standard subdirectories (`skills/`, `commands/`, `agents/`) if not explicitly declared.

---

## 8. Build on CoCo programmatically

### CoCo Agent SDK *(preview)*

The Agent SDK packages the same tools and agent loop that power CoCo as an installable library, in **Python and TypeScript**. Your agents get direct programmatic access to CoCo's production capabilities: working with data, querying Snowflake, reading files, running shell commands, searching codebases, executing SQL, and editing code — with tool execution built in, so you don't reimplement that infrastructure.

```javascript
import { query } from "cortex-code-agent-sdk";

for await (const message of query({
  prompt: `Profile the ORDERS table in MY_DATABASE.ANALYTICS:
    - Total row count and date range
    - Null rate for each column
    - Top 5 customers by order volume
    Summarize findings in plain English.`,
  options: { cwd: process.cwd(), connection: "my-connection" },
})) {
  if (message.type === "assistant") {
    for (const block of message.content) {
      if (block.type === "text") process.stdout.write(block.text);
    }
  }
  if (message.type === "result") console.log("\nDone:", message.subtype);
}
```

```python
import asyncio
from cortex_code_agent_sdk import query

async def main():
    async for message in query(
        prompt="""Profile the ORDERS table in MY_DATABASE.ANALYTICS:
        - Total row count and date range
        - Null rate for each column
        - Top 5 customers by order volume
        Summarize findings in plain English.""",
        options={"cwd": ".", "connection": "my-connection"},
    ):
        if message["type"] == "assistant":
            for block in message["content"]:
                if block["type"] == "text":
                    print(block["text"], end="", flush=True)

asyncio.run(main())
```

Beyond the built-in tools, the SDK supports multi-turn stateful sessions, structured (schema-validated JSON) output, MCP server integration, hooks for intercepting agent behavior at each step, streaming output, and custom system prompts. Call it from pipeline scripts, backend services, or internal apps; integrate it into CI/CD; or build data products on top of it.

### Model Context Protocol (MCP) *(preview)*

CoCo implements MCP — the open standard for connecting agents to external tools and data such as GitHub, Jira, Google Workspace, internal APIs, and databases. Add an MCP server once and its tools become available in every CoCo session. Configure in **Agent settings > MCP Servers**, or have an admin enable account-level connectors.

### Agent Client Protocol (ACP) *(preview)*

The flip side of MCP: ACP lets editors embed CoCo as a backend (see §6).

### Async API and Automations

CoCo can be embedded into agents and automated workflows via an **Async API**. **Automations** turn one-off prompts into scheduled, autonomous jobs (pipeline refreshes, quality checks, retraining, investigations), all under RBAC with audit trails — powered by Cloud Agents so they keep running when you're away from your machine.

---

## 9. Models and regions

CoCo runs on Cortex-hosted LLMs. Snowflake recommends setting the model to **`auto`**, which selects the highest-quality model available to your account and upgrades automatically as better models ship. To pin a model, use the `/model` command in a CLI session or the model picker in Desktop/Snowsight.

The documented CLI model set (identifiers in code):

| Model | Identifier |
|---|---|
| Auto (recommended) | `auto` |
| Claude Opus 4.6 | `claude-opus-4-6` |
| Claude Sonnet 4.6 | `claude-sonnet-4-6` |
| Claude Opus 4.5 | `claude-opus-4-5` |
| Claude Sonnet 4.5 | `claude-sonnet-4-5` |
| Claude Sonnet 4.0 | `claude-4-sonnet` |
| OpenAI GPT 5.2 | `openai-gpt-5.2` |

The exact lineup changes as models are released (Snowflake's marketing pages have referenced still-newer Claude and GPT versions), and what *you* can pick depends on region, your `CORTEX_MODELS_ALLOWLIST`, and cross-region inference. Trust the picker / `auto` over any fixed list, including this one.

**Cross-region inference.** If a model isn't available in your region, an `ACCOUNTADMIN` enables cross-region inference:
```sql
ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'AWS_US';
```
Rough guidance: `AWS_US` for the best Claude Opus experience, `AWS_EU` / `AWS_APJ` for regional Claude access, `AZURE_US` for OpenAI GPT, and `ANY_REGION` for best-effort global routing to all models.

---

## 10. Governance and security

This is CoCo's central selling point versus generic agents, so it's worth being precise.

- **Everything runs under your RBAC.** The agent acts as *you* — it cannot read data or perform actions your role isn't authorized for. There's no privileged backdoor.
- **Inference stays inside Snowflake's perimeter.** LLM calls don't leave Snowflake's security boundary.
- **Layered guardrails** help protect against prompt injection and other LLM-specific risks.
- **Human-in-the-loop approval.** A three-tier approval system (CLI) and a diff view (Snowsight/Desktop) put proposed changes in front of you before they execute. Plan mode forces confirmation of each step.
- **OS-level sandboxing** on the CLI; **permission modes** on Desktop to control what runs without asking.
- **Auditability.** Prompt and response logging, query tagging, usage monitoring, and admin-level cost and configuration controls.
- **Managed settings** let an org centrally configure the Desktop app for a controlled rollout.

For a regulated-environment rollout, the practical stack is: RBAC for hard data boundaries → managed settings + permission modes for what the agent may do unattended → `AGENTS.md` + Hooks for behavioral standards → query tagging + logging for audit.

---

## 11. Pricing and billing

CoCo is billed on **token consumption**. Two billing models apply to both CLI and Desktop:

- **Subscription** — individual developers who sign up at `signup.snowflake.com/cortex-code` get a 30-day free trial with a fixed usage allotment, then convert to a paid subscription (a fixed monthly usage amount) unless cancelled. Exceeding the included usage blocks access until the next billing period. The self-service trial includes $40 in inference credits for the first 30 days, after which a $20/month subscription fee applies.
- **Pay-as-you-go** — companies with an existing Snowflake account (on-demand or capacity) are billed by token consumption.

CoCo in Snowsight is billed by token consumption for existing-account customers. Any compute or storage you consume separately (virtual warehouses, storage) is billed at standard Snowflake on-demand rates. Admins can set **daily credit usage limits** for CoCo users. Always check Snowflake's current pricing and the Service Consumption Table for exact rates.

---

## 12. Worked examples

These natural-language workflows apply across CLI and Desktop. CoCo translates each into Snowflake-native tool calls, shows its reasoning, and asks for confirmation on risky steps.

### Build and deploy a Streamlit-in-Snowflake app
```text
1. "Create a Streamlit app to analyze customer churn. Add a title, a short
    description, and a chart placeholder. Generate the script and requirements.txt."
2. "Using the #SALES_MART.REVENUE table, write a function that returns churn data
    as a Pandas DataFrame."
3. "Add a multi-select to filter by CONTRACT_TYPE and a slider for TENURE; update
    the chart on selection."
4. "Create an internal stage named streamlit_assets, then deploy the app named
    Churn_Analysis_App from the current directory."
```

### End-to-end dbt project
```text
1. "Read the tables in FINANCE_DEMO.RAW and build a dbt project with staging,
    intermediate, and mart layers. Follow the naming and surrogate-key rules in
    my AGENTS.md. Write sources.yml and schema.yml with tests and column docs."
2. "Find models with gaps in test coverage and add not_null/unique/accepted_values
    tests where they're missing."
3. "Generate documentation for fct_monthly_revenue and each of its columns."
4. "Run a build, validate the output, and produce a shareable HTML summary."
```

### Orchestrate an Airflow pipeline
```text
1. "Create an Airflow DAG 'daily_sales_pipeline' that runs daily with a start and
    end task."
2. "Add a task that runs the Snowflake query in transform_sales.sql, then a task
    that loads the result into a summary table."
3. "Set dependencies: start >> transform_sales >> load_summary >> end."
4. "Why did daily_sales_pipeline fail yesterday? Show the failed task's logs."
```

---

## 13. Quick reference: choosing a surface

| If you want to… | Use |
|---|---|
| A full IDE with editor, terminal, browser, and notebooks in one place | **Desktop** |
| Script, automate, or wire CoCo into CI/CD | **CLI** |
| Quick SQL/notebook help or account admin with zero install | **Snowsight** |
| Stay in VS Code / JetBrains / Zed / Neovim | **Extensions (ACP)** |
| CLI-grade power from a browser with no local setup | **Cloud Agents (in Snowsight)** |
| Long-running scheduled jobs that keep going when you're offline | **Automations** |
| Trigger workflows or ask questions from chat | **Slackbot** *(coming soon)* |
| Approve workflows / monitor pipelines on the go | **Mobile app** *(coming soon)* |
| Embed CoCo's agent loop in your own software | **Agent SDK** *(preview)* |

---

## Status legend

Per Snowflake's labeling at time of writing: **GA** — CoCo CLI, CoCo in Snowsight, Cloud Agents in Snowsight. **Open preview** — CoCo Desktop. **Preview** — Agent SDK, MCP support, ACP support, Plugins. **Coming soon** — Slackbot, mobile app. Feature status changes frequently; verify against the docs before you commit to a rollout.

## Primary sources

- Snowflake CoCo product page — `snowflake.com/en/product/snowflake-coco/`
- "Snowflake CoCo: The Coding Agent Built for Data Now Available Where You Work" (blog, Jun 2, 2026)
- Cortex Code documentation — `docs.snowflake.com/en/user-guide/cortex-code/cortex-code`
- Cortex Code Desktop docs — `docs.snowflake.com/en/user-guide/cortex-code/cortex-code-desktop`
- Cortex Code CLI docs — `docs.snowflake.com/en/user-guide/cortex-code/cortex-code-cli`
- Cortex Code Agent SDK docs — `docs.snowflake.com/en/user-guide/cortex-code-agent-sdk/cortex-code-agent-sdk`
- Summit 26 press release and CoCo Foundations developer guide
