# SnowPrism HOL — Cortex Code Hands-On Lab Guide

> **You are an attendee.** Instead of writing SQL by hand, you will use **Cortex Code** (the AI assistant in Snowsight, Desktop, or CLI) to build the entire SnowPrism FinOps pipeline step by step using natural-language prompts.

---

## What you'll build

1. **R1 — Credit Visibility:** synthetic metering data, tenant mapping, 3 self-refreshing dynamic tables, and a budget summary view.
2. **R2 — Conversational FinOps:** a semantic view over your R1 pipeline, enabling natural-language Q&A with Cortex Analyst.

Everything lives in **one** schema you already own (`DELOITTE_COCO_LAB.BUILDER_XXX`). You never create a database.

---

## How to use this guide

- Each numbered step contains a **prompt** (in a quote block) that you type into the Cortex Code chat panel.
- Cortex Code will generate and execute SQL for you. Review the output before moving on.
- Steps build on each other — complete them in order.
- If Cortex Code asks a clarifying question, answer it based on the context provided in that step.

---

## Pre-requisites

- Access to a Snowflake account with the `HOL_BUILDER` role
- Your assigned builder number (e.g., `007`, `012`, `073`)
- Your assigned group warehouse (based on your builder number):
  - **BUILDER_001 – 040:** `COMPUTE_WH_GRP1`
  - **BUILDER_041 – 080:** `COMPUTE_WH_GRP2`
  - **BUILDER_081 – 120:** `COMPUTE_WH_GRP3`
  - **BUILDER_121 – 160:** `COMPUTE_WH_GRP4`
- Cortex Code available via one of:
  - **Snowsight** (browser) — Cortex Code chat panel on the left
  - **Cortex Code Desktop** (IDE) — chat panel
  - **Cortex Code CLI** — terminal

---

## Round 1 — Credit Visibility Pipeline

### Step 1: Set your session context

> **Prompt:**
> Set my session context to use role HOL_BUILDER. Detect my current username with SELECT CURRENT_USER() — it will be BUILDER_XXX. Use that to set my schema to DELOITTE_COCO_LAB.BUILDER_XXX. For the warehouse, pick the correct group warehouse based on my number: BUILDER_001–040 use COMPUTE_WH_GRP1, 041–080 use COMPUTE_WH_GRP2, 081–120 use COMPUTE_WH_GRP3, 121–160 use COMPUTE_WH_GRP4. After setting context, run SELECT CURRENT_ROLE(), CURRENT_WAREHOUSE(), CURRENT_SCHEMA() to confirm. The schema MUST NOT be NULL or 'NONE' — if it is, run USE SCHEMA explicitly.

> **IMPORTANT:** If Cortex Code shows `CURRENT_SCHEMA() = NULL`, paste this follow-up:
> "My schema is NULL. Run USE SCHEMA DELOITTE_COCO_LAB.BUILDER_XXX where XXX matches my CURRENT_USER()."

**What to expect:** Cortex Code detects your username, determines your group warehouse, and runs the appropriate `USE ROLE`, `USE WAREHOUSE`, and `USE SCHEMA` statements. You should see all three confirmed with non-NULL values. If schema shows NULL, use the follow-up prompt above.

---

### Step 2: Verify your session context

> **Prompt:**
> Show me my current role, warehouse, and schema to confirm I'm in the right place

**What to expect:** You should see `HOL_BUILDER` as the role, your group warehouse (e.g., `COMPUTE_WH_GRP1`), and `DELOITTE_COCO_LAB.BUILDER_XXX` matching your username.

---

### Step 3: Create the sample metering history table

> **Prompt:**
> Create a table called SAMPLE_METERING_HISTORY with the following columns: WAREHOUSE_NAME (VARCHAR 256), START_TIME (TIMESTAMP_LTZ), END_TIME (TIMESTAMP_LTZ), CREDITS_USED (NUMBER 38,9), CREDITS_USED_COMPUTE (NUMBER 38,9), CREDITS_USED_CLOUD_SERVICES (NUMBER 38,9). Add a comment saying it mimics ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY. Use CREATE OR REPLACE.

**What to expect:** The table is created (or replaced if it already existed).

---

### Step 4: Populate the metering history with synthetic data

> **Prompt:**
> Insert 720 rows of synthetic data into SAMPLE_METERING_HISTORY. Generate 90 days of data (from today going back 90 days) for 8 warehouses: WH_MARKETING_ETL (base 3.0 credits), WH_MARKETING_BI (1.5), WH_FINANCE_CLOSE (2.0), WH_DATAENG_TRANSFORM (5.0), WH_DATAENG_INGEST (2.5), WH_SALES_ANALYTICS (1.8), WH_PLATFORM_OPS (2.2), WH_ADHOC_SANDBOX (0.8). Apply these rules: weekends get 35% of normal usage, add random variation between 60-140% of base, add a 6x spike for WH_DATAENG_TRANSFORM exactly 14 days ago, and a 5x spike for WH_FINANCE_CLOSE exactly 3 days ago. Split CREDITS_USED into 92% compute and 8% cloud services. Round to 3 decimal places. Make sure to use a lateral column alias so CREDITS_USED_COMPUTE and CREDITS_USED_CLOUD_SERVICES reference the CREDITS_USED column.

**What to expect:** 720 rows inserted (8 warehouses x 90 days).

---

### Step 5: Verify the seed data

> **Prompt:**
> Count the total rows and distinct warehouse names in SAMPLE_METERING_HISTORY

**What to expect:** ROW_CNT = 720, WAREHOUSES = 8.

---

### Step 6: Create the tenant registry table

> **Prompt:**
> Create a table called T_TENANT with columns TENANT_ID (VARCHAR 10), TENANT_NAME (VARCHAR 100), and MONTHLY_BUDGET_CREDITS (NUMBER 38,2). Add a comment 'Tenant registry'. Use CREATE OR REPLACE.

**What to expect:** Table created.

---

### Step 7: Populate the tenant registry

> **Prompt:**
> Insert 6 rows into T_TENANT with these values: T001/MARKETING/120, T002/FINANCE/80, T003/DATA_ENG/220, T004/SALES/70, T005/PLATFORM/100, T000/UNASSIGNED/0

**What to expect:** 6 rows inserted.

---

### Step 8: Create the warehouse-to-tenant mapping table

> **Prompt:**
> Create a table called T_WAREHOUSE_TENANT_MAP with these columns: WAREHOUSE_NAME (VARCHAR 256, NOT NULL), TENANT_NAME (VARCHAR 100, default 'UNASSIGNED'), TOTAL_CREDITS (NUMBER 38,2, default 0), FIRST_SEEN (TIMESTAMP_LTZ, default CURRENT_TIMESTAMP), LAST_UPDATED (TIMESTAMP_LTZ, default CURRENT_TIMESTAMP), MAPPED_BY (VARCHAR 100, default CURRENT_USER), MAPPED_AT (TIMESTAMP_LTZ, default CURRENT_TIMESTAMP), COMMENT (VARCHAR 500). Add a unique constraint on WAREHOUSE_NAME. Table comment: 'Explicit warehouse-to-tenant mapping'. Use CREATE OR REPLACE.

**What to expect:** Table created with the unique constraint.

---

### Step 9: Create a sync procedure to discover warehouses

> **Prompt:**
> Create a stored procedure called SP_SYNC_WAREHOUSE_TENANT_MAP that returns VARCHAR, uses SQL language, and executes as caller. It should MERGE into T_WAREHOUSE_TENANT_MAP using a source query that selects WAREHOUSE_NAME and SUM(CREDITS_USED) as TOTAL_CREDITS from SAMPLE_METERING_HISTORY grouped by WAREHOUSE_NAME. When matched, update TOTAL_CREDITS and LAST_UPDATED. When not matched, insert the warehouse with TENANT_NAME='UNASSIGNED' and COMMENT='Auto-discovered'. Return a message like 'Sync complete: N rows merged'. Use CREATE OR REPLACE.

**What to expect:** Procedure created.

---

### Step 10: Call the sync procedure

> **Prompt:**
> Call the SP_SYNC_WAREHOUSE_TENANT_MAP procedure

**What to expect:** Output like "Sync complete: 8 rows merged".

---

### Step 11: Assign warehouses to the MARKETING tenant

> **Prompt:**
> Update T_WAREHOUSE_TENANT_MAP to set TENANT_NAME to 'MARKETING' where WAREHOUSE_NAME is in ('WH_MARKETING_ETL', 'WH_MARKETING_BI')

**What to expect:** 2 rows updated.

---

### Step 12: Assign warehouse to the FINANCE tenant

> **Prompt:**
> Update T_WAREHOUSE_TENANT_MAP to set TENANT_NAME to 'FINANCE' where WAREHOUSE_NAME is 'WH_FINANCE_CLOSE'

**What to expect:** 1 row updated.

---

### Step 13: Assign warehouses to the DATA_ENG tenant

> **Prompt:**
> Update T_WAREHOUSE_TENANT_MAP to set TENANT_NAME to 'DATA_ENG' where WAREHOUSE_NAME is in ('WH_DATAENG_TRANSFORM', 'WH_DATAENG_INGEST')

**What to expect:** 2 rows updated.

---

### Step 14: Assign warehouse to the SALES tenant

> **Prompt:**
> Update T_WAREHOUSE_TENANT_MAP to set TENANT_NAME to 'SALES' where WAREHOUSE_NAME is 'WH_SALES_ANALYTICS'

**What to expect:** 1 row updated.

---

### Step 15: Assign warehouse to the PLATFORM tenant

> **Prompt:**
> Update T_WAREHOUSE_TENANT_MAP to set TENANT_NAME to 'PLATFORM' where WAREHOUSE_NAME is 'WH_PLATFORM_OPS'

**What to expect:** 1 row updated. (WH_ADHOC_SANDBOX remains UNASSIGNED intentionally.)

---

### Step 16: Verify the warehouse-to-tenant mapping

> **Prompt:**
> Show me all rows in T_WAREHOUSE_TENANT_MAP ordered by TENANT_NAME

**What to expect:** 8 rows — 7 assigned to tenants, 1 (WH_ADHOC_SANDBOX) still UNASSIGNED.

---

### Step 17: Create the first dynamic table — credit by warehouse

> **Prompt:**
> Create a dynamic table called DT_CREDIT_BY_WAREHOUSE with a target lag of 1 hour using my current warehouse. It should select WAREHOUSE_NAME, START_TIME cast to DATE as CREDIT_DATE, and SUM of CREDITS_USED as CREDITS_CONSUMED from SAMPLE_METERING_HISTORY, grouped by WAREHOUSE_NAME and START_TIME::DATE. Use CREATE OR REPLACE. The output columns must be exactly: WAREHOUSE_NAME, CREDIT_DATE, CREDITS_CONSUMED.

**What to expect:** Dynamic table created. It will begin its initial refresh automatically.

---

### Step 18: Create the second dynamic table — credit by tenant

> **Prompt:**
> Create a dynamic table called DT_CREDIT_BY_TENANT with target lag DOWNSTREAM using my current warehouse. It should join DT_CREDIT_BY_WAREHOUSE (alias w) with T_WAREHOUSE_TENANT_MAP (alias m) on WAREHOUSE_NAME using a LEFT JOIN. Select COALESCE(m.TENANT_NAME, 'UNASSIGNED') as TENANT_NAME, w.CREDIT_DATE, w.WAREHOUSE_NAME, and SUM(w.CREDITS_CONSUMED) as TENANT_CREDITS. Group by the tenant name coalesce expression, CREDIT_DATE, and WAREHOUSE_NAME. Use CREATE OR REPLACE. The output columns must be exactly: TENANT_NAME, CREDIT_DATE, WAREHOUSE_NAME, TENANT_CREDITS.

**What to expect:** Dynamic table created. It refreshes when its upstream (DT_CREDIT_BY_WAREHOUSE) refreshes.

---

### Step 19: Create the third dynamic table — daily credit trend

> **Prompt:**
> Create a dynamic table called DT_CREDIT_DAILY_TREND with target lag DOWNSTREAM using my current warehouse. It should select CREDIT_DATE and SUM of CREDITS_CONSUMED as TOTAL_CREDITS from DT_CREDIT_BY_WAREHOUSE, grouped by CREDIT_DATE. Use CREATE OR REPLACE. The output columns must be exactly: CREDIT_DATE, TOTAL_CREDITS.

**What to expect:** Dynamic table created.

---

### Step 20: Verify the dynamic tables have data

> **Prompt:**
> Count the rows in DT_CREDIT_BY_WAREHOUSE

**What to expect:** 720 rows. If you see 0, wait about a minute for the initial refresh, then try again.

---

### Step 21: Create the credit summary view

> **Prompt:**
> Create a view called V_CREDIT_SUMMARY that joins T_TENANT (alias t) with DT_CREDIT_BY_TENANT (alias c) on TENANT_NAME using a LEFT JOIN. For each tenant show: TENANT_NAME, CREDITS_TODAY (sum of TENANT_CREDITS where CREDIT_DATE equals today, default 0), CREDITS_THIS_WEEK (sum where CREDIT_DATE >= start of current week, default 0), CREDITS_THIS_MONTH (sum where CREDIT_DATE >= start of current month, default 0), MONTHLY_BUDGET_CREDITS, and PCT_BUDGET_CONSUMED (credits this month divided by budget times 100, rounded to 1 decimal, NULL if budget is 0). Group by TENANT_NAME and MONTHLY_BUDGET_CREDITS. Order by CREDITS_THIS_MONTH descending. Use CREATE OR REPLACE.

**What to expect:** View created.

---

### Step 22: Query the credit summary

> **Prompt:**
> Select all rows from V_CREDIT_SUMMARY

**What to expect:** 6 rows. DATA_ENG should have the highest credit usage (~90% of budget consumed). UNASSIGNED will have credits but no budget (PCT_BUDGET_CONSUMED is NULL).

---

### Step 23: Spot-check the daily trend

> **Prompt:**
> Show me the top 5 days by total credits from DT_CREDIT_DAILY_TREND, ordered by total credits descending

**What to expect:** The day 14 days ago should be near the top (due to the DATA_ENG spike).

---

## Round 2 — Conversational FinOps (Semantic View + Cortex Analyst)

### Step 24: Create the semantic view

> **Prompt:**
> Create a semantic view called SV_FINOPS over the DT_CREDIT_BY_TENANT table (alias it as 'credits') with primary key (TENANT_NAME, CREDIT_DATE, WAREHOUSE_NAME) and comment 'Daily credit consumption by tenant and warehouse'. Define these dimensions: TENANT_NAME with comment 'Business unit / team name', WAREHOUSE_NAME with comment 'Warehouse that consumed the credits', CREDIT_DATE with comment 'Date of credit consumption'. Define one metric: TOTAL_CREDITS as SUM of credits.TENANT_CREDITS with comment 'Total credits consumed'. Overall semantic view comment: 'SnowPrism FinOps semantic view for natural-language credit analysis'. Use CREATE OR REPLACE.

**What to expect:** Semantic view created.

---

### Step 25: Verify the semantic view exists

> **Prompt:**
> Show semantic views like 'SV_FINOPS' in my current schema

**What to expect:** One row showing SV_FINOPS in your schema.

---

### Step 26: Ask your first question — top spender

> **Prompt:**
> Using the SV_FINOPS semantic view, which tenant spent the most credits in total?

**What to expect:** DATA_ENG — it has the highest base usage plus a 6x spike 14 days ago.

---

### Step 27: Ask about daily trends

> **Prompt:**
> Using SV_FINOPS, show me the daily credit trend for the last 30 days

**What to expect:** A list of dates with total credit consumption. You should see a spike about 14 days ago.

---

### Step 28: Drill into a specific tenant

> **Prompt:**
> Using SV_FINOPS, break down credit usage for the DATA_ENG tenant by warehouse

**What to expect:** Two warehouses — WH_DATAENG_TRANSFORM (higher) and WH_DATAENG_INGEST (lower).

---

### Step 29: Compare two tenants

> **Prompt:**
> Using SV_FINOPS, compare FINANCE and SALES total credit usage this month

**What to expect:** Both tenants' monthly totals side by side. FINANCE may show a spike from 3 days ago (month-end close).

---

### Step 30: Find the biggest spike

> **Prompt:**
> Using SV_FINOPS, which warehouse had the biggest single-day credit spike and on what date?

**What to expect:** WH_DATAENG_TRANSFORM, approximately 14 days ago.

---

## Round 3 — Streamlit FinOps Dashboard App

> **Important:** The Streamlit app must be created as a **standalone Streamlit object** in your schema — it cannot run from a shared workspace. You will create a single `streamlit_app.py` file and deploy it as a Streamlit-in-Snowflake app.
>
> **DO NOT** use PUT commands or copy files from the shared workspace. Cortex Code should write the `streamlit_app.py` content directly into a stage in your schema and create the Streamlit object pointing to that stage.

### Step 31: Create the Streamlit Dashboard app

> **Prompt:**
> Create a Streamlit app in my schema DELOITTE_COCO_LAB.BUILDER_XXX called SNOWPRISM_FINOPS_DASHBOARD. Deploy it as a standalone Streamlit object using `CREATE STREAMLIT` SQL with my current warehouse (do NOT use COMPUTE_WH — use whatever warehouse is in my current session). Do NOT use PUT commands or copy from workspace URLs. Write the streamlit_app.py content directly. The app should:
>
> 1. Use `st.connection("snowflake")` for the database connection.
> 2. Auto-detect the current user with `SELECT CURRENT_USER()` to derive the schema name (e.g., BUILDER_007 → DELOITTE_COCO_LAB.BUILDER_007).
> 3. Sidebar: navigation radio with "Dashboard" and "Conversational Agent" pages, plus a Refresh Data button that clears cache and reruns.
> 4. Dashboard page with:
>    - KPI metrics row using `st.container(horizontal=True)`: Total Credits MTD, Total Budget, Avg Budget Used %, Tenants >50% Budget (from V_CREDIT_SUMMARY)
>    - 2-column layout: daily credit trend area chart (from DT_CREDIT_DAILY_TREND) and credits-by-tenant bar chart (from V_CREDIT_SUMMARY)
>    - Second 2-column row: budget consumption horizontal bar chart and weekly trend by tenant line chart (pivot DT_CREDIT_BY_TENANT by ISO week and tenant)
>    - Full summary data table at the bottom
> 5. Cache all data-loading functions with `@st.cache_data`.
> 6. Use `st.set_page_config(page_title="SnowPrism FinOps", layout="wide")`.
> 7. Leave the Conversational Agent page as a placeholder for now (just show `st.info("Coming in next step...")`).

*(Replace `XXX` with your assigned builder number)*

**What to expect:** Cortex Code creates and deploys the Streamlit app. You should see SQL like `CREATE OR REPLACE STREAMLIT ...`.

---

### Step 32: Run the Dashboard

> In Snowsight, navigate to **Projects → Streamlit** (or use the sidebar). Find your app `SNOWPRISM_FINOPS_DASHBOARD` in schema `DELOITTE_COCO_LAB.BUILDER_XXX`. Click on it to launch.

**What to expect:** The app launches showing the Dashboard page with KPI cards, charts, and a data table.

---

### Step 33: Fix decimal type errors (if needed)

> If you see a `TypeError: unsupported operand type(s) for /: 'decimal.Decimal' and 'float'` error:

> **Prompt:**
> Fix this error in my Streamlit app: "TypeError: unsupported operand type(s) for /: 'decimal.Decimal' and 'float'". The numeric columns from Snowflake come as decimal.Decimal and need to be cast to float before arithmetic operations.

**What to expect:** Cortex Code updates the data loading or processing code to convert Decimal columns to float. The app should work after reloading.

---

### Step 34: Add the Conversational Agent page

> **Prompt:**
> Update my SNOWPRISM_FINOPS_DASHBOARD Streamlit app to add a working Conversational Agent page. It should:
>
> 1. Import `_snowflake` and `json` at the top of the file.
> 2. Use `_snowflake.send_snow_api_request("POST", "/api/v2/cortex/analyst/message", {}, {}, request_body, {}, 30000)` to call the Cortex Analyst API.
> 3. The request_body format is: `{"messages": [{"role": "user", "content": [{"type": "text", "text": question}]}], "semantic_view": "DELOITTE_COCO_LAB.BUILDER_XXX.SV_FINOPS"}`
> 4. Parse the response with `json.loads(resp["content"])`, then iterate over `response["message"]["content"]` looking for items with `type == "sql"` and execute their `statement` field via `conn.query()`.
> 5. Display results as a dataframe, and auto-generate a bar chart if the result has both numeric and non-numeric columns.
> 6. Add suggestion pills for: "Who is the top spender?", "Show daily trend", "Compare tenants", "Biggest spike".
> 7. Maintain chat history in `st.session_state.messages`.

*(Replace `XXX` with your assigned builder number)*

**What to expect:** Cortex Code updates the app file and redeploys. The Conversational Agent page now has a chat interface.

---

### Step 35: Fix Cortex Analyst API issues (if needed)

> If the Conversational Agent page returns errors when querying, it may be using the wrong API format. Ensure it uses:

> **Prompt:**
> Fix the conversational agent page. It should use `_snowflake.send_snow_api_request("POST", "/api/v2/cortex/analyst/message", {}, {}, request_body, {}, 30000)` where request_body is `{"messages": [{"role": "user", "content": [{"type": "text", "text": question}]}], "semantic_view": "DELOITTE_COCO_LAB.BUILDER_XXX.SV_FINOPS"}`. Parse the response with `json.loads(resp["content"])`, then iterate over `response["message"]["content"]` looking for items with `type == "sql"` and execute their `statement` field.

*(Replace `XXX` with your builder number)*

**What to expect:** The conversational agent now successfully queries SV_FINOPS and returns tabular results with auto-generated charts.

---

### Step 36: Test the conversational agent

> In the running app, switch to the **Conversational Agent** page. Click one of the suggestion pills (e.g., "Who is the top spender?") or type a question like "Which tenant spent the most credits in total?"

**What to expect:** The agent queries the SV_FINOPS semantic view and returns results as a table with an auto-generated chart.

---

## You're done

You built the entire SnowPrism FinOps pipeline — from raw synthetic data to self-refreshing dynamic tables to a conversational analytics Streamlit app — **entirely through Cortex Code prompts** in `DELOITTE_COCO_LAB.BUILDER_XXX`. No SQL written by hand.

---

## Troubleshooting

| Symptom | What to tell Cortex Code |
|---------|--------------------------|
| Schema is NULL or NONE | "Run USE SCHEMA DELOITTE_COCO_LAB.BUILDER_XXX" — replace XXX with your number. This is the #1 issue. |
| Dynamic tables show 0 rows | "Manually refresh DT_CREDIT_BY_WAREHOUSE and then check row count again" |
| `invalid identifier 'CREDIT_DATE'` | The Streamlit app is using wrong column names. Tell Cortex Code: "The column in DT_CREDIT_DAILY_TREND is called CREDIT_DATE, not date or usage_date. Fix the query." |
| `invalid identifier 'TENANT_NAME'` | "The column in DT_CREDIT_BY_TENANT is called TENANT_NAME. Fix the query to use that exact column name." |
| `invalid source URL scheme for PUT` | Cortex Code is trying to PUT from a workspace URL. Tell it: "Do NOT use PUT commands. Write the streamlit_app.py content directly into my stage and create the Streamlit object." |
| `invalid parameter 'OVERWRITE'` | Same issue as above — retry Step 31 prompt without PUT commands. |
| `Compute pool not ready` or pool space error | Wait 1-2 minutes and refresh the Streamlit app page. The compute pool needs time to provision. If still failing after 3 minutes, close other Streamlit tabs. |
| Semantic view not showing up | "Show all semantic views in my current schema" — verify the schema is correct |
| Wrong schema | "Switch my schema to DELOITTE_COCO_LAB.BUILDER_XXX" (your number) |
| Want to start over | "Drop all tables, views, dynamic tables, and semantic views in my current schema, then confirm it's empty" — then restart from Step 3 |
| Cortex Code generates different SQL | That's OK! As long as the output matches what's expected, the exact SQL can vary. |
| Streamlit app shows decimal.Decimal error | "Fix this error: TypeError: unsupported operand type(s) for /: 'decimal.Decimal' and 'float'" |
| Streamlit app won't launch | Ensure it was created as a standalone Streamlit object (`CREATE STREAMLIT`), not just a file in a workspace. The app needs its own deployment. |
| Conversational Agent returns errors | Verify the API call uses `_snowflake.send_snow_api_request` with endpoint `/api/v2/cortex/analyst/message`. The `semantic_view` field must be the fully qualified name including your schema. |
| App can't find tables | The app auto-detects your user and builds the schema path. Verify your tables exist: "Show tables in DELOITTE_COCO_LAB.BUILDER_XXX" |
| Permission denied on Streamlit | "Grant usage on the Streamlit app to my role" — ensure HOL_BUILDER has CREATE STREAMLIT privilege on the schema |

---

## Tips for getting the best results from Cortex Code

1. **Be specific** — include table names, column names, and data types in your prompts.
2. **One task per prompt** — don't combine unrelated operations in a single message.
3. **Verify after each step** — ask Cortex Code to confirm results before moving on.
4. **Reference previous objects** — prompts build on earlier work. Cortex Code remembers context within a session.
5. **Ask follow-up questions** — if output doesn't look right, ask "why does that result look different from what I expected?"
6. **Streamlit must be standalone** — the app is deployed as its own Streamlit object in your schema, not run from a shared workspace.
