# Databricks Primer — for a Cross-Platform Data & AI Advisor

*Built for someone who already knows Snowflake cold, joining a firm where advisors are expected to be technically credible, not slide-deck salespeople.*

---

## The one principle behind this whole plan

You are not training to pass an engineer's exam or to build pipelines for a living. You are training for three things, in this order:

1. **Technical credibility** — enough hands-on depth that no one files you as a "powerpoint jockey."
2. **Advisory range** — the ability to guide senior stakeholders on a Databricks-and-Snowflake roadmap.
3. **Firm credentialing** — a recognized credential and a point of view that helps the practice sell.

Your accelerant is that you already own a deep Snowflake mental model. Most of Databricks is the same ideas with different names and a different compute philosophy. So you learn by **mapping and porting**, not by starting over. Target: ~8 weeks of focused part-time effort to "credible advisor," then ongoing.

---

## Phase 0 — The translation layer (Days 1–3)

Before any course, internalize this map. It converts ~70% of what you know about Snowflake into Databricks fluency immediately.

| Concept | Snowflake | Databricks (2026 names) |
|---|---|---|
| Platform identity | Cloud data warehouse / "AI Data Cloud" | Data Intelligence Platform (lakehouse) |
| Compute | Virtual Warehouses (T-shirt sizes) | Clusters + SQL Warehouses, serverless options |
| Storage | Managed micro-partitions | Open files (Delta / Parquet, managed Iceberg) on **your** cloud object storage (S3/ADLS/GCS) |
| Table format | Native tables | Delta Lake (Parquet + transaction log); managed Iceberg now supported |
| Namespace | Database → Schema → Table | Catalog → Schema → Table (Unity Catalog) |
| Governance | Horizon Catalog | Unity Catalog (lineage, access, audit) |
| Python/code | Snowpark (added on) | Spark / PySpark / Spark SQL (native core) |
| Ingestion | Snowpipe / Snowpipe Streaming | Auto Loader, Lakeflow Connect, Structured Streaming |
| Orchestration | Tasks + Streams | Lakeflow Jobs (was Workflows) |
| Declarative ELT | Dynamic Tables | Lakeflow Declarative Pipelines (was Delta Live Tables) |
| AI / LLM | Cortex (Analyst, Search, AI functions) | Mosaic AI (Agent Framework, Vector Search, Model Serving) + `ai_query` SQL functions |
| NL analytics | Cortex Analyst | AI/BI Genie |
| UI | Snowsight | Notebooks, Databricks SQL, AI/BI Dashboards, Databricks One |
| Time travel / clone | Time Travel, zero-copy clone | Delta time travel, shallow clone |
| Sharing | Secure Data Sharing, Marketplace | Delta Sharing, Databricks Marketplace |
| Apps | Streamlit in Snowflake | Databricks Apps |
| OLTP | Unistore / Hybrid Tables | Lakebase (Postgres, from the Neon acquisition) |
| Query engine | (managed) | Photon |
| Cost unit | Credits (all-in) | DBUs **plus** pass-through cloud infra cost |

**The single most important difference to burn in:** the cost model. Snowflake bills one credit that bundles compute. Databricks bills DBUs **and** you separately pay the underlying cloud compute, which makes forecasting harder and FinOps a real discipline. This is the difference that comes up in every CFO conversation. Know it cold.

---

## Phase 1 — Hands-on fluency (Weeks 1–2)

Goal: stop reading, start touching. You cannot credential what you've only watched.

- Take the **free Lakehouse Fundamentals** badge on Databricks Academy. One sitting.
- Spin up a free workspace (Databricks Free Edition / cloud trial on AWS, Azure, or GCP).
- **Port one Snowflake pipeline you already know by heart** into Databricks: ingest with Auto Loader, land in a Delta table, transform in a notebook (SQL where you can, PySpark where you must), schedule it as a Lakeflow Job. You learn a platform fastest by rebuilding something you already understand.
- **Milestone:** you can navigate the workspace and speak from having built, not from having skimmed docs.

---

## Phase 2 — The genuine differences (Weeks 3–4)

Where Databricks is *not* just Snowflake with new labels. Spend your hands-on time here.

- **Spark / distributed compute model** — the mental shift from a managed warehouse to a cluster you reason about. Partitions, shuffles, why a job is slow.
- **Delta Lake internals** — the transaction log, ACID on object storage, compaction (OPTIMIZE), Z-ordering, vacuuming. This is what makes a lake behave like a warehouse.
- **Unity Catalog** — governance depth, lineage, fine-grained access, the open-vs-proprietary debate. Critical for regulated-industry conversations.
- **Lakeflow** — Connect (ingestion), Declarative Pipelines (the DLT successor), Jobs (orchestration). The modern data-engineering surface.
- **Milestone:** you can whiteboard the lakehouse architecture, top to bottom, without notes.

---

## Phase 3 — The AI layer (Weeks 5–6) — this is your edge

This is where your agentic-AI and Cortex background compounds, and where the practice actually sells.

- **Mosaic AI** — Agent Framework, Vector Search, Model Serving, fine-tuning. Map each piece to its Cortex equivalent so you can speak both fluently in the same client conversation.
- **AI/BI Genie** — natural-language analytics; the Cortex Analyst parallel.
- **GenAI app patterns** — RAG, agents, evaluation and monitoring on the lakehouse. This is the design pattern clients keep asking for.
- **Milestone:** you can stand in front of a stakeholder and design a GenAI solution on Databricks, then explain when you'd do the same on Snowflake instead.

---

## Phase 4 — Advisory synthesis & credentialing (Weeks 7–8)

Convert knowledge into the things that make you valuable.

- **Migration patterns** — Hadoop → Databricks, and Snowflake ↔ Databricks coexistence (Iceberg as the bridge, Databricks upstream for ML/engineering, Snowflake downstream for governed BI). Many enterprises run both; the architecture is workload-driven, not platform-driven.
- **FinOps / cost model** — the DBU-plus-infra reality, sizing, serverless trade-offs. Your CFO-facing material.
- **Competitive reality** — know the standard Snowflake attack ("Databricks isn't enterprise-ready," BC/DR, governance maturity, the 2x analytics-speed claim) and the honest rebuttals. You will be in rooms where this is live, and the credible advisor handles it without becoming a vendor cheerleader.
- **Build your own decision framework** — a written "when Databricks, when Snowflake, when both" point of view, with your name on it. This is your IP and the thing that makes you the cross-platform advisor rather than a platform loyalist.

---

## Certification strategy (for credentialing, not for you)

You don't need a cert to understand Databricks. You need one to credential the firm. So pick for leverage, not for completeness.

1. **Lakehouse Fundamentals badge** — free, Week 1. Table stakes.
2. **Generative AI Engineer Associate** — the highest-leverage paid cert for you. It aligns with your agentic-AI specialty and the practice's hottest selling area. ($200, valid 2 years.)
3. **Data Engineer Associate** *(optional)* — broad platform-fluency signal if the firm values it for credentialing. Useful, not urgent.
4. **Skip** the Data Engineer Professional grind and the deep PySpark optimization track. That depth belongs to the builders you'll guide, not to you.

---

## Resources (official-first)

- **Databricks Academy** — free self-paced courses and the badge tracks. Start here.
- **Free Edition / cloud trial** — your hands-on sandbox.
- **Official docs** — Delta Lake, Unity Catalog, Lakeflow, Mosaic AI. Use for depth.
- **Exam guides** — read the current guide before any cert; the platform and names change often.
- **Data + AI Summit** sessions and release notes — Lakeflow and Mosaic AI move fast; build a habit of skimming releases.

---

## What "done" actually looks like

Not a badge on LinkedIn. Three concrete things:

1. You can **whiteboard** a lakehouse architecture and a migration path, unprompted, no notes.
2. You have a **written Databricks-vs-Snowflake decision framework** with your name on it.
3. You have **shipped one small thing you built yourself** on the platform.

Hit those three and you walk into the practice credible from day one, with no rolodex required.

---

## A caution

The cert is the measurable part, so you'll be tempted to over-index on it. Don't. The badge credentials the firm; the architecture fluency and the decision framework are what make *you* the advisor they're paying for. Spend most of your time on the unmeasurable part.
