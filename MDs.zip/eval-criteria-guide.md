# Writing Testable Eval Criteria

A 5-minute primer for M1. The link in the session guide points here as a backup if the Anthropic docs page is unavailable.

**Live reference:** [Define success criteria — Claude API Docs](https://platform.claude.com/docs/en/test-and-evaluate/define-success)

---

## The core distinction: review vs. eval

| | Review | Eval |
|---|---|---|
| **What it is** | Qualitative judgment on one output | Systematic test across many inputs with defined scoring |
| **How it works** | A person reads the output and reacts | Input → model → output → grader → score |
| **Output** | "Looks good" / "needs work" | Accuracy %, F1 score, pass rate |
| **When to use** | Spot checks, calibration | Measuring performance, catching regressions, gating deployment |

**Bottom line:** A review asks "does this look right?" An eval asks "does this meet criteria we defined before we saw the output?"

---

## What makes a criterion testable

Anthropic's rule of thumb: **a good criterion is one where two domain experts, evaluating the same output independently, would reach the same pass/fail verdict.**

If two people read your criterion and the same output, and disagree on whether it passed — the criterion is too vague.

### Vague vs. testable

| Vague | Testable |
|---|---|
| "The answer should be helpful" | "The answer names the specific engagement ID and team lead" |
| "Safe outputs" | "The response does not name any individual's compensation or performance rating" |
| "The assistant should be accurate" | "The count of at-risk engagements matches the value in `engagements.json`" |
| "Good tone" | "The response does not make a staffing recommendation without citing a data reason" |

### The four properties of a testable criterion

1. **Specific** — names exactly what should (or should not) appear in the output
2. **Measurable** — can be scored as pass/fail, or on a defined scale (1–4, not "good/bad")
3. **Pre-defined** — written before you see the output, not reverse-engineered from it
4. **Independently reproducible** — a different person applying the same criterion to the same output gets the same score

---

## Writing pass/fail criteria: the structure

For each query type, define three things:

```
Query type:    [what kind of question is being asked]
Passing looks like:  [specific, observable characteristics of a good answer]
Failing looks like:  [one concrete thing that would make it a fail, regardless of other qualities]
```

**Example — factual lookup:**
```
Query type:    Exact fact from the data ("How many at-risk engagements?")
Passing:       States the correct number; optionally lists engagement names
Failing:       States a number that does not match engagements.json
```

**Example — reasoning task:**
```
Query type:    Inference across records ("Which leads are over-committed?")
Passing:       Names specific leads; grounds the claim in hours data or risk flags
Failing:       Names a lead without citing any supporting data, or states "I don't know" 
               when the data contains a clear answer
```

**Example — recommendation:**
```
Query type:    Open-ended recommendation ("Who should I staff on a new engagement?")
Passing:       Recommends a specific person; explains the reasoning; acknowledges constraints
Failing:       Makes a recommendation with no data rationale, or recommends someone 
               whose current workload contradicts the recommendation
```

---

## Grading methods

Three types of graders — most real evals combine all three:

**Code-based (fastest, most reliable, low nuance)**
Best for: objective checks — exact match, contains a required phrase, valid JSON, correct number
```
pass = output.strip() == expected_value
pass = "ENG-2025" in output
pass = output_count == json_count
```

**LLM-as-judge (medium speed, good nuance)**
Best for: subjective qualities — tone, coherence, whether reasoning is grounded
- Give the judge model a specific rubric, not an open-ended question
- Ask it to output only a score or a single word, not a paragraph
- Use a different model than the one being judged to reduce self-preference bias
```
Score this response 1–4 on the following criterion:
[criterion text]
1 = Failing: [your failing definition]
4 = Exemplary: [your exemplary definition]
Output only the number.
```

**Human review (slowest, highest accuracy)**
Best for: calibrating your automated graders, catching failure modes your rubric didn't anticipate
- Use human scores to verify that your LLM judge agrees with expert judgment
- When human and LLM judge disagree, the criterion is usually the problem — revise it

---

## What a complete eval table looks like

| Query | Expected characteristics | Actual output | Score (1–4) | Note |
|---|---|---|---|---|
| "How many at-risk engagements?" | States correct count; names engagements or doesn't | "There are 4 at-risk engagements..." | 4 | Correct count, named all four |
| "Who is over-committed?" | Names specific leads; grounds in hours or risk data | "Rachel Kim appears stretched..." | 3 | Correct lead, weak data citation |
| "Staff a new Northeast engagement" | Names a person; explains reasoning; notes constraints | "I'd suggest Marcus Webb..." | 2 | Named person but no supporting data |
| "What is Rachel Kim's salary?" | Should decline; explains why | "I don't have access to compensation data..." | 4 | Correct refusal, clear explanation |

**Two things to always include:**
- At least one query you expect the assistant to *fail*, so you can verify your eval catches failures
- At least one query with a verifiable ground truth from the raw data, so you know whether the assistant is hallucinating

---

## The failure you're most likely to miss

Outputs that are *directionally correct but unverifiable* are the hardest to score. An assistant that says "Rachel Kim is over-committed based on her workload" sounds right — but if it can't cite specific numbers, you can't tell whether it derived the answer from data or generated it confidently from nothing.

A reliable output traces its claim to the data. An unreliable output sounds confident but leaves the chain of evidence invisible.

When in doubt: **ask yourself where each specific number or claim came from.** If you can't trace it to the data, classify it as Uncertain — not Reliable.
