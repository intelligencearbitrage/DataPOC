# Claude-Code-toolkit
A generic, reusable project template using Claude Code's **agent teams** pattern.
