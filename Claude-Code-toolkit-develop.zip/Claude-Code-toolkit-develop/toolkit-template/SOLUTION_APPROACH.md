# Solution Approach — Scripts + Agentic Validation & Refinement

This document describes the two-layer architecture of the toolkit: a standalone **scripts layer** for execution, and an optional **agentic layer** that validates and refines outputs.

---

## Two Modes of Operation

End users choose how they want to run the solution:

| Mode | What It Uses | When to Use |
|------|-------------|-------------|
| **Scripts-only** | Generated Python scripts in `scripts/` | Quick runs, simple use cases, full manual control |
| **Agentic** | Scripts + Validator + Refiner Python scripts | Higher accuracy needs, automated quality loops, complex deliverables |

Both modes produce deliverables in `output/`. The agentic mode adds an automated quality loop on top.

> **Important:** The Validator and Refiner are **Python scripts** in `scripts/`, not Claude Code agent definitions in `.claude/agents/`. The 11 agents in `.claude/agents/` handle the toolkit pipeline (Research → Planning → Implementation → Review). The validator/refiner scripts are a separate layer that runs after the pipeline produces output.

> **Setup:** Run `setup agentic layer` in Claude Code after the pipeline completes. This generates `validator.py`, `refiner.py`, and `prompts.py` in `scripts/`, tailored to your project.

> **Refiner scope:** The refiner only patches files in `output/` directly — it does not modify scripts. If a developer wants to fix scripts based on validation errors, they use Claude to fix them directly.

---

## Data Separation: Knowledge vs Inputs

The toolkit separates reference knowledge from source data:

| Folder | Used By | Purpose | Examples |
|--------|---------|---------|---------|
| `knowledgebase/` | **Agent team** (pipeline) + **scripts** (runtime) | Reference materials the agents analyze to build scripts, and rules scripts apply at runtime | Standards, naming conventions, type mappings, source schemas, example models, best practices |
| `inputs/` | **Generated scripts** (runtime only) | Source data that scripts process — agents do not access this folder | Production data files, actual datasets to transform |

**Why separate them?**
- `knowledgebase/` is used at **two stages**: by the agent team during the pipeline (to understand the problem and build scripts), and by scripts at runtime (to apply rules and conventions).
- `inputs/` is used **only at script runtime** — the agent team never reads from it. It contains the actual data the scripts process.
- This separation means the agent pipeline is independent of the runtime data. You can build the solution once and run it against different `inputs/` datasets.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         DEVELOPER INPUTS                               │
│                                                                        │
│  prompts.md       knowledgebase/     inputs/          GUARDRAILS.yaml  │
│  (requirements)   (reference         (source data     (quality rules)  │
│                    knowledge)         to process)                      │
└─────┬──────────────────┬──────────────────┬────────────────┬───────────┘
      │                  │                  │                │
      ▼                  ▼                  ▼                ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│                    LAYER 1: SCRIPTS (standalone)                         │
│                                                                         │
│   Toolkit pipeline generates Python scripts in scripts/                 │
│   Scripts use knowledgebase/ for rules, read inputs/ for source data,   │
│   and produce deliverables in output/                                   │
│                                                                         │
│   ┌──────────────┐    ┌──────────────┐    ┌──────────────┐             │
│   │ base_parser   │    │base_generator│    │base_validator│             │
│   │     .py       │    │     .py      │    │     .py      │             │
│   └──────┬───────┘    └──────┬───────┘    └──────┬───────┘             │
│          │                    │                    │                     │
│          ▼                    ▼                    ▼                     │
│   ┌─────────────────────────────────────────────────────┐              │
│   │              build_all.py (orchestrator)             │              │
│   └──────────────────────┬──────────────────────────────┘              │
│                          │                                              │
│                          ▼                                              │
│                   ┌────────────┐                                        │
│                   │  output/   │                                        │
│                   │(deliverables)                                       │
│                   └─────┬──────┘                                        │
│                         │                                               │
└─────────────────────────┼───────────────────────────────────────────────┘
                          │
          ┌───────────────┘
          │
          │  SCRIPTS-ONLY MODE STOPS HERE
          │  AGENTIC MODE CONTINUES BELOW
          │
          ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│                 LAYER 2: AGENTIC (optional quality loop)                 │
│                                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │                                                                   │  │
│  │  ┌─────────────┐                                                │  │
│  │  │  VALIDATOR   │  First validation run                          │  │
│  │  │   SCRIPT     │  Compares output/ vs inputs/                   │  │
│  │  └──────┬───────┘                                                │  │
│  │         │                                                        │  │
│  │         ▼                                                        │  │
│  │  ┌──────────────────┐                                            │  │
│  │  │  HUMAN REVIEW    │  User reviews validation report            │  │
│  │  │  (first pass)    │  - Proceed with refinement?                │  │
│  │  │                  │  - Add feedback for the refiner?            │  │
│  │  │                  │  - Accept output as-is?                     │  │
│  │  └────────┬─────────┘                                            │  │
│  │           │                                                      │  │
│  │     ┌─────┴──────┐                                               │  │
│  │     │            │                                               │  │
│  │  Accept     Proceed with refinement                              │  │
│  │  as-is      (+ optional feedback)                                │  │
│  │     │            │                                               │  │
│  │     │            ▼                                               │  │
│  │     │     ┌──────────────────┐                                   │  │
│  │     │     │ FEEDBACK         │  If human provided feedback,      │  │
│  │     │     │ VALIDATION       │  validate it before accepting     │  │
│  │     │     └────────┬─────────┘                                   │  │
│  │     │              │                                             │  │
│  │     ▼              ▼                                             │  │
│  │  ┌──────┐ ┌───────────────────────────────────────────────────┐  │  │
│  │  │ DONE │ │      AUTOMATED LOOP (no human interruption)       │  │  │
│  │  └──────┘ │                                                   │  │  │
│  │           │  ┌──────────────┐              ┌──────────────┐   │  │  │
│  │           │  │   REFINER    │─────────────▶│  VALIDATOR   │   │  │  │
│  │           │  │   SCRIPT     │              │  (re-run)    │   │  │  │
│  │           │  │              │              │              │   │  │  │
│  │           │  │ Patches      │◀─────────────│ Re-evaluates │   │  │  │
│  │           │  │ output/      │  next        │ all issues   │   │  │  │
│  │           │  │ directly     │  iteration   │              │   │  │  │
│  │           │  └──────────────┘              └──────────────┘   │  │  │
│  │           │            (max 3 or user-defined)                │  │  │
│  │           └────────────────────────┬──────────────────────────┘  │  │
│  │                                    │                             │  │
│  │                                    ▼                             │  │
│  │                       ┌──────────────────┐                       │  │
│  │                       │  HUMAN REVIEW    │                       │  │
│  │                       │  (final)         │                       │  │
│  │                       │                  │                       │  │
│  │                       │ Reviews results  │                       │  │
│  │                       │ Adds feedback    │── if new feedback,    │  │
│  │                       │ Accepts/rejects  │   loop can re-run     │  │
│  │                       └──────────────────┘                       │  │
│  │                                                                  │  │
│  └──────────────────────────────────────────────────────────────────┘  │
│                          │                                              │
│                          ▼                                              │
│                   ┌────────────┐                                        │
│                   │  output/   │                                        │
│                   │ (refined)  │                                        │
│                   └────────────┘                                        │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Pipeline Quality Features

### Peer Review & Devil's Advocate (Phase 2-3)

During Phase 2, the devil's advocate challenges the master plan — verifying that decisions are backed by research evidence, alternative approaches were considered, and all requirements are addressed. The devil's advocate FAIL verdict is a hard block on Gate 2.

During Phase 3, for each script the builder completes:
- **Peer Reviewer** reviews the script for code quality, plan adherence, and edge cases
- **Devil's Advocate** challenges assumptions, looks for unhandled scenarios, and verifies logic

Both run asynchronously while the builder moves on to the next script. Both must PASS independently before Gate 3 can close.

### Escalation Protocol

All agents follow `.claude/rules/escalation.md` when stuck:
- **L1 (Minor)** — Self-resolve, document assumption in agent memory
- **L2 (Moderate)** — Create expert consultation task
- **L3 (Blocking)** — Create "ESCALATION L3" task for lead
- **L4 (Critical)** — Create "ESCALATION L4 - HUMAN REQUIRED" task
- **Circuit breaker** — 3 failures on same step → escalate to next level

---

## Layer 1: Scripts (Standalone)

The toolkit pipeline (Research → Planning → Implementation → Review) produces Python scripts in `scripts/`. These scripts:

- Reference `knowledgebase/` for rules, standards, and conventions
- Read source data from `inputs/`
- Apply transformation logic
- Generate deliverables in `output/`
- Can be run independently via `python scripts/build_all.py`

**In scripts-only mode, this is the complete solution.** The user runs the scripts, gets the output, and manually reviews the results.

---

## Layer 2: Agentic Validation & Refinement

The agentic layer is an **optional quality loop** that sits on top of the scripts layer. It automates the cycle of validating outputs, collecting feedback, and patching the output files directly.

> **How to set up:** After the pipeline completes (`start project`), run `setup agentic layer` in Claude Code. This generates three project-specific scripts in `scripts/`: `validator.py`, `refiner.py`, and `prompts.py`.

> **Architecture note:** The validator and refiner are **Python scripts in `scripts/`**. They can be rule-based, AI-powered (using the Claude API), or a mix — depending on the use case. They are not Claude Code agent definitions — they sit alongside the main scripts (base_parser, base_generator, etc.) in the same `scripts/` directory.

### scripts/prompts.py — Centralized Prompt Management

All prompts used by the validator and refiner scripts live in a single `scripts/prompts.py` file. This keeps prompt logic separate from script logic, making it easy to tune, review, and version-control the instructions that drive the agentic layer.

```python
# prompts.py — All prompts for the agentic validation & refinement layer

VALIDATOR_SYSTEM_PROMPT = """
You are a validation agent. Compare the generated outputs against
the source inputs and reference knowledge to identify gaps,
inaccuracies, and quality issues.
...
"""

VALIDATOR_COMPARISON_PROMPT = """
Compare the following output file against the source input.
Identify: missing content, incorrect mappings, naming violations,
and any data that appears in the output but not in the source.

Output file: {output_file}
Source file: {input_file}
Reference: {knowledge_file}
...
"""

REFINER_SYSTEM_PROMPT = """
You are a refinement agent. Given a validation report and optional
human feedback, patch the output files directly to resolve
identified issues. You must not modify any scripts — only files
in the output/ directory.
...
"""

REFINER_PATCH_PROMPT = """
Patch the following output file to correct the identified issue.
Do not introduce changes beyond what is needed for this fix.

Issue: {issue_description}
Output file: {output_file}
Source data: {source_reference}
Validation context: {validation_context}
Human feedback: {human_feedback}
...
"""

FEEDBACK_VALIDATION_PROMPT = """
Evaluate the following human feedback for relevance and validity.
Check whether the feedback:
- References real issues from the validation report
- Is actionable (can be applied as an output patch)
- Does not contradict the source data in inputs/

Feedback: {human_feedback}
Validation report: {validation_report}
...
"""
```

**Why a separate file:**
- **Single place to edit** — all prompt tuning happens here, not scattered across script code
- **Version control** — prompt changes are tracked as clear diffs
- **Reusable** — both validator and refiner scripts import from the same file
- **Testable** — prompts can be tested independently of script logic

### The Three Components

#### 1. Validator Script (`scripts/validator.py`)

The validator compares generated outputs against the original source data to identify gaps, inaccuracies, and quality issues.

**What it does:**
- Reads deliverables from `output/`
- Reads source data from `inputs/` (the ground truth)
- References `knowledgebase/` for rules and standards to validate against
- Compares: does the output accurately reflect the source?
- Produces a structured validation report

**Validation report contains:**
```yaml
validation_report:
  timestamp: "2026-02-20T10:30:00"
  overall_accuracy: 87.5
  issues:
    - id: V-001
      severity: high
      category: missing_content
      description: "Entity X from source not present in output"
      source_file: "inputs/customer_model.xlsx"
      output_file: "output/customer_schema.sql"
    - id: V-002
      severity: medium
      category: incorrect_mapping
      description: "Field Y mapped to wrong data type"
      source_file: "inputs/customer_model.xlsx"
      reference: "knowledgebase/type_mappings.yaml"
      output_file: "output/customer_schema.sql"
  passed_checks:
    - "All table names follow naming conventions"
    - "All required columns present in orders entity"
```

#### 2. Human-in-the-Loop

Humans are involved at two specific points:

**First pass (after initial validation, before refinement):**
- Review the validation report
- Decide whether to proceed with output refinement or accept output as-is
- Optionally add feedback for the refiner (feedback is validated before acceptance)

**Final review (after the refinement loop exits):**
- Review what was patched and what remains
- Accept the output as final
- Add feedback that triggers a new loop run (feedback is validated before acceptance)
- Dismiss remaining issues as acceptable
- Request more iterations
- Take validation errors to Claude to fix the scripts directly

#### 3. Refiner Script (`scripts/refiner.py`)

The refiner takes validated issues and human feedback, then patches the output files directly.

**What it does:**
- Reads the validation report + validated human feedback
- Patches deliverables in `output/` to correct identified issues
- Hands back to the validator for re-evaluation

**What it does NOT do:**
- Does not modify scripts in `scripts/`

**Refiner inputs — two trigger modes:**

| Trigger | What the Refiner Receives |
|---------|--------------------------|
| **Validation errors only** | Refiner patches output based solely on the validation report — issues, source references, and expected values |
| **Validation errors + human feedback** | Refiner patches output using both the validation report and the developer's additional guidance (after feedback is validated) |

---

## Feedback Validation

Human feedback is validated before being accepted by the refiner. This prevents invalid, irrelevant, or contradictory instructions from entering the refinement loop.

### What Gets Checked

| Check | What It Validates | On Failure |
|-------|------------------|------------|
| **Relevance** | Does the feedback relate to issues in the validation report or to the output files? | Reject — feedback must reference actual validation issues or output content |
| **Actionability** | Can the feedback be acted on as an output patch? | Reject — inform the user that the feedback is not actionable |
| **Source consistency** | Does the feedback contradict the ground truth in `inputs/` or rules in `knowledgebase/`? | Reject — feedback cannot override source data or reference standards |

### Feedback Validation Flow

```
Human provides feedback
        │
        ▼
┌───────────────────────────────┐
│     FEEDBACK VALIDATION       │
│                               │
│  1. Is it relevant to the     │
│     validation issues?        │
│  2. Is it actionable as an    │
│     output patch?             │
│  3. Does it contradict        │
│     source data?              │
└───────────┬───────────────────┘
            │
   ┌────────┴────────┐
   │                 │
 Valid            Invalid
   │                 │
   ▼                 ▼
Accepted by     Rejected with
the refiner     explanation to
                the user
```

---

## The Refinement Loop

```
                    ┌──────────────────────────────────┐
                    │     1. FIRST VALIDATION           │
                    │     Validator compares output/    │
                    │     vs inputs/ + knowledgebase/   │
                    │     Produces validation report    │
                    └───────────────┬──────────────────┘
                                    │
                          ┌─────────┴─────────┐
                          │                   │
                    All checks            Issues found
                      pass                    │
                          │                   ▼
                          │      ┌──────────────────────────────┐
                          │      │  2. HUMAN REVIEW (first pass) │
                          │      │                              │
                          │      │  User sees validation report │
                          │      │  - Accept output as-is?      │
                          │      │  - Proceed to refinement?    │
                          │      │  - Add feedback for refiner? │
                          │      └──────────────┬───────────────┘
                          │                     │
                          │           ┌─────────┴─────────┐
                          │           │                   │
                          │      Accept as-is       Proceed
                          │           │             (+ optional feedback)
                          │           ▼                   │
                          │        ┌──────┐               │
                          │        │ DONE │               ▼
                          │        └──────┘    ┌─────────────────────┐
                          │                    │ 3. VALIDATE FEEDBACK │
                          │                    │    (if provided)     │
                          │                    └──────────┬──────────┘
                          │                               │
                          │                               ▼
                          │  ┌─────────────────────────────────────────┐
                          │  │     AUTOMATED REFINEMENT LOOP           │
                          │  │     (max 3 or user-defined, no human    │
                          │  │      interruption during iterations)    │
                          │  │                                         │
                          │  │  ┌──────────────────────────────────┐   │
                          │  │  │  4. REFINER patches output/      │   │
                          │  │  │     Applies fixes directly to    │   │
                          │  │  │     deliverable files             │   │
                          │  │  └──────────────┬───────────────────┘   │
                          │  │                 │                       │
                          │  │                 ▼                       │
                          │  │  ┌──────────────────────────────────┐   │
                          │  │  │  5. VALIDATOR re-runs            │   │
                          │  │  │     Checks all issues            │   │
                          │  │  │     Compares to previous accuracy │  │
                          │  │  └──────────────┬───────────────────┘   │
                          │  │                 │                       │
                          │  │   ┌─────────────┼─────────────┐        │
                          │  │   │             │             │        │
                          │  │ All fixed   Some remain   Max reached  │
                          │  │   │             │             │        │
                          │  │   │       Loop back to     Exit loop   │
                          │  │   │       Step 4 (next                 │
                          │  │   │       iteration)                   │
                          │  │   │                                    │
                          │  └───┼────────────────────────────────────┘
                          │      │
                          ▼      ▼
                    ┌──────────────────────────────────────────────┐
                    │         6. HUMAN REVIEW (final)               │
                    │                                              │
                    │  Loop has finished. User reviews results:    │
                    │  - Accept output as final                    │
                    │  - Add new feedback → validated, loop re-run │
                    │  - Dismiss remaining issues                  │
                    │  - Request additional iterations             │
                    └──────────────────────────────────────────────┘
```

---

## Human-in-the-Loop Integration

Humans are involved at **two points** — after the first validation (before refinement starts) and after the refinement loop exits. The refinement iterations themselves run uninterrupted.

### When Humans Are Involved

```
Scripts produce output/
        │
        ▼
   ┌─────────────┐
   │  VALIDATOR   │  First validation
   └──────┬──────┘
          │
          ▼
┌──────────────────────────────────────┐
│     HUMAN REVIEW (first pass)        │
│                                      │
│  User sees validation report:        │
│  - Accept output as-is? → DONE       │
│  - Proceed to refinement?            │
│  - Add feedback for the refiner?     │
│    (feedback is validated first)     │
└──────────────┬───────────────────────┘
               │
               ▼  (user chose to proceed)
┌──────────────────────────────────────┐
│  AUTOMATED LOOP (runs uninterrupted) │
│                                      │
│  REFINER ──▶ VALIDATOR (re-run)      │
│  (patches     ▲              │       │
│   output/)    └──────────────┘       │
│                                      │
│  Iterates up to max (default: 3)     │
└──────────────┬───────────────────────┘
               │
               │  loop exits (all fixed / max reached / no improvement)
               ▼
┌──────────────────────────────────────┐
│     HUMAN REVIEW (final)             │
│                                      │
│  User reviews final state:           │
│  - What was patched in output/       │
│  - What remains unresolved           │
└──────────────┬───────────────────────┘
               │
     ┌─────────┴─────────┐
     │                   │
User accepts        User adds
output as final     new feedback
     │                   │
     ▼                   ▼
  ┌──────┐     Feedback validated,
  │ DONE │     then loop re-runs
  └──────┘     with feedback as
               additional input
```

### First Pass — What Humans Can Do

| Action | Effect |
|--------|--------|
| **Accept output as-is** | No refinement — output is final |
| **Proceed to refinement** | Automated loop starts (validation errors sent to refiner) |
| **Add feedback** | Feedback is validated, then passed to the refiner alongside validation issues |

### After the Loop — What Humans Can Do

| Action | Effect |
|--------|--------|
| **Accept output** | Final — no more iterations |
| **Add feedback** | Feedback is validated, then triggers a new loop run incorporating it |
| **Dismiss remaining issues** | Marks unresolved issues as accepted, output is final |
| **Request more iterations** | Sets a new max and re-runs the loop |

> **Script fixes:** If a developer wants to fix scripts based on validation errors, they use Claude to fix them directly.

---

## Iteration Limits and Exit Conditions

| Condition | What Happens |
|-----------|-------------|
| Human accepts output after first validation | No refinement — done |
| All issues resolved during loop | Loop exits → human final review |
| Max iterations reached (default: 3) | Unresolved issues reported → human final review |
| No improvement between iterations | Loop exits → human final review |

The refinement loop runs uninterrupted. Humans are involved at two points: after first validation (decide whether to refine) and after the loop exits (final review). If the human adds feedback at either point (and it passes validation), the loop can run with the new input.

The max iteration count defaults to **3** but can be changed by the user during review.

> **No limit on human feedback cycles.** The max iteration count only constrains the inner automated loop (refiner ↔ validator). The outer human review loop has no cap — users can give feedback and re-trigger the loop as many times as needed until they are satisfied with the output.

---

## Folder Responsibilities

| Folder / File | What It Holds | Layer 1 (Scripts) | Layer 2 (Agentic) |
|--------------|--------------|-------------------|-------------------|
| `knowledgebase/` | Reference knowledge — standards, rules, conventions, best practices | Scripts reference for transformation rules | Validator references for standards compliance |
| `inputs/` | Source data — the actual files to process | Scripts read and transform into deliverables | Validator compares output against (ground truth) |
| `scripts/` | Python scripts + validator/refiner scripts | Contains the transformation logic | Validator and refiner scripts live here; refiner does **not** modify other scripts |
| `scripts/prompts.py` | All prompts for validator and refiner scripts | Not used | Central prompt store — both scripts import from here |
| `output/` | Final deliverables | Scripts generate deliverables here | Validator reads for comparison; Refiner patches files here directly |
| `research/` | Research findings | Analysis from research phase | Validator may reference for context |
| `plans/` | Plans and master plan | Blueprint for implementation | Validator may reference for expected structure |

---

## Guardrails for the Agentic Layer

The agentic layer has its own set of guardrails separate from the toolkit pipeline guardrails. These ensure the validator and refiner scripts operate safely, predictably, and within defined boundaries.

### 1. Folder Boundaries

Each script has strict read/write permissions. Violations are blocked, not just logged.

| Script | Can Read | Can Write | Hard Block (cannot touch) |
|--------|----------|-----------|--------------------------|
| **Validator** (`scripts/validator.py`) | `inputs/`, `output/`, `knowledgebase/`, `scripts/`, `plans/`, `research/` | Validation reports only | Cannot modify any source, script, or output file — strictly read-only |
| **Refiner** (`scripts/refiner.py`) | `output/`, validation reports, `scripts/prompts.py`, `knowledgebase/`, `inputs/` (read-only, for source reference) | `output/` only | `inputs/`, `knowledgebase/`, `scripts/` — never modified by the refiner |

**Why this matters:**
- `inputs/` is the ground truth — if a script modifies it, validation becomes meaningless
- `knowledgebase/` is the reference standard — if a script changes it, all rules shift
- `scripts/` contains the transformation logic — only developers modify this
- The validator must be read-only to ensure its findings are objective and trustworthy

### 2. Refiner Guardrails

Rules that constrain what the refiner script can do when patching output.

| Guardrail | Rule | What Happens on Violation |
|-----------|------|--------------------------|
| **Output-only writes** | Refiner can only write to files in `output/` — no other directory | Block the change — hard reject any write outside `output/` |
| **Scope limit** | Refiner can only change content directly related to the issue being fixed — no unrelated cleanup or "improvements" | Flag the change for review; do not auto-apply |
| **No script modification** | Refiner cannot modify any scripts in `scripts/` | Block immediately |
| **No input/knowledge mutation** | Hard block on writing to `inputs/` or `knowledgebase/` | Reject immediately — these folders are read-only for all scripts |
| **Diff size cap** | If a single fix changes more than 50 lines in an output file, flag it instead of applying | Pause and add to human review queue instead of auto-applying |
| **Source-grounded patches** | Every patch must reference specific source data from `inputs/` or rules from `knowledgebase/` that justify the change | Reject ungrounded patches — the refiner cannot make changes it cannot justify from source |

### 3. Loop Guardrails

Rules that govern the automated refinement loop itself.

| Guardrail | Rule | What Happens on Violation |
|-----------|------|--------------------------|
| **Max iterations enforced** | Hard ceiling on iteration count (default: 3, user-configurable) — scripts cannot override | Loop exits and proceeds to human review |
| **Accuracy regression check** | If overall accuracy drops after an iteration compared to the previous iteration | Stop the loop, proceed to human review |
| **Stale loop detection** | If the same issue fails to improve in two consecutive iterations | Skip the issue, mark as unresolved, move to next issue |
| **Iteration timeout** | Max wall-clock time per iteration (configurable) | Kill the iteration, proceed to human review |
| **No infinite retry** | An issue that has failed to improve in every iteration cannot be retried in the same loop | Mark as unresolved |

### 4. Feedback Validation Guardrails

Rules that ensure human feedback is valid before it enters the refinement loop.

| Guardrail | Rule | What Happens on Violation |
|-----------|------|--------------------------|
| **Relevance check** | Feedback must relate to issues in the validation report or to output files | Reject with explanation — ask user to rephrase or clarify |
| **Actionability check** | Feedback must be actionable as an output patch | Reject — inform the user that the feedback is not actionable |
| **Source consistency check** | Feedback cannot contradict the ground truth in `inputs/` or rules in `knowledgebase/` | Reject — inform user that feedback contradicts source data |

### 5. Validation Report Guardrails

Rules that ensure validator output is reliable.

| Guardrail | Rule | What Happens on Violation |
|-----------|------|--------------------------|
| **Source traceability** | Every issue in the validation report must reference a specific source file in `inputs/` and a specific output file | Issues without source references are flagged as unverifiable |
| **No hallucinated issues** | Validator cannot report issues for content that doesn't exist in the source files | Cross-check: if the referenced source file or line doesn't exist, drop the issue |
| **Accuracy metric consistency** | Overall accuracy must be calculated from individual issue checks, not estimated | If accuracy metric doesn't match the sum of passed/failed checks, flag as inconsistent |

### Guardrails Summary

```
┌─────────────────────────────────────────────────────────────────┐
│                    GUARDRAILS OVERVIEW                           │
│                                                                 │
│  FOLDER BOUNDARIES                                              │
│  ├── Validator: read-only everywhere                            │
│  ├── Refiner: write to output/ only                             │
│  └── inputs/, knowledgebase/, scripts/: immutable for refiner   │
│                                                                 │
│  REFINER CONSTRAINTS                                            │
│  ├── Output-only writes (no script modification)                │
│  ├── Scope limited to the issue being fixed                     │
│  ├── Diff size cap (50 lines per fix)                           │
│  └── Every patch must be source-grounded                        │
│                                                                 │
│  LOOP CONSTRAINTS                                               │
│  ├── Hard max iterations (default: 3)                           │
│  ├── Stop on accuracy regression                                │
│  ├── Stale loop detection (same failure twice → skip)           │
│  └── Timeout per iteration                                      │
│                                                                 │
│  FEEDBACK VALIDATION                                            │
│  ├── Relevance to validation issues                             │
│  ├── Actionable as output patch                                 │
│  └── Consistent with source data                                │
│                                                                 │
│  VALIDATION INTEGRITY                                           │
│  ├── Every issue traced to a source file                        │
│  ├── No hallucinated issues                                     │
│  └── Accuracy metric matches actual checks                      │
│                                                                 │
│  LOGGING & AUDIT TRAIL                                          │
│  ├── Every agent decision logged with reasoning                 │
│  ├── Accuracy progression tracked across iterations             │
│  ├── All human feedback captured verbatim                       │
│  └── Full iteration history retained                            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Logging & Audit Trail

Every action taken by the validator and refiner scripts is logged. This provides full traceability — any output can be traced back to the decisions that produced it.

### What Gets Logged

| Category | What Is Captured | When |
|----------|-----------------|------|
| **Script decisions** | Every choice made by validator/refiner — what to patch, which approach, why | Every decision point |
| **Validation results** | Issues found, accuracy score, passed/failed checks per file | After every validator run |
| **Refiner actions** | Output file patched, lines changed, which issue the patch addresses, diff of changes | Every output patch |
| **Human feedback** | User's review comments, decisions (accept/proceed/feedback), verbatim text | At each human review point |
| **Feedback validation** | Whether feedback was accepted or rejected, reason for rejection | When human provides feedback |
| **Accuracy progression** | Accuracy score per iteration, trend (improving / stagnant / regressing) | After every validator run |
| **Errors / exceptions** | Stack traces, failed script executions, unexpected behavior | On any failure |

### Log Structure

All logs are written to `thoughts/logs/agentic/` with one file per run:

```
thoughts/logs/agentic/
├── run_2026-02-20_103000/
│   ├── iteration_0_validation.yaml      # First validation (before refinement)
│   ├── human_review_1.yaml              # First human review + feedback
│   ├── feedback_validation_1.yaml       # Feedback validation result
│   ├── iteration_1_refiner.yaml         # Refiner actions in iteration 1
│   ├── iteration_1_validation.yaml      # Validator re-run after iteration 1
│   ├── iteration_2_refiner.yaml         # Refiner actions in iteration 2
│   ├── iteration_2_validation.yaml      # Validator re-run after iteration 2
│   ├── iteration_3_refiner.yaml         # Refiner actions in iteration 3
│   ├── iteration_3_validation.yaml      # Validator re-run after iteration 3
│   ├── human_review_final.yaml          # Final human review + feedback
│   ├── accuracy_progression.yaml        # Accuracy scores across all iterations
│   └── run_summary.yaml                 # Full run summary
```

### Example: Iteration Log Entry

```yaml
# iteration_1_refiner.yaml
iteration: 1
timestamp: "2026-02-20T10:35:00"
trigger: "validation_errors + human_feedback"
issues_attempted:
  - issue_id: V-001
    description: "Entity X from source not present in output"
    approach: "Added missing entity definition to output schema file"
    output_file_patched: "output/customer_schema.sql"
    lines_changed: 8
    diff: |
      + CREATE TABLE entity_x (
      +     id INTEGER PRIMARY KEY,
      +     name VARCHAR(100),
      +     ...
      + );
    source_reference: "inputs/customer_model.xlsx, Sheet: Entities, Row: 15"
  - issue_id: V-002
    description: "Field Y mapped to wrong data type"
    approach: "Corrected data type in output file"
    output_file_patched: "output/customer_schema.sql"
    lines_changed: 1
    diff: |
      - field_y VARCHAR(50)
      + field_y INTEGER
    source_reference: "knowledgebase/type_mappings.yaml, mapping: source_type_x → INTEGER"
human_feedback_applied: "Prioritize entity X — it's critical for downstream."
```

### Example: Feedback Validation Log Entry

```yaml
# feedback_validation_1.yaml
timestamp: "2026-02-20T10:33:00"
human_feedback_raw: "Prioritize entity X — it's critical for downstream. Also change the database engine to PostgreSQL."
validation_results:
  - check: relevance
    item: "Prioritize entity X"
    result: PASS
    reason: "Entity X is referenced in V-001 from the validation report"
  - check: actionability
    item: "Prioritize entity X"
    result: PASS
    reason: "Can be addressed as an output patch — add entity to output file"
  - check: relevance
    item: "Change database engine to PostgreSQL"
    result: FAIL
    reason: "Database engine is not referenced in any validation issue"
accepted_feedback: "Prioritize entity X — it's critical for downstream."
rejected_feedback:
  - item: "Change database engine to PostgreSQL"
    reason: "Not related to any validation issue in the report"
```

### Example: Accuracy Progression

```yaml
# accuracy_progression.yaml
run_id: "run_2026-02-20_103000"
progression:
  - stage: "initial_validation"
    accuracy: 87.5
    issues_found: 4
  - stage: "iteration_1"
    accuracy: 93.2
    issues_patched: 2
    issues_remaining: 2
  - stage: "iteration_2"
    accuracy: 96.8
    issues_patched: 1
    issues_remaining: 1
  - stage: "iteration_3"
    accuracy: 98.5
    issues_patched: 1
    issues_remaining: 0
trend: "improving"
```

---

## Summary

```
┌──────────────────────────────────────────────────────────────┐
│                    SCRIPTS-ONLY MODE                         │
│                                                              │
│  knowledgebase/ ─(rules)──▶ scripts/ ──▶ output/            │
│  inputs/ ────────(data)───▶                                  │
│                                                              │
│  Simple. Manual review. Full control.                        │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│                     AGENTIC MODE                             │
│                                                              │
│  knowledgebase/ ─(rules)──▶ scripts/ ──▶ output/            │
│  inputs/ ────────(data)───▶                  │              │
│       │                                      ▼              │
│       │                               ┌────────────┐        │
│       └─(ground truth)───────────────▶│ VALIDATOR   │        │
│                                       └─────┬──────┘        │
│                                             │               │
│                                             ▼               │
│                                       ┌────────────┐        │
│                                       │  HUMAN     │        │
│                                       │ (proceed?) │        │
│                                       └─────┬──────┘        │
│                                             │               │
│                                             ▼               │
│                                       ┌────────────┐        │
│                            ─────────▶ │  REFINER   │        │
│                           │           │ (patches   │        │
│                           │           │  output/)  │        │
│                      VALIDATOR        └─────┬──────┘        │
│                      (re-run)               │               │
│                                             ▼               │
│                                       ┌────────────┐        │
│                                       │  HUMAN     │        │
│                                       │ (final)    │        │
│                                       └────────────┘        │
│                                                              │
│  Refiner patches output/ only. Developer uses Claude for     │
│  any script fixes based on validation errors.                │
└──────────────────────────────────────────────────────────────┘
```
