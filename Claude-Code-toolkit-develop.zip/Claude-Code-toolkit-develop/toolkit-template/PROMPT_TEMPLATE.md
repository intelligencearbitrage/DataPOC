# Prompt Template for Developers

Guidelines for writing prompts that produce grounded, hallucination-free output from the agent team. Based on CLAUDE_guidelines.md principles.

---

## Before You Prompt

1. **Place all source files in `knowledgebase/`** — agents should never need to invent data. If the source doesn't exist, agents can't produce accurate output.
2. **Fill in `prompts.md` completely** — every blank placeholder is a place where an agent might guess.
3. **Be specific, not vague** — "generate DDL for Snowflake" is better than "generate some database stuff."

---

## Prompt Structure

Use this structure when writing instructions in `prompts.md` or when giving commands to the agent team.

### 1. State the Goal (What, not How)

```
GOOD: "Produce a data dictionary in YAML for every table found in knowledgebase/schema.sql"
BAD:  "Create some documentation"
```

**Rules:**
- Name the exact deliverable (what format, what content)
- Name the exact source (which file in knowledgebase/)
- Name where the output goes (which folder under output/)

### 2. Define the Source of Truth

```
GOOD: "Use only the entities found in knowledgebase/data_model.xlsx, Sheet 'Entities', columns A-F"
BAD:  "Use the data model" (which one? which parts?)
```

**Rules:**
- Point to specific files, sheets, columns, sections
- If multiple sources exist, state the priority order
- If something is NOT a source, say so explicitly: "Do not use external knowledge for entity names"

### 3. Set Boundaries on What to Include

```
GOOD: "Only include tables that appear in the source file. Do not add tables that are not in the source."
BAD:  (leaving this unstated — agents may add "helpful" extras)
```

**Rules:**
- Explicitly state what should NOT be generated
- If you only want a subset, name it
- If agents should not infer or extrapolate, say: "Do not infer items not explicitly present in the source"

### 4. Define Naming and Format Conventions

```
GOOD: "Table names: UPPER_SNAKE_CASE with prefix SILVER_. Column names: UPPER_SNAKE_CASE.
       Data types: use Snowflake-compatible types (VARCHAR, NUMBER, DATE, TIMESTAMP_NTZ, BOOLEAN)"
BAD:  "Use standard naming" (standard according to whom?)
```

**Rules:**
- Spell out the exact convention — don't rely on "standard" or "typical"
- Provide examples where possible
- If there's a reference file with conventions, point to it

### 5. State What "Done" Looks Like

```
GOOD: "Success means:
       - One .sql file per domain in output/ddl/
       - Every table from the source has a corresponding CREATE TABLE
       - Every column has a data type and COMMENT
       - File is valid Snowflake SQL (no syntax errors)"
BAD:  "Make it complete"
```

**Rules:**
- List verifiable success criteria (things an agent can check)
- Include both positive (what must exist) and negative (what must not exist) criteria
- Tie criteria back to the source: "every entity in the source has a corresponding output"

### 6. Handle Unknowns Explicitly

```
GOOD: "If a column's data type is not specified in the source, mark it as VARCHAR(255)
       and add a comment: '-- DATA TYPE NOT IN SOURCE, NEEDS REVIEW'"
BAD:  (saying nothing — agents will guess or fabricate types)
```

**Rules:**
- For every field where the source might be incomplete, state a fallback behavior
- Options: use a default value, flag for review, skip it, or ask via expert consultation
- Never leave gaps unaddressed — that's where hallucination happens

---

## Anti-Hallucination Checklist

Before submitting your prompts.md, verify:

- [ ] Every deliverable names a specific source file in knowledgebase/
- [ ] No vague terms ("standard", "typical", "appropriate", "best practice") without definition
- [ ] Naming conventions are spelled out with examples, not left to interpretation
- [ ] Success criteria are verifiable (an agent can check pass/fail)
- [ ] Behavior for missing/incomplete data is explicitly defined
- [ ] Scope boundaries are stated (what to include AND what to exclude)
- [ ] No requirement relies on external knowledge the agents don't have access to

---

## Example: Well-Structured vs Poorly-Structured Prompt

### Poorly-Structured (hallucination-prone)

```markdown
## Objective
Build a data model for our customer domain.

## Deliverables
- DDL scripts
- Documentation

## Requirements
- Use best practices
- Include standard audit columns
```

Problems: Which source? What format? What "best practices"? What "standard" columns? Agents will invent answers.

### Well-Structured (grounded)

```markdown
## Objective
Generate Snowflake DDL and YAML data dictionaries for the customer domain,
based exclusively on the entity definitions in knowledgebase/customer_model.xlsx.

## Source Materials
- knowledgebase/customer_model.xlsx — Sheet "Entities" contains table definitions (columns A-H),
  Sheet "Relationships" contains foreign keys (columns A-D)
- Do not use any entities or attributes not found in this file.

## Deliverables
- output/ddl/customer_ddl.sql — one CREATE TABLE per entity in the source
- output/docs/customer_dictionary.yaml — one entry per table with all column metadata

## Naming Conventions
- Tables: SILVER_CUSTOMER_{ENTITY_NAME} in UPPER_SNAKE_CASE
- Columns: UPPER_SNAKE_CASE
- Primary keys: {ENTITY_NAME}_ID

## Audit Columns (add to every table)
- RECORD_SOURCE VARCHAR(100)
- LOAD_TIMESTAMP TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
- EFFECTIVE_FROM DATE
- EFFECTIVE_TO DATE DEFAULT '9999-12-31'
- IS_CURRENT BOOLEAN DEFAULT TRUE

## Handling Missing Data
- If a column has no data type in the source: use VARCHAR(255) and add comment "TYPE_NOT_IN_SOURCE"
- If a relationship references a table not in the source: log it in output/docs/gaps.yaml, do not create the table

## Success Criteria
- [ ] Every entity in Sheet "Entities" has a CREATE TABLE in the DDL
- [ ] Every column in the source has a corresponding column in the DDL
- [ ] DDL is valid Snowflake SQL (parseable without errors)
- [ ] No tables or columns exist in the output that are not in the source
- [ ] All gaps are documented in output/docs/gaps.yaml
```

---

## Quick Reference: Prompt Quality Signals

| Signal | Grounded Prompt | Hallucination-Prone Prompt |
|--------|----------------|---------------------------|
| Source | "from knowledgebase/file.xlsx, Sheet X" | "from the data model" |
| Scope | "only entities in the source" | (unstated) |
| Naming | "UPPER_SNAKE_CASE, prefix SILVER_" | "use standard naming" |
| Missing data | "mark as VARCHAR(255) with flag" | (unstated) |
| Success | "every source entity has a DDL table" | "make it complete" |
| Exclusions | "do not add tables not in source" | (unstated) |
