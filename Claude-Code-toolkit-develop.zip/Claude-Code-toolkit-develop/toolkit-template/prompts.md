# Project: [YOUR PROJECT NAME]

## Objective
<!-- What solution are you building? Examples: reverse engineering, forward engineering, data modeling, data governance, testing, migration, etc. -->
[Replace with your project objective]

## Solution Type
<!-- Check the type that best describes your solution -->
- [ ] Reverse Engineering
- [ ] Forward Engineering
- [ ] Data Modeling
- [ ] Data Governance
- [ ] Testing / Validation
- [ ] Migration / Modernization
- [ ] Other: [describe]

## Source Materials
<!-- What inputs will the agent team work with? Place files in the knowledgebase/ directory -->
- File 1: `knowledgebase/[filename]` - [description of what this file contains]
- File 2: `knowledgebase/[filename]` - [description]

## Target Deliverables
<!-- What outputs do you need generated in output/? -->
- [ ] Deliverable 1: [describe what should be produced]
- [ ] Deliverable 2: [describe]
- [ ] Deliverable 3: [describe]

## Technical Requirements
<!-- Platforms, standards, conventions, tools to use -->
- Target platform: [describe]
- Conventions: [describe any naming, formatting, structural rules]
- Standards to follow: [describe any industry or internal standards]
- Tools / libraries: [describe any required dependencies]

## Component Structure
<!-- How should the solution be organized? List your components/modules/domains -->
- Component 1: [name] - [description and scope]
- Component 2: [name] - [description and scope]
- Component 3: [name] - [description and scope]

## Quality Requirements
<!-- What standards must outputs meet? -->
- [ ] Requirement 1: [describe]
- [ ] Requirement 2: [describe]
- [ ] Requirement 3: [describe]

## Success Criteria
<!-- How do you measure completeness? -->
- [ ] Criterion 1: [describe]
- [ ] Criterion 2: [describe]
- [ ] Criterion 3: [describe]

## Notes
<!-- Any additional context, constraints, or preferences -->
[Add any additional notes here]
