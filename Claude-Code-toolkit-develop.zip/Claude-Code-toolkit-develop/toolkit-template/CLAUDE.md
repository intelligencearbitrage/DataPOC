# Toolkit Template — Project Instructions

## Role & Context

You are an AI agent operating within the **Toolkit Template** — a framework for building multi-agent pipelines using Claude Code's Agent Teams feature. Your primary task is to follow the 4-phase pipeline (Research → Plan → Build → Review) to analyze inputs and produce deliverables.

## General Principles

### Pipeline Mindset
- **Follow the phases**: Research thoroughly before planning. Plan completely before building. Review everything before delivering.
- **Evidence over assumption**: Every claim must trace back to a source file. If you can't cite the source, flag it as an assumption.
- **Reproducibility**: Agents produce scripts. Scripts produce deliverables. Anyone can re-run the scripts without AI.
- **Quality gates are non-negotiable**: Phase gates (GATE tasks) must PASS before the next phase starts. Never skip validation.

### Agent Coordination
- **Shared task list is the single source of truth**: All coordination happens through `TaskCreate`, `TaskUpdate`, `TaskList`, `TaskGet`.
- **Task descriptions must be self-contained**: Another agent must be able to complete your task without asking questions.
- **Write findings to files, not task descriptions**: Use `research/`, `plans/`, `scripts/`, `output/` folders. Tasks point to files.
- **Ask, don't assume**: For business/domain ambiguity, create a `CLARIFICATION NEEDED` task (L1.5) and block until the user answers. Only self-resolve (L1) for technical decisions.
- **Escalate when stuck**: Follow `.claude/rules/escalation.md` — L1 self-resolve, L1.5 clarify with user, L2 consult expert, L3 escalate to lead, L4 human required.

---

## Workflow Instructions

### When Starting a New Project

1. Read `prompts.md` — this defines what to build, which source materials to use, and what deliverables to produce
2. Read `GUARDRAILS.yaml` — this defines quality standards, folder boundaries, and phase gates
3. Read `SETUP_GUIDE.md` — this documents the project configuration and customization choices
4. Check `.claude/rules/` — active rules are auto-loaded based on file paths you work with

### Folder Conventions

| Folder | Purpose | Who Writes |
|--------|---------|------------|
| `knowledgebase/` | Reference materials (standards, rules, conventions) | Human (read-only) |
| `inputs/` | Source data for scripts to process | Human (read-only) |
| `research/` | Analysis findings from Phase 1 | Researcher agent |
| `plans/` | Master plan and component plans from Phase 2 | Analyzer agent |
| `scripts/` | Python scripts from Phase 3 | Builder agent |
| `output/` | Final deliverables (produced by running scripts) | Scripts |
| `testscripts/` | Review reports and validation results from Phase 4 | Reviewer agent |

### Code Quality Standards

All generated scripts must:
- Be **idempotent** (safe to re-run)
- Use **pathlib** for all file operations
- Include **error handling** for file I/O
- Include **type hints** and **docstrings**
- Read from `inputs/` + `knowledgebase/`, write to `output/`
- Follow naming conventions in `GUARDRAILS.yaml`
- Contain **no hardcoded values** — read configuration from plans

---

## Available Resources

### Agents (11)
See `.claude/agents/` for full definitions. The lead orchestrator coordinates all work.

### Skills (5)
| Skill | Purpose |
|-------|---------|
| `manage-tasks` | Task coordination patterns for agent teams |
| `parse-input` | Input file parsing patterns (Excel, XML, JSON, SQL) |
| `generate-output` | Output generation patterns (text, YAML, templates) |
| `validate-quality` | Quality validation patterns and guardrail checks |
| `self-review` | Self-check procedure before completing tasks |

### Rules (auto-loaded from `.claude/rules/`)
| Rule | Loaded When |
|------|-------------|
| `escalation.md` | Always (no path scope) |

Developers add domain-specific rules by copying from `guidelines/rules-reference/` into `.claude/rules/`. See `guidelines/rules-reference/README.md` for details and copy commands.

---

## Key Documents

| Document | What It Tells You |
|----------|-------------------|
| `prompts.md` | What to build — source materials, components, deliverables |
| `GUARDRAILS.yaml` | Quality standards — folder boundaries, naming, phase gates |
| `SETUP_GUIDE.md` | How this project was configured |
| `SOLUTION_APPROACH.md` | Architecture and pipeline design |
| `README.md` | Overview of the toolkit template |
