# Gold Standard Rules Reference — Legacy Data Stack Modernization

These are **reference files for developers**, NOT active Claude rules. Claude does NOT auto-load files from this directory.

## What These Are

Production-quality domain rules for the **Legacy Data Stack Modernization** archetype (Teradata/Informatica/SSIS to Snowflake/Databricks). They demonstrate the depth, structure, and level of detail expected when creating rules for any archetype.

## Files

### Source Technology Rules (Reverse Engineering)
| File | Lines | Covers |
|------|-------|--------|
| `source-teradata-sql.md` | ~243 | Teradata SQL, BTEQ, SPL, FastLoad/MultiLoad, temporal tables, data types, anti-patterns |
| `source-informatica-xml.md` | ~399 | PowerCenter XML parsing, transformations, expressions, variable ports, lookups, session properties |
| `source-ssis-dtsx.md` | ~306 | .dtsx XML structure, components, Script Tasks, precedence constraints, deployment models |

### Target Platform Rules (Forward Engineering)
| File | Lines | Covers |
|------|-------|--------|
| `converted-snowflake-sql.md` | ~319 | Snowflake architecture, migration patterns, stored procs, T-SQL conversion, security, performance |
| `converted-databricks-sql.md` | ~344 | Medallion architecture, DLT, Auto Loader, Unity Catalog, Teradata-to-Spark conversion |

### Cross-Cutting Methodology
| File | Lines | Covers |
|------|-------|--------|
| `migration-methodology.md` | ~308 | 4-level validation framework, complexity scoring, lineage tracing, hybrid conversion strategy |
| `etl-python.md` | ~69 | Python ETL/orchestration standards, Airflow DAG patterns |
| `validation-queries.md` | ~105 | Validation query templates (Level 1-3), output format standards |

## How to Use

1. **Study these files** to understand the expected depth and structure
2. **If your project is a legacy data stack modernization**: copy the relevant files to `.claude/rules/` — they become active rules that Claude loads contextually based on `paths:` frontmatter
3. **If your project is a different archetype**: use these as examples to create your own rule files in `.claude/rules/`, following the same structure and depth

### Quick Start for Legacy Data Stack Modernization

```bash
# Copy the rules you need to .claude/rules/ to activate them
# Only copy what applies to your source and target technologies

# Source: Teradata
cp guidelines/rules-reference/source-teradata-sql.md .claude/rules/

# Source: Informatica
cp guidelines/rules-reference/source-informatica-xml.md .claude/rules/

# Source: SSIS
cp guidelines/rules-reference/source-ssis-dtsx.md .claude/rules/

# Target: Snowflake
cp guidelines/rules-reference/converted-snowflake-sql.md .claude/rules/

# Target: Databricks
cp guidelines/rules-reference/converted-databricks-sql.md .claude/rules/

# Cross-cutting (copy if applicable)
cp guidelines/rules-reference/migration-methodology.md .claude/rules/
cp guidelines/rules-reference/etl-python.md .claude/rules/
cp guidelines/rules-reference/validation-queries.md .claude/rules/
```

After copying, review the `paths:` frontmatter in each file and adjust to match your project's directory structure.
