---
paths:
  - "src/etl/**/*.py"
  - "src/orchestration/**/*.py"
  - "dags/**/*.py"
  - "pipelines/**/*.py"
  - "jobs/**/*.py"
---

# ETL Orchestration Python Rules

You are writing or reviewing **Python ETL/orchestration code** (Airflow DAGs, Databricks notebooks, scripts, etc.).

## Standards

- Use parameterized SQL (never f-strings for query building - use parameter binding to prevent SQL injection)
- Implement retry logic with exponential backoff for external calls
- Log at INFO level for pipeline progress, WARNING for recoverable issues, ERROR for failures
- Include execution metadata (run_id, start_time, record counts) in all log messages
- Use environment variables or secrets managers for credentials (never hard-code)
- Follow the project's existing patterns for connection management

## Migration-Specific Guidance

- When converting Informatica workflows to Python orchestration, each session maps to a task/step
- When converting SSIS control flow to Python, precedence constraints map to task dependencies
- Preserve the original error handling semantics (fail-fast vs continue-on-error)
- Include validation steps after each major data movement
- Document the original source system object in code comments for traceability

## Airflow DAG Patterns for Migration

```python
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator
from datetime import datetime

# Replacing: Informatica wf_daily_customer_load
with DAG(
    dag_id="daily_customer_load",
    schedule_interval="0 6 * * *",
    start_date=datetime(2024, 1, 1),
    catchup=False,
    tags=["migration", "customer"],
) as dag:

    # Replacing: Informatica s_truncate_staging (Pre-Session SQL)
    truncate_staging = SnowflakeOperator(
        task_id="truncate_staging",
        sql="TRUNCATE TABLE staging.stg_customer;",
    )

    # Replacing: Informatica s_load_staging (Session with mapping m_load_stg_customer)
    load_staging = SnowflakeOperator(
        task_id="load_staging",
        sql="CALL sp_load_stg_customer(%(batch_id)s);",
        parameters={"batch_id": "{{ run_id }}"},
    )

    # Replacing: Informatica s_merge_dim (Session with mapping m_merge_dim_customer)
    merge_dim = SnowflakeOperator(
        task_id="merge_dim_customer",
        sql="CALL sp_merge_dim_customer(%(batch_id)s);",
        parameters={"batch_id": "{{ run_id }}"},
    )

    truncate_staging >> load_staging >> merge_dim
```
