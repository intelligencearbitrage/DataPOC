---
paths:
  - "**/*.sql"
  - "**/*.py"
  - "**/*.xml"
  - "**/*.dtsx"
  - "**/*.md"
---

# Migration Methodology & Cross-Cutting Concerns

This rule file contains migration methodology that applies across all source and target platforms.

## Discovery & Assessment

Before writing any migration code:
1. **Inventory all objects**: Tables, views, stored procedures, ETL jobs, reports
2. **Score complexity**: Simple (1:1 translation), Medium (requires redesign), Complex (requires new approach)
3. **Map dependencies**: Build a graph of which ETL loads which tables, which reports read which tables
4. **Identify data volumes**: Row counts, data sizes, growth rates per table
5. **Catalog data types**: Flag types with no direct target equivalent (PERIOD, INTERVAL, custom UDTs)
6. **Document business SLAs**: Load windows, freshness requirements, availability requirements

## Data Lineage Tracing

When analyzing end-to-end lineage across heterogeneous systems:
- **Column-level lineage**: Trace each target column back through ETL transformations to ultimate source column
- **Cross-system lineage**: Source DB -> Informatica Mapping -> Staging Table -> SSIS Package -> Target Table -> Report
- **Document lineage in a standard format**:
  ```
  Target: DW.fact_sales.total_amount
    <- Informatica EXP_CALC.o_total (expression: unit_price * quantity * (1 - discount_pct))
      <- Informatica SQ_ORDERS.unit_price <- SOURCE_DB.orders.unit_price
      <- Informatica SQ_ORDERS.quantity <- SOURCE_DB.orders.qty
      <- Informatica LKP_DISCOUNT.discount_pct <- SOURCE_DB.promotions.pct (lookup on promo_code)
  ```

## 4-Level Validation Framework

Every migrated component must pass all four levels before sign-off:

**Level 1: Structural Validation** (automated, run first)
- Row count comparison: Source `COUNT(*)` = Target `COUNT(*)`
- Column count verification: Target table has expected number of columns
- Data type verification: Each target column matches the expected type and precision
- Primary key / unique key integrity: No unexpected duplicates in target
- NOT NULL constraint validation: Columns that were non-null in source remain non-null in target

**Level 2: Data Content Validation** (automated, run after Level 1 passes)
- Column-level checksums: `SUM(HASH(col1, col2, ...))` comparison between source and target
- Full-row hash comparison: Hash every row on source and target, compare sorted hash lists
- Sample record comparison: Random sample of N records (minimum 100 or 1% of rows, whichever is larger) compared field-by-field
- Boundary value checks: MIN/MAX of every numeric and date column must match

**Level 3: Statistical Validation** (automated + manual review)
- Aggregate validation: `SUM`, `MIN`, `MAX`, `AVG`, `COUNT DISTINCT` on all numeric columns
- NULL count comparison: `COUNT(*) - COUNT(col)` for every column on both source and target
- Distribution analysis: Top-N value frequency counts for categorical columns (compare source vs target)
- Outlier detection: Identify values in target that fall outside the source's observed range
- Referential integrity: Foreign key relationships hold in the target (e.g., every `fact.dim_key` exists in `dim.key`)

**Level 4: Functional Validation** (manual + stakeholder sign-off)
- Business report comparison: Run 3-5 key business reports/queries against both source and target, compare outputs
- End-to-end pipeline testing: Execute the full orchestrated pipeline (not just individual SQL), verify final state
- Incremental load testing: Run pipeline with a delta/incremental batch, verify correct MERGE/upsert behavior
- Error/edge case replay: Re-process known problematic records (NULLs, special characters, boundary dates)
- Performance benchmarking: Compare query elapsed times for representative workloads under production-like concurrency

### Tolerance Thresholds

| Metric | Tolerance | Action if Exceeded |
|---|---|---|
| **Row count** | Exact match (0 difference) | Fail - investigate missing/extra rows |
| **DECIMAL/INTEGER aggregates** (SUM, MIN, MAX) | Exact match | Fail - trace to specific rows |
| **FLOAT/DOUBLE aggregates** (SUM, AVG) | <= 0.001% relative difference | Fail if > 0.001% - likely a casting or rounding difference |
| **NULL counts per column** | Exact match | Fail - likely a JOIN or COALESCE behavioral difference |
| **COUNT DISTINCT** | Exact match | Fail - deduplication or case-sensitivity issue |
| **String column checksums** | Exact match | Warn - check trailing spaces, case sensitivity, encoding |
| **Date column MIN/MAX** | Exact match | Fail - check timezone or format conversion |
| **Distribution top-10 frequencies** | <= 0.1% relative difference per bucket | Investigate - may indicate filter or grouping difference |

### Validation Progression Rule

Do **not** proceed to Level N+1 until Level N passes. Failures at lower levels (especially Level 1) indicate fundamental issues that will cascade and produce misleading results at higher levels.

## Common Migration Pitfalls

| Pitfall | Source Behavior | Target Behavior | Fix |
|---|---|---|---|
| **NULL in string concatenation** | Teradata: NULL poisons result | Snowflake: same. Databricks: same | Use COALESCE before concat |
| **Empty string vs NULL** | Teradata: '' and NULL can be distinct | Snowflake: '' and NULL are distinct | Explicit handling required |
| **Integer division** | Teradata: 5/2 = 2 (integer) | Snowflake: 5/2 = 2.5 (decimal) | Cast to match legacy behavior if needed |
| **Date arithmetic** | Teradata: date - date = interval integer | Snowflake: DATEDIFF | Replace with DATEDIFF explicitly |
| **Case sensitivity** | Teradata: NOT CASESPECIFIC by default | Snowflake: case-sensitive by default | Add UPPER/LOWER or COLLATE |
| **Trailing spaces** | Teradata CHAR: pads with spaces | Snowflake CHAR: pads with spaces | Use VARCHAR or TRIM consistently |
| **Numeric precision** | Teradata DECIMAL(18,2) | Ensure matching precision on target | Explicit DECIMAL(p,s) declarations |
| **Sort order with NULLs** | Teradata: NULLs sort high | Snowflake: NULLs sort high (configurable) | Use NULLS FIRST/LAST explicitly |
| **Boolean handling** | Teradata: no native BOOLEAN | Snowflake/Databricks: native BOOLEAN | Convert CHAR(1) Y/N or INT 0/1 patterns |
| **Timezone handling** | Teradata: varies by config | Platform-specific | Normalize to UTC, use TIMESTAMP_TZ/TIMESTAMP_NTZ explicitly |
| **Implicit casting** | Teradata: lenient string-to-number | Snowflake: stricter | Add explicit CAST/TRY_CAST |
| **GROUP BY ordinal** | Teradata: GROUP BY 1,2 allowed | Snowflake: allowed. Databricks: allowed | Works on both but prefer column names |

## ETL Process Documentation Template

For every legacy ETL process being migrated, produce this standardized document:

```markdown
## ETL Process: [Name/ID]

### Overview
- **Purpose**: [One-sentence business description]
- **Frequency**: [Daily/Hourly/Monthly/Ad-hoc]
- **Scheduler**: [TWS/Control-M/cron/AutoSys job name]
- **Criticality**: [High/Medium/Low]
- **Source System**: [Teradata/Informatica/SSIS]
- **Target Platform**: [Snowflake/Databricks]

### Source Tables
| Database.Table | Access Type | Key Columns Used | Filter Conditions | Estimated Rows |
|---|---|---|---|---|

### Target Tables
| Database.Table | DML Operation | Key Columns | Load Strategy | Partitioning |
|---|---|---|---|---|

### Transformation Logic (Business Rules)
1. [Step description with business rule, NOT just SQL syntax]
   - Business Rule: "Active customers are those with status A or B and effective date not in future"
   - Source Implementation: `CASE WHEN status_cd IN ('A','B') AND eff_date <= CURRENT_DATE THEN 'ACTIVE'`
2. [Next step...]

### Column-Level Lineage
| Target Column | Source Column(s) | Transformation | Notes |
|---|---|---|---|

### Dependencies
- **Upstream**: [Processes that must complete first]
- **Downstream**: [Processes that depend on this one]
- **External**: [Files, APIs, or other systems involved]

### Platform-Specific Flags (check all that apply)
- [ ] Teradata SET table deduplication
- [ ] Teradata QUALIFY clause
- [ ] Teradata NORMALIZE / temporal logic
- [ ] Teradata CASESPECIFIC behavior
- [ ] Teradata FORMAT in CAST
- [ ] Informatica variable port order-dependency
- [ ] Informatica unconnected lookups
- [ ] Informatica dynamic/persistent cache
- [ ] SSIS Script Task with C#/VB.NET code
- [ ] SSIS ForEach Loop pattern
- [ ] Custom/third-party components

### Error Handling
- [Error detection mechanism]
- [Recovery/restart strategy]
- [Error thresholds]

### Complexity Rating: [Low/Medium/High]
- Justification: [Why this rating]
```

## Validation Query Templates

Standard validation queries to run after migration:

```sql
-- 1. Row Count Validation
SELECT 'source' AS system, COUNT(*) AS row_count FROM source_table
UNION ALL
SELECT 'target' AS system, COUNT(*) AS row_count FROM target_table;

-- 2. Column Checksum Validation (Snowflake)
SELECT SUM(HASH(col1, col2, col3, col4)) AS checksum FROM source_table;
SELECT SUM(HASH(col1, col2, col3, col4)) AS checksum FROM target_table;

-- 3. Aggregate Validation
SELECT
    COUNT(*) AS row_count,
    COUNT(DISTINCT business_key) AS unique_keys,
    SUM(amount) AS total_amount,
    MIN(effective_date) AS min_date,
    MAX(effective_date) AS max_date,
    SUM(CASE WHEN amount IS NULL THEN 1 ELSE 0 END) AS null_amount_count
FROM target_table;

-- 4. Sample Record Comparison (parameterized)
SELECT * FROM source_table WHERE business_key IN ('key1','key2','key3') ORDER BY business_key;
SELECT * FROM target_table WHERE business_key IN ('key1','key2','key3') ORDER BY business_key;

-- 5. Data Type Boundary Testing
SELECT
    MIN(numeric_col), MAX(numeric_col),                    -- Check for overflow
    MIN(LENGTH(string_col)), MAX(LENGTH(string_col)),      -- Check for truncation
    COUNT(CASE WHEN date_col < '1900-01-01' THEN 1 END),  -- Check for invalid dates
    COUNT(CASE WHEN date_col > '2099-12-31' THEN 1 END)   -- Check for far-future dates
FROM target_table;

-- 6. Duplicate Detection (critical for SET table migration)
SELECT business_key, COUNT(*) AS cnt
FROM target_table
GROUP BY business_key
HAVING COUNT(*) > 1;
```

## Metadata & Migration Registry

Maintain a migration tracking registry with these fields for each object:

```
| Source System | Source Object | Object Type | Complexity | Target Platform | Target Object | Status | Validation Status | Notes |
|---|---|---|---|---|---|---|---|---|
| Teradata | DW.sp_load_fact_sales | Stored Proc | High | Snowflake | ETL.sp_load_fact_sales | In Progress | Not Started | Contains dynamic SQL |
| Informatica | wf_daily_customer_load | Workflow | Medium | Databricks | job_daily_customer_load | Completed | Passed | 3 sessions, linear |
| SSIS | pkg_load_dim_product.dtsx | Package | Low | Snowflake | task_load_dim_product | Completed | Passed | Simple truncate+load |
```

## Complexity Scoring Matrix

Score each object for migration prioritization:

| Factor | Low (1) | Medium (2) | High (3) |
|---|---|---|---|
| **Lines of code** | <100 | 100-500 | >500 |
| **Source tables** | 1-2 | 3-5 | >5 |
| **Transformations** | Simple filters/lookups | Aggregations, SCD, window functions | Temporal, dynamic SQL, recursive |
| **Platform-specific constructs** | None | 1-2 (e.g., QUALIFY, FORMAT) | 3+ (e.g., temporal, SET tables, BTEQ control flow) |
| **Script code (C#/Java)** | None | Simple string/date manipulation | Complex API calls, file operations |
| **Dependencies** | Standalone | 2-3 upstream/downstream | Complex web of dependencies |
| **Error handling** | Simple pass/fail | Conditional retry | Complex branching with recovery |
| **Data volume** | <1M rows | 1M-100M rows | >100M rows |

**Total score interpretation:**
- 8-12: Simple migration (batch convert with high confidence)
- 13-18: Medium complexity (convert with careful review)
- 19-24: High complexity (requires dedicated analysis and custom approach)

## Migration Strategy Patterns

**Phased migration** (recommended for large estates):
1. Phase 1: Replicate source data to target platform (raw/bronze layer)
2. Phase 2: Build and validate target transformations against raw data
3. Phase 3: Parallel run - execute both source and target, compare outputs
4. Phase 4: Cutover - switch downstream consumers to target
5. Phase 5: Decommission source

**Coexistence patterns during migration**:
- Dual-write: Both systems updated (complex, use sparingly)
- CDC replication: Source -> target via change data capture (Debezium, Fivetran, etc.)
- View abstraction: Create views that point to whichever system is current

## Hybrid Conversion Strategy

Not all objects should be converted the same way. Use a tiered approach based on complexity:

### Tier 1: Automated Conversion (target: 70-80% of objects by count)

**Candidates**: Simple SELECT-INSERT, 1:1 table mappings, straightforward lookups, basic filters, standard data type conversions.

**Approach**:
- Use rule-based scripts or transpilers (e.g., SQLGlot for SQL dialect conversion) to batch-convert
- Apply standard function mappings automatically
- Auto-generate validation queries from templates
- Human review is still required but should be a quick spot-check

**Quality gate**: Must pass Level 1 + Level 2 validation automatically before proceeding.

### Tier 2: AI-Assisted Conversion (target: 15-25% of objects)

**Candidates**: Medium-complexity stored procedures, Informatica mappings with 3-8 transformations, SSIS packages with conditional logic, objects scoring 13-18 on the complexity matrix.

**Approach**:
- Use Claude (with these rules loaded) to reverse engineer the source and generate target code
- Claude produces the converted code + validation queries + documentation
- Developer reviews the generated code with attention to: edge cases, business rule preservation, behavioral differences flagged by Claude
- Developer runs validation queries and confirms Level 1-3 pass

**Quality gate**: Must pass Level 1 + Level 2 + Level 3 validation. Developer sign-off required.

### Tier 3: Manual Conversion (target: 5-10% of objects)

**Candidates**: Objects scoring 19-24 on the complexity matrix, including: dynamic SQL generation, recursive/temporal logic, complex BTEQ control flow, SSIS Script Tasks with external API calls, Informatica mappings with 10+ transformations or custom Java code, objects with undocumented business rules.

**Approach**:
- Senior developer manually reverse engineers with Claude assisting on analysis/documentation
- Architecture review before writing target code (may require redesign, not just translation)
- Target code written manually, potentially using different patterns than source
- Full 4-level validation including Level 4 (functional validation with stakeholder sign-off)
- Peer code review required

**Quality gate**: Must pass all 4 validation levels. Stakeholder sign-off on business logic preservation.

### Conversion Tier Assignment Workflow

```
For each source object:
  1. Score complexity using the complexity scoring matrix
  2. Assign tier:
     - Score 8-12  -> Tier 1 (Automated)
     - Score 13-18 -> Tier 2 (AI-Assisted)
     - Score 19-24 -> Tier 3 (Manual)
  3. Override to higher tier if:
     - Object has known undocumented business rules
     - Object is in critical path (revenue-affecting, regulatory)
     - Object has no test cases or validation baseline
  4. Track tier assignment in migration registry
```
