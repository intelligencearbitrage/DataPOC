---
paths:
  - "src/converted/databricks/**/*.sql"
  - "src/converted/databricks/**/*.py"
  - "src/databricks/**/*"
  - "target/databricks/**/*"
  - "databricks/**/*"
---

# Forward Engineering to Databricks

You are writing or reviewing **target Databricks code**. This is migration output code. Use lakehouse-native patterns, not lift-and-shift.

## Code Standards (Mandatory)

- All identifiers in lowercase_snake_case
- Medallion architecture: bronze (raw), silver (cleansed), gold (business)
- Every table must have audit columns: load_timestamp, source_system, batch_id
- All code must be idempotent (safe to re-run)
- Use MERGE INTO for upsert patterns
- Use explicit data types in CAST
- Use Delta Lake format for all tables
- Reference source system object in comments for traceability
- Use SELECT with explicit column lists (no SELECT * in production code)

## Databricks Architecture Principles

- **Lakehouse / Medallion Architecture**: Bronze (raw) -> Silver (cleansed/conformed) -> Gold (business-level aggregates)
- **Delta Lake by default**: All tables should be Delta format for ACID, time travel, schema enforcement
- **Unity Catalog**: Use for centralized governance, lineage, access control
- **Photon**: Enable for performance-critical SQL workloads
- **Serverless compute**: Prefer serverless SQL warehouses and serverless jobs where available

## Databricks Migration Patterns

### Medallion Architecture for ETL
```
Legacy ETL Pipeline:
  Source -> Informatica/SSIS Transform -> Target DW

Databricks Equivalent:
  Bronze (raw ingestion) -> Silver (cleansed, conformed) -> Gold (business aggregates)
```

### File Ingestion with Auto Loader
```python
# Replace SSIS File Source / Informatica File Reader
# Auto Loader handles schema evolution and exactly-once processing
df = (spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "csv")
    .option("cloudFiles.schemaLocation", "/mnt/schema/")
    .option("cloudFiles.inferColumnTypes", "true")
    .load("/mnt/landing/"))

(df.writeStream
    .format("delta")
    .option("checkpointLocation", "/mnt/checkpoints/raw_table")
    .option("mergeSchema", "true")
    .trigger(availableNow=True)
    .toTable("bronze.raw_table"))
```

### Delta Live Tables (DLT) for Pipeline Definition
```python
# Replace complex Informatica mappings with declarative DLT
import dlt
from pyspark.sql.functions import *

@dlt.table(comment="Raw customer data from source system")
def bronze_customers():
    return spark.readStream.format("cloudFiles") \
        .option("cloudFiles.format", "csv") \
        .load("/mnt/landing/customers/")

@dlt.table(comment="Cleansed customer data")
@dlt.expect_or_drop("valid_email", "email IS NOT NULL AND email LIKE '%@%'")
def silver_customers():
    return dlt.read_stream("bronze_customers").select(
        col("customer_id").cast("int"),
        trim(col("name")).alias("name"),
        lower(trim(col("email"))).alias("email"),
        to_date(col("birth_date"), "yyyy-MM-dd").alias("birth_date")
    )

@dlt.table(comment="Customer summary for analytics")
def gold_customer_summary():
    return dlt.read("silver_customers").groupBy("region").agg(
        count("*").alias("customer_count"),
        avg("lifetime_value").alias("avg_ltv")
    )
```

### SCD Type 2 with Delta Lake (Python)
```python
from delta.tables import DeltaTable

target = DeltaTable.forName(spark, "silver.dim_customer")
source = spark.table("bronze.stg_customer")

target.alias("tgt").merge(
    source.alias("src"),
    "tgt.business_key = src.business_key AND tgt.is_current = true"
).whenMatchedUpdate(
    condition="tgt.hash_diff <> src.hash_diff",
    set={"is_current": "false", "end_date": "current_timestamp()"}
).whenNotMatchedInsert(
    values={
        "business_key": "src.business_key",
        "name": "src.name",
        "start_date": "current_timestamp()",
        "end_date": "cast('9999-12-31' as timestamp)",
        "is_current": "true",
        "hash_diff": "src.hash_diff"
    }
).execute()
```

### SCD Type 2 with SQL-based MERGE
```sql
MERGE INTO silver.dim_customer AS tgt
USING bronze.stg_customer AS src
ON tgt.business_key = src.business_key AND tgt.is_current = TRUE
WHEN MATCHED AND tgt.hash_diff <> src.hash_diff THEN
  UPDATE SET is_current = FALSE, end_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
  INSERT (business_key, name, start_date, end_date, is_current, hash_diff)
  VALUES (src.business_key, src.name, CURRENT_TIMESTAMP(), TIMESTAMP'9999-12-31', TRUE, src.hash_diff);
```

### SCD Type 2 with Delta Live Tables AUTO CDC (Preferred)
```sql
-- Declarative SCD Type 2 - handles out-of-order records automatically
CREATE OR REFRESH STREAMING TABLE dim_customer;

APPLY CHANGES INTO LIVE.dim_customer
FROM STREAM(LIVE.staging_customer)
KEYS (customer_key)
SEQUENCE BY updated_at
STORED AS SCD TYPE 2;
```

### Full Sync MERGE with Delete Propagation
```sql
-- Sync target with source, propagating inserts, updates, AND deletes
MERGE INTO silver.customers AS tgt
USING bronze.staged_customers AS src
ON tgt.customer_id = src.customer_id
WHEN MATCHED THEN UPDATE SET *
WHEN NOT MATCHED BY TARGET THEN INSERT *
WHEN NOT MATCHED BY SOURCE
  AND tgt.last_seen >= CURRENT_DATE() - INTERVAL 30 DAYS
  THEN UPDATE SET tgt.status = 'inactive';
```

### Change Data Feed (CDF) for Incremental Processing
```sql
-- Enable CDF on Delta tables (replaces Informatica incremental workflows)
ALTER TABLE silver.orders SET TBLPROPERTIES (delta.enableChangeDataFeed = true);

-- Read changes (batch) - returns _change_type, _commit_version, _commit_timestamp
SELECT * FROM table_changes('silver.orders', startVersion, endVersion);
```
```python
# Read changes (streaming)
changes_df = (spark.readStream
    .option("readChangeFeed", "true")
    .option("startingVersion", last_processed_version)
    .table("catalog.schema.source_table"))
```

### DLT with Data Quality Expectations
```sql
-- Replace legacy data quality frameworks with DLT Expectations
CREATE OR REFRESH STREAMING TABLE clean_orders (
  CONSTRAINT valid_order_id EXPECT (order_id IS NOT NULL) ON VIOLATION DROP ROW,
  CONSTRAINT valid_amount EXPECT (amount > 0) ON VIOLATION FAIL UPDATE,
  CONSTRAINT valid_date EXPECT (order_date >= '2000-01-01') ON VIOLATION DROP ROW
)
AS SELECT
  CAST(order_id AS BIGINT) AS order_id,
  TO_DATE(order_date, 'yyyy-MM-dd') AS order_date,
  CAST(amount AS DECIMAL(18,2)) AS amount
FROM STREAM(LIVE.raw_orders);
```

## Databricks SQL Conversion Rules

When converting SQL to Databricks/Spark SQL:
- `QUALIFY` is NOT supported in Spark SQL -> use subquery/CTE with window function + WHERE filter
- Use `MERGE INTO` for upserts (Delta Lake)
- `LATERAL VIEW EXPLODE()` for array unnesting (replaces Informatica Normalizer / Snowflake FLATTEN)
- `TRY_CAST` is available in Databricks SQL for safe conversions
- Use `IDENTITY` columns or `UUID()` for surrogate keys (replaces Informatica Sequence Generator)
- `DESCRIBE HISTORY table_name` for time travel / audit
- Databricks supports `CREATE OR REPLACE TABLE` with Delta Lake
- Use `OPTIMIZE table_name ZORDER BY (col)` for query performance (replaces index concepts)
- `VACUUM table_name RETAIN 168 HOURS` for storage cleanup

## Teradata SQL to Spark SQL Conversion Rules

| Teradata SQL | Databricks/Spark SQL Equivalent |
|---|---|
| `QUALIFY ROW_NUMBER() OVER (...) = 1` | `WITH cte AS (SELECT *, ROW_NUMBER() OVER (...) AS rn FROM t) SELECT * FROM cte WHERE rn = 1` |
| `SEL` | `SELECT` |
| `SAMPLE 100` | `TABLESAMPLE (100 ROWS)` or `.limit(100)` in PySpark |
| `LOCKING ROW FOR ACCESS` | Remove (not applicable) |
| `VOLATILE TABLE` | `CREATE OR REPLACE TEMP VIEW` or `createOrReplaceTempView()` |
| `COLLECT STATISTICS` | `ANALYZE TABLE t COMPUTE STATISTICS FOR ALL COLUMNS` |
| `CASESPECIFIC` / `NOT CASESPECIFIC` | Spark is case-insensitive for identifiers by default but case-sensitive for string comparisons; use `UPPER()`/`LOWER()` |
| `FORMAT 'YYYYMMDD'` | `DATE_FORMAT(col, 'yyyyMMdd')` |
| `TITLE 'Column Name'` | ``col AS `Column Name` `` |
| `NAMED alias` | `col AS alias` |
| `OREPLACE(s, f, r)` | `REPLACE(s, f, r)` |
| `OTRANSLATE(s, f, t)` | `TRANSLATE(s, f, t)` |
| `STRTOK(s, d, n)` | `SPLIT(s, d)[n-1]` (0-indexed in Spark) |
| `ZEROIFNULL(x)` | `COALESCE(x, 0)` |
| `NULLIFZERO(x)` | `NULLIF(x, 0)` |
| `INDEX(s, sub)` | `LOCATE(sub, s)` |
| `CHARACTERS(s)` | `LENGTH(s)` |
| `CAST(d AS FORMAT 'YYYYMMDD')` | `DATE_FORMAT(d, 'yyyyMMdd')` |
| `d1 - d2` (date difference -> integer) | `DATEDIFF(d1, d2)` |
| `NORMALIZE ON period_col` | Custom SQL with window functions to merge overlapping ranges |
| `PERIOD(DATE)` | Two columns: `start_date DATE, end_date DATE` |

## Databricks Workflow Orchestration Patterns

Replace Informatica Workflows / SSIS Master Packages with Databricks Workflows:

```json
{
  "name": "daily_etl_pipeline",
  "tasks": [
    {
      "task_key": "load_bronze",
      "notebook_task": {"notebook_path": "/ETL/bronze/load-raw-data"},
      "cluster_key": "etl_cluster"
    },
    {
      "task_key": "transform_silver",
      "depends_on": [{"task_key": "load_bronze"}],
      "notebook_task": {"notebook_path": "/ETL/silver/transform-customers"}
    },
    {
      "task_key": "aggregate_gold",
      "depends_on": [{"task_key": "transform_silver"}],
      "sql_task": {
        "query": {"query_id": "query_abc123"},
        "warehouse_id": "warehouse_xyz"
      }
    }
  ],
  "schedule": {"quartz_cron_expression": "0 0 6 * * ?", "timezone_id": "America/New_York"}
}
```

**Orchestration mapping from legacy tools:**

| Legacy Pattern | Databricks Equivalent |
|---|---|
| Informatica sequential sessions | Tasks with `depends_on` dependencies |
| Informatica parallel branches | Tasks with no dependency (run in parallel) |
| SSIS ForEach Loop (files) | Auto Loader (continuous) or `for file in dbutils.fs.ls()` pattern |
| SSIS Execute Package Task | Task referencing another notebook/job |
| Informatica Decision task | `dbutils.widgets.get()` + `if/else` in notebook |
| SSIS precedence constraint with expression | `depends_on` + `condition_task` (run_if) |
| Informatica Event Wait | Auto Loader (file arrival) or external trigger via REST API |
| SSIS error event handler | `on_failure` task specification in workflow |

## Databricks Unity Catalog Governance

| Legacy Concept | Unity Catalog Equivalent |
|---|---|
| Teradata database-level grants | Catalog/Schema-level GRANT statements |
| Teradata VIEW-based security | Row-level security with row filters, column masks |
| Informatica connection credentials | Unity Catalog external locations + storage credentials |
| SSIS connection manager secrets | Databricks secrets (backed by Azure Key Vault / AWS Secrets Manager) |
| Teradata roles (GRANT role TO user) | Unity Catalog groups + GRANT privileges |

```sql
-- Unity Catalog security setup
GRANT USAGE ON CATALOG analytics TO `data_team`;
GRANT USAGE ON SCHEMA analytics.gold TO `data_team`;
GRANT SELECT ON TABLE analytics.gold.fact_sales TO `data_team`;

-- Row-level security
ALTER TABLE analytics.gold.fact_sales SET ROW FILTER row_filter_fn ON (region);

-- Column masking
ALTER TABLE analytics.gold.dim_customer ALTER COLUMN ssn SET MASK mask_ssn_fn;
```

## SQL Server to Databricks Data Type Mapping

| SQL Server Type | Databricks Type | Notes |
|---|---|---|
| `BIT` | `BOOLEAN` | |
| `TINYINT` | `SMALLINT` | SQL Server TINYINT is unsigned (0-255); Spark TINYINT is signed (-128 to 127). Use SMALLINT to avoid overflow. |
| `SMALLINT` | `SMALLINT` | |
| `INT` | `INT` | |
| `BIGINT` | `BIGINT` | |
| `FLOAT` / `REAL` | `DOUBLE` / `FLOAT` | |
| `DECIMAL(p,s)` / `NUMERIC(p,s)` | `DECIMAL(p,s)` | Max precision 38 in both |
| `MONEY` / `SMALLMONEY` | `DECIMAL(19,4)` / `DECIMAL(10,4)` | |
| `CHAR(n)` / `NCHAR(n)` | `STRING` | Spark STRING has no length limit; add CHECK constraint if needed |
| `VARCHAR(n)` / `NVARCHAR(n)` | `STRING` | |
| `VARCHAR(MAX)` / `NVARCHAR(MAX)` | `STRING` | |
| `BINARY(n)` / `VARBINARY(n)` | `BINARY` | |
| `DATE` | `DATE` | |
| `TIME` | `STRING` | No native TIME type in Spark |
| `DATETIME` / `DATETIME2` | `TIMESTAMP` | Use `TIMESTAMP_NTZ` for timezone-unaware behavior |
| `DATETIMEOFFSET` | `TIMESTAMP` | Convert timezone info before loading |
| `UNIQUEIDENTIFIER` | `STRING` | Use `UUID()` to generate new values |
| `XML` | `STRING` | Parse with XPath functions |
| `GEOGRAPHY` / `GEOMETRY` | `GEOGRAPHY` / `GEOMETRY` | Native geospatial types in Databricks |
| `HIERARCHYID` | `STRING` | No native equivalent; store as string path |
| `SQL_VARIANT` | `VARIANT` | |

## Databricks Performance Best Practices

- **Liquid Clustering** (preferred over Z-ORDER for new tables): `ALTER TABLE t CLUSTER BY (col1, col2)`
  - **Automatic Liquid Clustering** (DBR 15.4+): `CLUSTER BY AUTO` lets Databricks choose keys based on query patterns
  - Clustering keys can be changed without rewriting: `ALTER TABLE t CLUSTER BY (new_col)`
- **Photon-enabled clusters** for SQL workloads (2-8x faster)
- **Adaptive Query Execution (AQE)**: Enabled by default; handles skew and partition coalescing
- **Delta caching**: Enable on compute for frequently accessed data
- **Broadcast joins**: For small dimension tables `/*+ BROADCAST(dim) */`; adjust threshold: `SET spark.sql.autoBroadcastJoinThreshold = 100m`
- **Partition columns**: Only for very large tables (>1TB) with clear partition key; each partition should have >1GB data
- **Low Shuffle Merge**: Reduces files rewritten during MERGE; enabled by default in DBR 10.4+
- **Dynamic File Pruning**: Automatically skips irrelevant files; works best with clustered tables
- **Predictive Optimization**: Automatically runs OPTIMIZE and VACUUM on Unity Catalog managed tables
- **Avoid small files**: Use `OPTIMIZE` to compact; target 256MB-1GB per file
- **Use serverless warehouses** for SQL analytics workloads
- **Databricks Asset Bundles (DABs)**: Define jobs/clusters/pipelines as YAML code for CI/CD deployment across environments

## Anti-Patterns to Avoid

- Pandas UDFs for simple transformations (use native Spark SQL)
- Collect() on large datasets
- Hard-coded paths (use Unity Catalog volumes or parameterize)
- Non-Delta formats in production tables
- Repartition without clear justification
- SELECT * in production code
