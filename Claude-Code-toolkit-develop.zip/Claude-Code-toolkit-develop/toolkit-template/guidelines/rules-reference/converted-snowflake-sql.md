---
paths:
  - "src/converted/snowflake/**/*.sql"
  - "src/snowflake/**/*.sql"
  - "target/snowflake/**/*.sql"
  - "snowflake/**/*.sql"
---

# Forward Engineering to Snowflake

You are writing or reviewing **target Snowflake SQL**. This is migration output code. Use cloud-native patterns, not lift-and-shift.

## Code Standards (Mandatory)

- All identifiers in UPPERCASE_SNAKE_CASE
- Prefixes: SP_ (procedures), VW_ (views), STG_ (stages), TSK_ (tasks), STM_ (streams)
- Every table must have audit columns: LOAD_TIMESTAMP, SOURCE_SYSTEM, BATCH_ID
- All code must be idempotent (safe to re-run)
- Use MERGE for upsert patterns (never DELETE+INSERT)
- Use explicit data types (never rely on implicit casting)
- Include TRY/CATCH error handling in stored procedures
- Use CURRENT_TIMESTAMP() (not SYSDATE or GETDATE)
- Reference source system object in comments for traceability
- Use SELECT with explicit column lists (no SELECT * in production code)

## Snowflake Architecture Principles

- **Separation of storage and compute**: Size warehouses for workload, not data volume
- **No indexes**: Snowflake uses micro-partitions and metadata pruning. Don't try to recreate index strategies.
- **Semi-structured data native**: Use VARIANT for JSON/XML/Parquet instead of shredding into relational columns
- **Zero-copy cloning**: Use for dev/test environments and safe migration testing
- **Time Travel**: Enable for recovery (1-90 days based on edition)
- **Dynamic Tables**: Declarative ELT - define target as query, Snowflake auto-maintains incrementally

**Warehouse-per-workload pattern:**
| Warehouse | Purpose | Recommended Size | Auto-Suspend |
|---|---|---|---|
| `WH_INGESTION` | ELT loading (COPY INTO, Snowpipe) | Small/Medium | 60s |
| `WH_TRANSFORM` | Stored procs, dbt, tasks | Medium/Large | 120s |
| `WH_ANALYTICS` | BI tools, ad-hoc queries | Small + multi-cluster auto-scale | 300s |
| `WH_DATA_SCIENCE` | Snowpark, ML workloads | Medium/Large (Snowpark-optimized) | 120s |

**Table type guidance:**
- `TRANSIENT` tables: Staging/intermediate (no Fail-safe, lower storage cost, 0-1 day Time Travel)
- `PERMANENT` tables: Gold/consumption layer (7-day Time Travel + 7-day Fail-safe on Enterprise+)
- `TEMPORARY` tables: Session-scoped intermediate results in stored procedures

## Snowflake Migration Patterns

### ETL to ELT Conversion
Legacy Informatica/SSIS pattern:
```
Source -> Extract -> Transform (in ETL tool) -> Load to target
```
Snowflake-native pattern:
```
Source -> Stage (raw/landing) -> COPY INTO raw table -> SQL transforms (stored procs/views) -> Target table
```

### File Ingestion
```sql
-- Replace SSIS Flat File Source / Informatica File Reader
CREATE OR REPLACE STAGE my_stage URL='s3://bucket/path/' CREDENTIALS=(...);
CREATE OR REPLACE FILE FORMAT my_csv TYPE='CSV' FIELD_DELIMITER=',' SKIP_HEADER=1;
COPY INTO raw_table FROM @my_stage FILE_FORMAT=my_csv;

-- For streaming/continuous ingestion (replaces event-driven SSIS/Informatica):
CREATE OR REPLACE PIPE my_pipe AUTO_INGEST=TRUE AS
  COPY INTO raw_table FROM @my_stage FILE_FORMAT=my_csv;
```

### Dynamic Tables (Declarative ELT)
```sql
-- Define the target as a query; Snowflake automatically maintains it incrementally
-- Replaces many stream + task + merge patterns
CREATE DYNAMIC TABLE transformed_orders
  TARGET_LAG = '10 minutes'
  WAREHOUSE = WH_TRANSFORM
AS
  SELECT order_id, customer_id, SUM(amount) AS total
  FROM raw_db.source.orders
  GROUP BY 1, 2;
```

### SCD Type 2 Pattern
```sql
-- Replace Informatica SCD Wizard / SSIS Slowly Changing Dimension
MERGE INTO dim_customer tgt
USING (
  SELECT * FROM stg_customer
  WHERE _load_timestamp > (SELECT MAX(_load_timestamp) FROM dim_customer)
) src
ON tgt.business_key = src.business_key AND tgt.is_current = TRUE
WHEN MATCHED AND (tgt.hash_diff <> src.hash_diff) THEN
  UPDATE SET is_current = FALSE, end_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
  INSERT (business_key, ..., start_date, end_date, is_current)
  VALUES (src.business_key, ..., CURRENT_TIMESTAMP(), '9999-12-31', TRUE);

-- Insert new current records for changed rows
INSERT INTO dim_customer (business_key, ..., start_date, end_date, is_current)
SELECT business_key, ..., CURRENT_TIMESTAMP(), '9999-12-31', TRUE
FROM stg_customer src
WHERE EXISTS (
  SELECT 1 FROM dim_customer tgt
  WHERE tgt.business_key = src.business_key
  AND tgt.is_current = FALSE
  AND tgt.end_date = CURRENT_TIMESTAMP()::DATE
);
```

### Orchestration with Tasks + Streams
```sql
-- Replace Informatica Workflow / SSIS Master Package
CREATE OR REPLACE STREAM stg_stream ON TABLE raw_landing;

CREATE OR REPLACE TASK load_dim_customer
  WAREHOUSE = etl_wh
  SCHEDULE = 'USING CRON 0 6 * * * America/New_York'
  WHEN SYSTEM$STREAM_HAS_DATA('stg_stream')
AS
  CALL sp_load_dim_customer();

-- Child tasks for dependencies
CREATE OR REPLACE TASK load_fact_orders
  WAREHOUSE = etl_wh
  AFTER load_dim_customer
AS
  CALL sp_load_fact_orders();
```

## Snowflake SQL Conversion Rules

When converting SQL to Snowflake:
- Snowflake supports `QUALIFY` (same as Teradata) - use it for window function filtering
- Use `FLATTEN` for array/JSON unpacking (replaces Informatica Normalizer)
- Use `TRY_CAST`, `TRY_TO_NUMBER`, `TRY_TO_DATE` for safe type conversions (replaces Informatica IS_NUMBER, IS_DATE)
- `CREATE TABLE ... CLONE source_table` for zero-copy table copies
- Use `IDENTIFIER()` function for dynamic SQL with object names
- `RESULT_SCAN(LAST_QUERY_ID())` to capture query results for metadata
- Snowflake JavaScript UDFs for complex procedural logic that doesn't fit SQL
- Snowflake Python UDFs/UDTFs via Snowpark for data science workloads
- Use `$1, $2` notation for staged file column references

## Snowflake Stored Procedure Pattern

```sql
CREATE OR REPLACE PROCEDURE SP_LOAD_DIM_CUSTOMER(P_BATCH_ID VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
AS
$$
DECLARE
    v_row_count INTEGER;
    v_error_msg VARCHAR;
BEGIN
    -- Log start
    INSERT INTO ETL.AUDIT_LOG (PROC_NAME, BATCH_ID, STATUS, START_TIME)
    VALUES ('SP_LOAD_DIM_CUSTOMER', :P_BATCH_ID, 'RUNNING', CURRENT_TIMESTAMP());

    BEGIN
        -- Main ETL logic (MERGE for SCD Type 1)
        MERGE INTO DIMENSIONS.DIM_CUSTOMER AS tgt
        USING STAGING.STG_CUSTOMER AS src
        ON tgt.CUSTOMER_BK = src.CUSTOMER_BK
        WHEN MATCHED AND src.HASH_DIFF <> tgt.HASH_DIFF THEN
            UPDATE SET tgt.CUSTOMER_NAME = src.CUSTOMER_NAME,
                       tgt.MODIFIED_DATE = CURRENT_TIMESTAMP(),
                       tgt.BATCH_ID = :P_BATCH_ID
        WHEN NOT MATCHED THEN
            INSERT (CUSTOMER_BK, CUSTOMER_NAME, CREATED_DATE, MODIFIED_DATE, BATCH_ID)
            VALUES (src.CUSTOMER_BK, src.CUSTOMER_NAME, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), :P_BATCH_ID);

        -- Capture row count
        v_row_count := SQLROWCOUNT;

        -- Log success
        UPDATE ETL.AUDIT_LOG SET STATUS = 'SUCCESS', END_TIME = CURRENT_TIMESTAMP(),
               ROWS_AFFECTED = :v_row_count
        WHERE PROC_NAME = 'SP_LOAD_DIM_CUSTOMER' AND BATCH_ID = :P_BATCH_ID;

        RETURN 'SUCCESS: ' || :v_row_count || ' rows processed';
    EXCEPTION
        WHEN OTHER THEN
            v_error_msg := SQLERRM;
            UPDATE ETL.AUDIT_LOG SET STATUS = 'FAILED', END_TIME = CURRENT_TIMESTAMP(),
                   ERROR_MESSAGE = :v_error_msg
            WHERE PROC_NAME = 'SP_LOAD_DIM_CUSTOMER' AND BATCH_ID = :P_BATCH_ID;
            RAISE;
    END;
END;
$$;
```

## Dynamic SQL for Metadata-Driven Loads

```sql
CREATE OR REPLACE PROCEDURE SP_GENERIC_FILE_LOAD(
    P_TABLE_NAME VARCHAR, P_STAGE_NAME VARCHAR, P_FILE_FORMAT VARCHAR
)
RETURNS VARCHAR
LANGUAGE SQL
AS
$$
BEGIN
    EXECUTE IMMEDIATE 'COPY INTO ' || P_TABLE_NAME ||
        ' FROM @' || P_STAGE_NAME ||
        ' FILE_FORMAT = (FORMAT_NAME = ' || P_FILE_FORMAT || ')' ||
        ' ON_ERROR = CONTINUE';
    RETURN 'Loaded ' || SQLROWCOUNT || ' rows into ' || P_TABLE_NAME;
END;
$$;
```

## T-SQL to Snowflake Conversion Rules

| T-SQL (SQL Server / SSIS) | Snowflake Equivalent |
|---|---|
| `ISNULL(a, b)` | `COALESCE(a, b)` or `NVL(a, b)` |
| `GETDATE()` | `CURRENT_TIMESTAMP()` |
| `CONVERT(type, val, style)` | `TO_CHAR(val, format)` or `TRY_TO_DATE(val, format)` |
| `CHARINDEX(sub, str)` | `POSITION(sub IN str)` |
| `STUFF(str, start, len, replace)` | `INSERT(str, start, len, replace)` |
| `LEN(str)` (excludes trailing spaces) | `LENGTH(RTRIM(str))` |
| `DATALENGTH(str)` | `LENGTH(str)` (in bytes: `OCTET_LENGTH(str)`) |
| `@@ROWCOUNT` | `SQLROWCOUNT` (in procedures) |
| `@@IDENTITY` / `SCOPE_IDENTITY()` | `SELECT column_name FROM TABLE(RESULT_SCAN(LAST_QUERY_ID()))` |
| `TOP N` | `LIMIT N` |
| `WITH (NOLOCK)` | Not needed (Snowflake uses MVCC) |
| `CROSS APPLY` / `OUTER APPLY` | `LATERAL FLATTEN` or `LATERAL` subquery |
| `PIVOT` / `UNPIVOT` | `PIVOT` / `UNPIVOT` (native support) |
| `TRY_CONVERT(type, val)` | `TRY_CAST(val AS type)` |
| `STRING_AGG(col, ',')` | `LISTAGG(col, ',')` |
| `NEWID()` | `UUID_STRING()` |
| `HASHBYTES('SHA2_256', val)` | `SHA2(val, 256)` |
| `BEGIN TRY...END TRY BEGIN CATCH...END CATCH` | `BEGIN...EXCEPTION WHEN OTHER THEN...END` |
| `EXEC sp_executesql @sql` | `EXECUTE IMMEDIATE sql_string` |
| `CURSOR + FETCH` | `RESULTSET` + `CURSOR` (Snowflake Scripting) |
| `WHILE @@FETCH_STATUS = 0` | `FOR record IN cursor DO ... END FOR` |

## SQL Server to Snowflake Data Type Mapping

| SQL Server Type | Snowflake Type | Notes |
|---|---|---|
| `BIT` | `BOOLEAN` | |
| `TINYINT` / `SMALLINT` / `INT` / `BIGINT` | `NUMBER(38,0)` | All integer aliases map to same internal type |
| `DECIMAL(p,s)` / `NUMERIC(p,s)` | `NUMBER(p,s)` | Direct mapping |
| `FLOAT` / `REAL` | `FLOAT` | IEEE 754 double (64-bit) |
| `MONEY` / `SMALLMONEY` | `NUMBER(19,4)` / `NUMBER(10,4)` | |
| `CHAR(n)` / `NCHAR(n)` | `VARCHAR(n)` | Snowflake VARCHAR is always UTF-8; N-prefix unnecessary |
| `VARCHAR(n)` / `NVARCHAR(n)` | `VARCHAR(n)` | Max 16,777,216 bytes |
| `VARCHAR(MAX)` / `NVARCHAR(MAX)` | `VARCHAR(16777216)` | |
| `BINARY(n)` / `VARBINARY(n)` | `BINARY(n)` / `VARBINARY(n)` | |
| `DATE` | `DATE` | |
| `TIME` | `TIME` | |
| `DATETIME` / `DATETIME2` | `TIMESTAMP_NTZ` | Use NTZ to avoid timezone surprises |
| `DATETIMEOFFSET` | `TIMESTAMP_TZ` | |
| `UNIQUEIDENTIFIER` | `VARCHAR(36)` | Use `UUID_STRING()` to generate |
| `XML` | `VARIANT` | Parse with `XMLGET`, `FLATTEN` |
| `GEOGRAPHY` / `GEOMETRY` | `GEOGRAPHY` / `GEOMETRY` | Native geospatial support |
| `HIERARCHYID` | `VARCHAR` | Store as path string |
| `SQL_VARIANT` | `VARIANT` | |
| `ROWVERSION` | `NUMBER` or Stream metadata | Use Streams for change tracking |

**Critical guidance**: Set `TIMESTAMP_TYPE_MAPPING = 'TIMESTAMP_NTZ'` at account level so bare `TIMESTAMP` defaults to NTZ.

## Snowflake Security Patterns

**RBAC Role Hierarchy:**
```
ACCOUNTADMIN (restricted to 1-2 users)
  +-- SYSADMIN (creates databases, warehouses)
  |     +-- DB_RAW_ADMIN, DB_TRANSFORM_ADMIN, DB_ANALYTICS_ADMIN
  |     +-- DATA_ENGINEER (R/W on RAW + TRANSFORM, R on ANALYTICS)
  |     +-- DATA_ANALYST (R on ANALYTICS, usage on analytics warehouse)
  |     +-- SERVICE_ACCOUNT_ETL (R/W where needed, used by pipelines)
  +-- SECURITYADMIN (manages roles, grants)
  +-- USERADMIN (creates users)
```

**FUTURE GRANTS** (auto-inherit permissions for new objects):
```sql
GRANT SELECT ON FUTURE TABLES IN SCHEMA analytics_db.finance TO ROLE DATA_ANALYST;
```

**Dynamic Data Masking:**
```sql
CREATE MASKING POLICY pii_mask AS (val STRING) RETURNS STRING ->
  CASE WHEN CURRENT_ROLE() IN ('DATA_ENGINEER', 'DATA_ADMIN') THEN val
       ELSE '***MASKED***' END;
ALTER TABLE dim_customer MODIFY COLUMN email SET MASKING POLICY pii_mask;
```

**Row Access Policies:**
```sql
CREATE ROW ACCESS POLICY region_policy AS (region_col VARCHAR) RETURNS BOOLEAN ->
  CURRENT_ROLE() = 'DATA_ADMIN'
  OR region_col IN (SELECT region FROM user_region_mapping WHERE user_name = CURRENT_USER());
ALTER TABLE fact_sales ADD ROW ACCESS POLICY region_policy ON (region);
```

## Snowflake Performance Best Practices

- **Do NOT over-cluster**: Only add clustering keys to tables >1TB with known filter patterns
- **Right-size warehouses**: Start with MEDIUM, scale up for complex queries, scale down for simple ones
- **Use transient tables** for staging/temp data (no Time Travel storage cost)
- **Materialized views** for frequently computed aggregations (but they have maintenance cost)
- **Search Optimization Service** for point lookup queries on large tables (replaces secondary indexes)
- **Query acceleration service** for queries with large scans that filter to small results

## Anti-Patterns to Avoid

- Row-by-row cursor loops (use set-based SQL)
- Overuse of JavaScript stored procedures (prefer Snowflake Scripting / SQL)
- Multi-statement transactions where single MERGE suffices
- Hard-coded warehouse names (use parameterization)
- SELECT * in production code
