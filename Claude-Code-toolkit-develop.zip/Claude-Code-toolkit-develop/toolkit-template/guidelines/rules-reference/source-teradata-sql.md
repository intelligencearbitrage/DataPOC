---
paths:
  - "src/source_sql/**/*.sql"
  - "src/source_sql/**/*.bteq"
  - "legacy/**/*.sql"
  - "legacy/**/*.bteq"
  - "source/**/*.sql"
  - "teradata/**/*.sql"
---

# Teradata SQL Reverse Engineering

You are analyzing **read-only source Teradata SQL**. Do NOT modify these files. Your goal is to understand business intent, flag migration-critical constructs, and produce structured documentation.

## Key Teradata Constructs to Recognize

| Teradata Construct | What It Does | Migration Impact |
|---|---|---|
| `SET` vs `MULTISET` tables | SET tables silently deduplicate rows on insert | Must add explicit DISTINCT or dedup logic on target |
| `PRIMARY INDEX (PI)` | Hash-distributes data across AMPs | No direct equivalent in Snowflake (micro-partitions); maps to partition/cluster key in Databricks |
| `PARTITION BY` (PPI) | Partitioned Primary Index for partition elimination | Maps to Snowflake clustering keys or Databricks partition columns |
| `QUALIFY` | Filters window function results | Snowflake supports QUALIFY natively; Databricks requires subquery/CTE wrapper |
| `SAMPLE` | Statistical sampling | Use `TABLESAMPLE` or `SAMPLE` on target |
| `NORMALIZE` / `PERIOD` | Temporal data operations | Requires custom logic on target platforms |
| `CASESPECIFIC` / `NOT CASESPECIFIC` | Column-level case sensitivity control | Default behavior differs: handle explicitly in WHERE/JOIN conditions |
| `FORMAT` / `TITLE` | Display formatting in DDL | Strip during migration; handle in presentation layer |
| `HASHROW` / `HASHBUCKET` | Hash distribution introspection | No equivalent needed; remove |
| `LOCKING ROW FOR ACCESS` | Dirty read hint | Not needed in Snowflake (MVCC); remove |
| `COLLECT STATISTICS` | Optimizer stats | Snowflake auto-manages; Databricks uses ANALYZE TABLE |
| `JOIN INDEX` | Materialized join result | Map to Snowflake materialized views or Databricks Delta tables |
| `VOLATILE` / `GLOBAL TEMPORARY` tables | Session-scoped temp tables | Map to Snowflake temporary/transient tables or Databricks temp views |
| `MERGE INTO` | Upsert pattern | Direct equivalent exists in both Snowflake and Databricks |
| `NAMED` | Named result in expressions | Rewrite as CTE or subquery alias |
| `SEL` (abbreviation) | Short for SELECT | Expand to full SELECT |
| `CHARACTERS` / `CHARACTER_LENGTH` | String length functions | Map to LENGTH/LEN on target |
| `.date` (INTEGER date) | Teradata integer date format (YYMMDD or similar) | Convert to proper DATE type; watch for date arithmetic patterns |
| `ZEROIFNULL` / `NULLIFZERO` | NULL/zero coalescing | Rewrite with COALESCE/NULLIF/CASE |

## Teradata SQL Analysis Checklist

When reverse engineering Teradata SQL:

1. **Identify the PI/PPI strategy** - understand data distribution intent for performance-sensitive queries
2. **Check for SET table semantics** - look for implicit dedup behavior that callers may depend on
3. **Catalog all BTEQ control statements** - `.IF ERRORCODE`, `.QUIT`, `.LOGON`, `.EXPORT` are orchestration, not SQL
4. **Map all Teradata-specific functions** to target equivalents:
   - `ZEROIFNULL(x)` -> `COALESCE(x, 0)`
   - `NULLIFZERO(x)` -> `NULLIF(x, 0)`
   - `OREPLACE(s, from, to)` -> `REPLACE(s, from, to)`
   - `OTRANSLATE(s, from, to)` -> `TRANSLATE(s, from, to)`
   - `STRTOK(s, delim, n)` -> `SPLIT_PART(s, delim, n)`
   - `ADD_MONTHS(date, n)` -> `DATEADD(MONTH, n, date)` (Snowflake) / `ADD_MONTHS(date, n)` (Databricks)
   - `EXTRACT(YEAR FROM date)` -> `YEAR(date)` or `EXTRACT(YEAR FROM date)`
   - `TRIM(BOTH FROM x)` -> `TRIM(x)`
   - `INDEX(string, substring)` -> `POSITION(substring IN string)` or `CHARINDEX`
   - `SUBSTR` -> `SUBSTRING`
   - `CHARACTERS(x)` -> `LENGTH(x)`
5. **Watch for date arithmetic**: Teradata allows `date_col - date_col` yielding integer intervals (YYMMDDD format); rewrite with DATEDIFF
6. **Check for implicit type casting**: Teradata is more lenient with implicit casts between strings and numbers
7. **Document COLLECT STATISTICS columns** to inform clustering/partition strategy on target
8. **Identify cross-database references** (e.g., `database.table`) and map to target schema strategy

## Teradata Data Type Mapping

| Teradata Type | Snowflake Type | Databricks Type |
|---|---|---|
| `BYTEINT` | `TINYINT` or `SMALLINT` | `TINYINT` |
| `SMALLINT` | `SMALLINT` | `SMALLINT` |
| `INTEGER` | `INTEGER` | `INT` |
| `BIGINT` | `BIGINT` | `BIGINT` |
| `DECIMAL(p,s)` / `NUMERIC(p,s)` | `NUMBER(p,s)` | `DECIMAL(p,s)` |
| `FLOAT` / `DOUBLE PRECISION` | `FLOAT` / `DOUBLE` | `DOUBLE` |
| `CHAR(n)` | `CHAR(n)` (max 16MB) | `CHAR(n)` (max 255) or `STRING` |
| `VARCHAR(n)` | `VARCHAR(n)` (max 16MB) | `STRING` |
| `CLOB` | `VARCHAR(16777216)` | `STRING` |
| `BYTE(n)` / `VARBYTE(n)` | `BINARY(n)` / `VARBINARY(n)` | `BINARY` |
| `BLOB` | `BINARY` | `BINARY` |
| `DATE` | `DATE` | `DATE` |
| `TIME` | `TIME` | `STRING` (no native TIME) or `TIMESTAMP` |
| `TIMESTAMP` | `TIMESTAMP_NTZ` | `TIMESTAMP` |
| `TIMESTAMP WITH TIME ZONE` | `TIMESTAMP_TZ` | `TIMESTAMP` (UTC normalized) |
| `INTERVAL` | No direct equivalent; use DATEDIFF | No direct equivalent; use arithmetic |
| `PERIOD(DATE)` / `PERIOD(TIMESTAMP)` | Decompose to start/end columns | Decompose to start/end columns |
| `NUMBER` (no precision) | `NUMBER(38,0)` | `DECIMAL(38,0)` |
| `JSON` / `XML` | `VARIANT` / `VARCHAR` | `STRING` |

## BTEQ Script Analysis

BTEQ (Basic Teradata Query) is Teradata's command-line scripting tool. When reverse engineering BTEQ scripts:

**Key Directives to Recognize:**
- `.LOGON`, `.LOGOFF`, `.QUIT`, `.EXIT` - session lifecycle control
- `.SET WIDTH`, `.SET FORMAT`, `.SET ERROROUT` - output formatting and error routing
- `.EXPORT FILE=` and `.IMPORT` - data movement to/from flat files
- `.IF ERRORCODE <> 0 THEN .GOTO LABEL` - conditional error-handling branches
- `.RUN FILE=` - inclusion of external script files (chase these references for dependency graph)
- `.ACTIVITYCOUNT` - row count after each SQL statement; ETL logic frequently branches on this

**BTEQ Transaction Semantics:**
- Each SQL statement is submitted independently (NOT as a transaction) unless explicitly wrapped in `BT` (Begin Transaction) / `ET` (End Transaction)
- A single BTEQ file often contains dozens of SQL statements separated by semicolons
- Error handling is procedural via `.IF ERRORCODE` / `.GOTO` constructs

**Documentation approach**: For each BTEQ script, document (a) session parameters, (b) sequence of SQL operations, (c) error-handling branches and recovery logic, (d) external file dependencies via `.RUN FILE`, and (e) effective transaction boundaries (BT/ET blocks).

## FastLoad, MultiLoad, and TPump Utilities

| Utility | Purpose | Key Characteristics | Migration Impact |
|---|---|---|---|
| **FastLoad** | Bulk load into empty tables | Two phases (acquisition + application), bypasses transient journal, uses error tables (ET/UV) | Replace with COPY INTO (Snowflake) or Auto Loader (Databricks) |
| **MultiLoad** | INSERT/UPDATE/DELETE/UPSERT on populated tables | Uses work tables + error tables, `.DML LABEL` for operation routing | Replace with MERGE or staged loads |
| **TPump** | Real-time continuous loading | Row-level transactional, `RATE` and `SERIALIZE` parameters | Replace with Snowpipe (Snowflake) or Structured Streaming (Databricks) |

**Key directives to look for:**
- FastLoad: `.BEGIN LOADING`, `.END LOADING`, `DEFINE` block (column mapping), error table references
- MultiLoad: `.BEGIN MLOAD`, `.LAYOUT`, `.DML LABEL`, `.IMPORT`, `.APPLY` directives
- TPump: `.BEGIN LOAD` with `RATE`, `SERIALIZE`, `PACK` parameters

**Error table naming conventions**: ET_tablename and UV_tablename (FastLoad); WT_tablename, ET_tablename, UV_tablename (MultiLoad). These hold rejected rows and must be accounted for in migration.

## Temporal Tables and PERIOD Data Types

Teradata supports ANSI temporal tables with two dimensions:
- **Valid-time (application-time)**: When data is effective in the real world
- **Transaction-time (system-versioned)**: When data was stored in the database
- **Bitemporal**: Both dimensions simultaneously

**Constructs to recognize:**
```sql
-- PERIOD columns
validity_period PERIOD(DATE)
system_period PERIOD(TIMESTAMP)

-- Temporal qualifiers in DML
CURRENT VALIDTIME SELECT * FROM temporal_table;
SEQUENCED VALIDTIME SELECT * FROM temporal_table WHERE validity_period OVERLAPS PERIOD(DATE '2024-01-01', DATE '2024-12-31');
NONSEQUENCED VALIDTIME SELECT * FROM temporal_table;

-- NORMALIZE: merges overlapping periods
SELECT NORMALIZE customer_id, validity_period FROM temporal_table;
```

**Migration impact**: Temporal tables are among the hardest Teradata features to migrate. No direct equivalent exists on Snowflake or Databricks. Decompose PERIOD columns into `start_date`/`end_date` pairs and rewrite temporal queries as explicit range joins and date comparisons.

## Teradata Stored Procedures (SPL)

Teradata uses SPL (Stored Procedure Language), distinct from PL/SQL or T-SQL:

```sql
CREATE PROCEDURE schema.proc_name (IN p_date DATE, OUT p_count INTEGER)
BEGIN
    DECLARE v_local INTEGER;
    DECLARE v_cursor CURSOR FOR SELECT col FROM table WHERE dt = p_date;
    DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET v_local = -1;

    OPEN v_cursor;
    FETCH v_cursor INTO v_local;
    CLOSE v_cursor;

    SET p_count = ACTIVITY_COUNT;  -- Row count from last statement
END;
```

**SPL features to document for each procedure:**
- Parameter modes: `IN`, `OUT`, `INOUT`
- `DECLARE CURSOR` / `OPEN` / `FETCH` / `CLOSE` for cursor operations
- `DECLARE HANDLER FOR SQLSTATE` / `DECLARE HANDLER FOR SQLEXCEPTION` for error handling
- `EXECUTE IMMEDIATE` for dynamic SQL
- `ACTIVITY_COUNT` (equivalent to SQL Server's `@@ROWCOUNT`)
- Control flow: `IF/ELSEIF/ELSE`, `WHILE`, `LOOP`, `REPEAT`, `FOR`, `LEAVE`, `ITERATE`
- `CALL` for nested procedure invocation

## Teradata Macros

Macros are lightweight parameterized multi-statement scripts:
```sql
CREATE MACRO schema.macro_name (p_date DATE, p_threshold INTEGER DEFAULT 100) AS (
    DELETE FROM staging WHERE load_date < :p_date;
    INSERT INTO staging SELECT * FROM source WHERE amount > :p_threshold;
    SELECT COUNT(*) FROM staging;
);
```

**Key characteristics:**
- Parameters referenced with colon prefix (`:p_date`)
- All statements execute as a **single implicit transaction** (all-or-nothing)
- No control-flow logic (no IF, WHILE, etc.)
- Last SELECT returns a result set to the caller

## Metadata Extraction from DBC Dictionary

Key Teradata dictionary views for inventory extraction:
```sql
-- Table/view definitions
SELECT * FROM DBC.TablesV WHERE DatabaseName = 'your_db';
-- Column definitions (types, nullability, defaults, FORMAT, TITLE)
SELECT * FROM DBC.ColumnsV WHERE DatabaseName = 'your_db';
-- Index definitions (PI, SI, JI, PPI)
SELECT * FROM DBC.IndicesV WHERE DatabaseName = 'your_db';
-- View/procedure/macro source SQL
SELECT RequestText FROM DBC.TablesV WHERE TableKind IN ('V','P','M') AND DatabaseName = 'your_db';
-- Statistics
SELECT * FROM DBC.StatsV WHERE DatabaseName = 'your_db';
-- Referential integrity constraints
SELECT * FROM DBC.All_RI_ParentsV WHERE ChildDB = 'your_db';
-- Space usage
SELECT * FROM DBC.TableSizeV WHERE DatabaseName = 'your_db';
-- Query logs (actual access patterns)
SELECT * FROM DBC.QryLogV;  -- Historical SQL for lineage analysis
```

Use `SHOW TABLE/VIEW/PROCEDURE/MACRO schema.object_name` for complete DDL extraction.

## Common Teradata Anti-Patterns

1. **Cross-join accidents**: Missing join conditions in old-style comma-FROM syntax
2. **Volatile table chains**: Chains of `CREATE VOLATILE TABLE ... WITH DATA` where CTEs suffice
3. **Poor PI choices**: PI on low-cardinality columns causing AMP skew
4. **Unnecessary DISTINCT on SET tables**: Redundant dedup on tables that already discard duplicates
5. **Missing/stale statistics**: No `COLLECT STATISTICS` causing poor optimizer plans
6. **Hardcoded dates/magic numbers**: Literal date ranges instead of parameterized logic
7. **Nested views >4 levels deep**: Optimizer cannot flatten effectively
8. **Inconsistent CASESPECIFIC usage**: Mixing case sensitivity within related queries
9. **Excessive LOCKING hints**: `LOCKING TABLE FOR EXCLUSIVE` when `ACCESS` or `READ` suffices
10. **Integer date arithmetic**: Using `date_col / 10000 + 1900` pattern from Teradata's internal `(year-1900)*10000 + month*100 + day` storage

## Teradata Performance Construct Translation

- **Primary Index distribution** -> In Snowflake, data is auto-distributed via micro-partitions; no action needed. In Databricks, consider `ZORDER BY` or liquid clustering on the equivalent columns.
- **Secondary Indexes (USI/NUSI)** -> Snowflake: use search optimization service for point lookups. Databricks: use Z-ORDER or bloom filters.
- **Join Indexes** -> Snowflake: materialized views. Databricks: pre-computed Delta tables or materialized views (if using Unity Catalog).
- **Sparse Indexes** -> No equivalent; rely on query optimizer.
- **Statistics (COLLECT STATS)** -> Snowflake: fully automatic. Databricks: `ANALYZE TABLE ... COMPUTE STATISTICS`.

## Output Format

For each Teradata SQL file analyzed, produce:
1. **Plain-English summary** of business purpose
2. **All source tables** consumed and **all target tables** produced
3. **Transformation logic** step by step
4. **Flagged constructs** with migration notes
5. **Complexity rating** (Low/Medium/High) with justification
