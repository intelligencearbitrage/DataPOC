---
paths:
  - "src/informatica/**/*.xml"
  - "src/informatica/**/*.XML"
  - "legacy/infa/**/*"
  - "informatica/**/*"
---

# Informatica Reverse Engineering

You are analyzing **read-only Informatica PowerCenter XML exports**. Do NOT modify these files. Your goal is to trace data flows, document transformations, and produce column-level lineage.

## Repository Structure Understanding

Informatica PowerCenter organizes ETL as:
```
Repository
  +-- Folder(s)
       +-- Workflow(s)
            +-- Session(s)
                 +-- Mapping(s)
                      +-- Source(s)
                      +-- Transformation(s)
                      +-- Target(s)
            +-- Worklet(s)
            +-- Event Wait/Raise
            +-- Timer
            +-- Decision
            +-- Command Task
       +-- Mapplet(s) (reusable transformation groups)
       +-- Source/Target Definitions
       +-- Parameter Files
```

## Key Transformation Analysis

When analyzing Informatica mappings, document each transformation's purpose:

| Transformation | What to Document | Migration Consideration |
|---|---|---|
| **Source Qualifier (SQ)** | Custom SQL override, join conditions, filter | Becomes a source query or view on target |
| **Expression (EXP)** | All port expressions, variable ports (evaluated top-to-bottom) | Convert expression language to SQL CASE/functions |
| **Filter (FIL)** | Filter condition | Becomes WHERE clause |
| **Joiner (JNR)** | Join type, condition, sorted input requirement | Becomes SQL JOIN; check join type carefully (MASTER OUTER vs DETAIL OUTER vs FULL) |
| **Lookup (LKP)** | Connected vs unconnected, condition, return port, cache settings | Connected: becomes JOIN. Unconnected: becomes scalar subquery or UDF |
| **Aggregator (AGG)** | Group-by ports, aggregate expressions, sorted input | Becomes GROUP BY query |
| **Router (RTR)** | Group filter conditions, default group | Becomes CASE WHEN or multiple INSERT...SELECT |
| **Sorter (SRT)** | Sort key, distinct flag | Becomes ORDER BY or DISTINCT |
| **Rank (RNK)** | Rank port, group-by, top/bottom N | Becomes ROW_NUMBER/RANK window function with QUALIFY |
| **Normalizer (NRM)** | Occurs columns, generated keys | Becomes UNPIVOT or LATERAL FLATTEN |
| **Update Strategy (UPD)** | DD_INSERT, DD_UPDATE, DD_DELETE, DD_REJECT | Becomes MERGE or conditional DML |
| **Sequence Generator (SEQ)** | Start value, increment, cycle | Becomes Snowflake SEQUENCE or Databricks MONOTONICALLY_INCREASING_ID/IDENTITY |
| **Stored Procedure (SP)** | Procedure name, parameters | Inline the logic or create equivalent stored procedure |
| **Custom Transformation / Java** | Java code, input/output ports | Rewrite as UDF (Python/SQL) on target |
| **SQL Transformation** | Embedded SQL, connection type | Inline into main SQL flow |
| **HTTP Transformation** | REST API calls | Move to external orchestration (Airflow, Azure Data Factory) |
| **Mapplet** | Reusable logic block | Convert to reusable view, CTE, or macro/UDF |

## Informatica Expression Language Mapping

| Informatica Function | SQL Equivalent |
|---|---|
| `IIF(cond, true_val, false_val)` | `CASE WHEN cond THEN true_val ELSE false_val END` |
| `DECODE(val, match1, result1, ..., default)` | `CASE val WHEN match1 THEN result1 ... ELSE default END` |
| `IS_SPACES(x)` | `TRIM(x) = '' OR x IS NULL` |
| `IS_NUMBER(x)` | `TRY_CAST(x AS NUMBER) IS NOT NULL` (Snowflake) / `CAST(x AS DOUBLE) IS NOT NULL` with try-catch |
| `LTRIM/RTRIM/TRIM` | `LTRIM/RTRIM/TRIM` |
| `SUBSTR(str, start, len)` | `SUBSTRING(str, start, len)` (1-based in both) |
| `INSTR(str, search, start, occurrence)` | `POSITION` or `REGEXP_INSTR` |
| `REG_EXTRACT(str, pattern, group)` | `REGEXP_SUBSTR` with group extraction |
| `REG_REPLACE(str, pattern, replace)` | `REGEXP_REPLACE(str, pattern, replace)` |
| `TO_DATE(str, format)` | `TO_DATE(str, format)` (check format string differences!) |
| `TO_CHAR(val, format)` | `TO_CHAR(val, format)` |
| `TO_DECIMAL(str, scale)` | `CAST(str AS DECIMAL(38, scale))` |
| `TO_INTEGER(str)` | `CAST(str AS INTEGER)` |
| `ROUND(val, precision)` | `ROUND(val, precision)` |
| `TRUNC(val, precision)` | `TRUNC(val, precision)` (Snowflake) / `TRUNCATE` (Databricks) |
| `ADD_TO_DATE(date, format, amount)` | `DATEADD(format, amount, date)` |
| `DATE_DIFF(date1, date2, format)` | `DATEDIFF(format, date2, date1)` |
| `SYSDATE` | `CURRENT_TIMESTAMP()` |
| `SESSSTARTTIME` | `CURRENT_TIMESTAMP()` (or pipeline start time variable) |
| `LPAD/RPAD(str, len, pad)` | `LPAD/RPAD(str, len, pad)` |
| `REPLACECHR(case_flag, str, chars, replacement)` | `TRANSLATE(str, chars, replacement)` or `REPLACE` |
| `REPLACESTR(case_flag, str, search, replacement)` | `REPLACE(str, search, replacement)` |
| `ERROR('message')` | Raise exception in stored procedure or reject to error table |
| `ABORT('message')` | Raise exception to halt pipeline |
| `LOOKUP(...)` (unconnected) | Scalar subquery: `(SELECT col FROM table WHERE ...)` |
| Variable ports (`v_`)  | CTEs or intermediate columns evaluated in order |
| Output ports (`o_`) | Final SELECT columns |

## Informatica XML Export Structure

When analyzing exported Informatica XML (PowerCenter repository exports):

```xml
<!-- Top-level structure of an Informatica XML export -->
<POWERMART>
  <REPOSITORY>
    <FOLDER NAME="folder_name">
      <SOURCE NAME="source_table" DBDNAME="schema.table"/>
      <TARGET NAME="target_table" DBDNAME="schema.table"/>
      <MAPPLET NAME="reusable_logic">
        <TRANSFORMATION NAME="exp_transform" TYPE="Expression"/>
      </MAPPLET>
      <MAPPING NAME="m_mapping_name">
        <TRANSFORMATION NAME="SQ_source" TYPE="Source Qualifier">
          <TRANSFORMFIELD NAME="col1" DATATYPE="string"/>
        </TRANSFORMATION>
        <TRANSFORMATION NAME="EXP_calc" TYPE="Expression">
          <TRANSFORMFIELD NAME="v_amount" EXPRESSION="IIF(ISNULL(price),0,price*qty)"
                          PORTTYPE="LOCAL VARIABLE"/>
          <TRANSFORMFIELD NAME="o_amount" EXPRESSION="v_amount" PORTTYPE="OUTPUT"/>
        </TRANSFORMATION>
        <CONNECTOR FROMINSTANCE="SQ_source" TOINSTANCE="EXP_calc"
                   FROMFIELD="col1" TOFIELD="col1"/>
      </MAPPING>
      <SESSION NAME="s_session_name" MAPPINGNAME="m_mapping_name"/>
      <WORKFLOW NAME="wf_workflow_name">
        <TASKINSTANCE NAME="s_session_name" TASKTYPE="Session"/>
      </WORKFLOW>
    </FOLDER>
  </REPOSITORY>
</POWERMART>
```

**Key XML elements to parse:**
- `<TRANSFORMATION>`: Each node has TYPE, NAME, and child `<TRANSFORMFIELD>` elements
- `<TRANSFORMFIELD>`: Contains EXPRESSION attribute (the actual logic), PORTTYPE (INPUT, OUTPUT, INPUT/OUTPUT, LOCAL VARIABLE)
- `<CONNECTOR>`: Maps data flow between transformations (FROMINSTANCE -> TOINSTANCE, FROMFIELD -> TOFIELD)
- `<SESSIONEXTENSION>`: Contains connection information, pre/post-session SQL
- `<ATTRIBUTE NAME="Source Filter">`: Source Qualifier filter conditions
- `<ATTRIBUTE NAME="User Defined Join">`: Source Qualifier custom joins

## Informatica Variable Port Evaluation

**Critical**: Variable ports in Expression transformations evaluate **top-to-bottom in the order they appear**. This order-dependency must be preserved during migration.

```
-- Informatica Expression transformation port order:
v_prev_amount  = v_running_total          -- References PREVIOUS iteration's running total
v_running_total = v_running_total + amount -- Accumulates (references itself = previous row value)
o_running_total = v_running_total          -- Output the accumulated value
```

When converting to SQL, map variable ports to:
- **Window functions** if the logic is row-by-row accumulation: `SUM(amount) OVER (ORDER BY ... ROWS UNBOUNDED PRECEDING)`
- **CTEs with LAG/LEAD** if the logic references previous/next row values
- **Recursive CTEs** for complex iterative logic (rare, last resort)

## Connected vs Unconnected Lookups

| Type | Behavior | SQL Equivalent |
|---|---|---|
| **Connected Lookup** | Sits in the data flow pipeline; receives input, returns output for every row | `LEFT JOIN` (or `INNER JOIN` based on mapping) |
| **Unconnected Lookup** | Called on-demand via `:LKP.lookup_name(input)` from an Expression | Scalar subquery: `(SELECT col FROM table WHERE key = :input)` |

**Connected Lookup cache modes:**
- `Static Cache` (default): Loaded once at session start -> maps to a standard JOIN
- `Dynamic Cache`: Updated during session -> maps to MERGE/UPSERT pattern
- `Persistent Cache`: Survives across sessions -> maps to a materialized staging table

## Informatica Session Properties to Document

| Property | What It Controls | Migration Impact |
|---|---|---|
| **Target Load Type** (BULK/NORMAL) | Bulk bypasses indexes/triggers | Affects load strategy on target |
| **Commit Interval** | Rows between commits | Batch size on target |
| **Error Handling** (Stop on N errors) | Error threshold before abort | Error handling config in target pipeline |
| **Pre-Session SQL** | SQL run before mapping executes | Often contains TRUNCATE, temp table creation |
| **Post-Session SQL** | SQL run after mapping completes | Often contains stats collection, partition swap |
| **Pushdown Optimization** | Whether SQL is pushed to source/target DB | If enabled, actual SQL may differ from visual mapping |
| **Session Log File** | Logging location and verbosity | Map to target platform logging |

## Informatica Analysis Checklist

1. **Export mappings as XML** and parse for automated analysis when dealing with hundreds of mappings
2. **Identify parameter files** (`$$param` references) - catalog all parameters and their runtime values
3. **Map connection objects** to target platform connections/secrets
4. **Check session properties**: target load type (BULK vs NORMAL), commit interval, DTM buffer size, error handling thresholds
5. **Identify pre/post-session SQL** - these often contain critical DDL (TRUNCATE, CREATE TABLE, UPDATE stats)
6. **Trace variable port evaluation order** - variable ports in Expression transformations are evaluated top-to-bottom; order matters
7. **Check for pushdown optimization** - if enabled, the actual SQL pushed to the database may differ from the visual mapping
8. **Document reusable mapplets** separately as candidate shared components
9. **Identify SCD (Slowly Changing Dimension) patterns** - look for mappings with Lookup + Router + Update Strategy combinations
10. **Check for source-side vs target-side filtering** to understand where row reduction happens

## Informatica Naming Conventions (Common Prefixes)

| Prefix | Object Type | Example |
|---|---|---|
| `m_` | Mapping | `m_load_dim_customer` |
| `s_` | Session | `s_load_dim_customer` |
| `wf_` | Workflow | `wf_daily_customer_load` |
| `wl_` | Worklet | `wl_scd_processing` |
| `mplt_` | Mapplet | `mplt_address_cleansing` |
| `sq_` | Source Qualifier | `sq_STG_CUSTOMER` |
| `exp_` | Expression | `exp_CALC_AMOUNTS` |
| `lkp_` | Lookup | `lkp_DIM_PRODUCT` |
| `jnr_` | Joiner | `jnr_CUSTOMER_ADDRESS` |
| `rtr_` | Router | `rtr_SCD_ROUTING` |
| `agg_` | Aggregator | `agg_DAILY_TOTALS` |
| `fil_` | Filter | `fil_ACTIVE_ONLY` |
| `upd_` | Update Strategy | `upd_INSERT_OR_UPDATE` |
| `seq_` | Sequence Generator | `seq_CUSTOMER_SK` |

## Parameter File Format

```ini
[Global]
$$GLOBAL_PARAM=value

[folder_name.WF:workflow_name.ST:session_name]
$$PARAM1=value1
$$PARAM2=2024-01-01 00:00:00
$InputFile_SQ_instance=filename.dat
$OutputFile_TGT_instance=output.dat
$DBConnection_SRC=ConnectionName
$PMSessionLogDir=/path/to/logs
$PMBadFileDir=/path/to/bad
$PMCacheDir=/path/to/cache

[folder_name.WF:workflow_name]
$$WF_PARAM=value
```

Parameter types:
- `$$` prefix: User-defined mapping/workflow parameters
- `$PMSessionLogDir`, `$PMBadFileDir`, etc.: Built-in service process variables
- `$InputFile_`, `$OutputFile_`: File connection overrides
- `$DBConnection_`: Database connection overrides per session

## Repository Metadata Extraction

**pmrep Command-Line Utility:**
```bash
pmrep connect -r REPO_NAME -d DOMAIN -n user -x password
pmrep listobjects -o mapping -f FOLDER_NAME          # List mappings
pmrep listobjects -o workflow -f FOLDER_NAME          # List workflows
pmrep getmappingdetails -m MAPPING -f FOLDER_NAME     # Mapping details
pmrep objectexport -o folder -n FOLDER -u EXPORT.xml  # Export folder to XML
pmrep listobjectdependencies -o mapping -n MAP -f FOLDER -p parents  # Upstream deps
pmrep listobjectdependencies -o mapping -n MAP -f FOLDER -p children # Downstream deps
```

**Repository Database Tables** (for direct SQL queries):
| Table | Contains |
|---|---|
| `OPB_MAPPING` | Mapping metadata (name, ID, is_valid) |
| `OPB_WIDGET` | Transformation instances within mappings |
| `OPB_WIDGET_FIELD` | Ports on transformations (names, types, expressions) |
| `OPB_WIDGET_ATTR` | Transformation-level attributes/properties |
| `OPB_SRC` / `OPB_SRC_FLD` | Source definitions and fields |
| `OPB_TGT` / `OPB_TGT_FLD` | Target definitions and fields |
| `OPB_WORKFLOW` | Workflow metadata |
| `OPB_SESSION` | Session metadata (session_id, mapping_id, workflow_id) |
| `OPB_TASK_INST` | Task instances within workflows |
| `OPB_TASK_INST_RUN` | Runtime statistics |
| `OPB_SUBJECT` | Folder metadata |
| `REP_SESS_LOG` | Session run log data |

## Workflow Link Conditions

Links between tasks use these condition variables:
```
$Session1.Status = SUCCEEDED | FAILED | ABORTED | STOPPED
$Session1.SrcSuccessRows > 0
$Session1.TgtSuccessRows > 0
$Session1.TotalTgtRows = 0
$Decision1.condition = TRUE
$$WF_VARIABLE = 'Y'
```

## Common Informatica Pitfalls During Migration

1. **Session-level overrides are invisible in the mapping**: Always check session properties for SQL overrides, connection changes, and property overrides
2. **Reusable transformations may be stale**: If modified after being added to a mapping, instances may use old versions if not synced
3. **Shortcut references**: Objects may be shortcuts to other folders - follow shortcuts to actual definitions
4. **Dynamic lookups modify cache during runtime**: Affects data lineage interpretation
5. **Multiple target instances**: Same target table may appear multiple times (once for inserts, once for updates) - each is independent
6. **Persistent lookup caches**: Cache may not come from the lookup source table if pre-built/shared across sessions
7. **Workflow variable persistence**: Persistent variables retain values across runs, creating hidden state
8. **Active vs Passive distinction**: Active transformations change row counts (Filter, Router, Aggregator, Joiner, Normalizer, Rank, Union). Passive transformations preserve row counts (Expression, Lookup, Sequence Generator, Sorter without distinct)

## Workflow Orchestration Mapping

| Informatica Workflow Construct | Snowflake Equivalent | Databricks Equivalent |
|---|---|---|
| Workflow with sequential sessions | Snowflake Tasks with dependencies | Databricks Workflow (Jobs) |
| Parallel session branches | Independent Tasks (same schedule) | Parallel tasks in Workflow |
| Worklets | Task graphs / stored procedures | Sub-workflows or task groups |
| Event Wait/Raise | Streams + Tasks (event-driven) | File arrival sensors / Auto Loader |
| Timer | CRON-based task schedule | Cron-triggered job |
| Decision task | IF/ELSE in stored procedure | `if/else` in notebook or workflow |
| Command task | Pre/post SQL in Task | Notebook task with shell commands |
| Email task | External notification (SNS, etc.) | Webhook or notification task |
| Parameter files | Session variables / environment config | Workflow parameters / widget parameters |

---

## Informatica-to-SQL Conversion Patterns (Advanced)

### Full Mapping Conversion Walkthrough

When converting a complete Informatica mapping to SQL:

**Step 1: Identify the source query**
```
SQ_SOURCE (Source Qualifier) with custom SQL override:
  SELECT a.id, a.name, b.amount
  FROM schema.table_a a, schema.table_b b
  WHERE a.id = b.id AND a.active_flag = 'Y'
```
-> This becomes your base CTE or source subquery

**Step 2: Chain transformations as CTEs**
```sql
WITH
-- Source Qualifier (base query)
sq_source AS (
    SELECT a.id, a.name, b.amount
    FROM schema.table_a a
    JOIN schema.table_b b ON a.id = b.id
    WHERE a.active_flag = 'Y'
),
-- Expression transformation (variable ports + output ports)
exp_calc AS (
    SELECT
        id,
        name,
        amount,
        -- v_category (variable port)
        CASE WHEN amount > 1000 THEN 'HIGH'
             WHEN amount > 100 THEN 'MEDIUM'
             ELSE 'LOW' END AS category,
        -- o_adjusted_amount (output port referencing variable)
        amount * 1.1 AS adjusted_amount
    FROM sq_source
),
-- Filter transformation
fil_active AS (
    SELECT * FROM exp_calc
    WHERE category IN ('HIGH', 'MEDIUM')
),
-- Lookup transformation (connected, static cache -> LEFT JOIN)
lkp_region AS (
    SELECT
        f.*,
        COALESCE(r.region_name, 'UNKNOWN') AS region_name
    FROM fil_active f
    LEFT JOIN dim_region r ON f.region_id = r.region_id
),
-- Aggregator transformation
agg_summary AS (
    SELECT
        region_name,
        category,
        COUNT(*) AS record_count,
        SUM(adjusted_amount) AS total_amount
    FROM lkp_region
    GROUP BY region_name, category
)
-- Final INSERT (Update Strategy = DD_INSERT)
INSERT INTO target_summary (region_name, category, record_count, total_amount, load_timestamp)
SELECT region_name, category, record_count, total_amount, CURRENT_TIMESTAMP()
FROM agg_summary;
```

### Router Transformation -> Multiple INSERT Pattern

```sql
-- Informatica Router with 3 groups: high_value, medium_value, default_group
-- Each group becomes a separate INSERT with its filter condition

INSERT INTO target_high_value (...)
SELECT ... FROM source_cte WHERE amount > 10000;

INSERT INTO target_medium_value (...)
SELECT ... FROM source_cte WHERE amount BETWEEN 1000 AND 10000;

INSERT INTO target_low_value (...)
SELECT ... FROM source_cte WHERE amount < 1000 OR amount IS NULL;  -- default group
```

### Update Strategy -> MERGE Pattern

```sql
-- Informatica Update Strategy with DD_INSERT and DD_UPDATE
-- Driven by: IIF(ISNULL(lkp_existing_id), DD_INSERT, DD_UPDATE)

MERGE INTO target_table AS tgt
USING source_cte AS src
ON tgt.business_key = src.business_key
WHEN MATCHED THEN
    UPDATE SET tgt.col1 = src.col1, tgt.modified_date = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN
    INSERT (business_key, col1, created_date, modified_date)
    VALUES (src.business_key, src.col1, CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP());
```
