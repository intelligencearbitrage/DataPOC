---
paths:
  - "src/ssis/**/*.dtsx"
  - "legacy/ssis/**/*.dtsx"
  - "ssis/**/*.dtsx"
  - "**/*.dtsx"
---

# SSIS Reverse Engineering

You are analyzing **read-only SSIS .dtsx packages**. Do NOT modify these files. Your goal is to parse the XML structure, trace control and data flows, and produce structured migration documentation.

## SSIS Package Structure

SSIS packages (.dtsx) are XML files containing:
```
Package (.dtsx)
  +-- Connection Managers (database, file, HTTP, FTP connections)
  +-- Variables & Parameters
  +-- Control Flow
  |    +-- Data Flow Tasks
  |    |    +-- Sources (OLE DB, Flat File, Excel, ADO.NET)
  |    |    +-- Transformations (Derived Column, Lookup, Conditional Split, etc.)
  |    |    +-- Destinations (OLE DB, Flat File, etc.)
  |    +-- Execute SQL Tasks
  |    +-- Execute Package Tasks
  |    +-- Script Tasks (C#/VB.NET)
  |    +-- For/ForEach Loop Containers
  |    +-- Sequence Containers
  |    +-- File System Tasks
  |    +-- FTP/Send Mail Tasks
  +-- Event Handlers (OnError, OnPreExecute, OnPostExecute, etc.)
  +-- Precedence Constraints (Success/Failure/Completion + Expressions)
```

## SSIS Component Analysis

| SSIS Component | What to Document | Migration Approach |
|---|---|---|
| **OLE DB Source** | SQL command or table, parameters | Source query in target SQL |
| **Flat File Source** | File path, delimiters, text qualifier, column mappings | Snowflake: COPY INTO + file format. Databricks: Auto Loader / read CSV |
| **Derived Column** | SSIS expressions for each derived column | SQL CASE/function expressions |
| **Lookup** | Full/Partial cache, matched/unmatched output, join columns | SQL JOIN (full cache) or subquery |
| **Conditional Split** | Output conditions and names | CASE WHEN for routing, or INSERT...SELECT with WHERE |
| **Multicast** | Number of output paths | Multiple INSERT statements from same source |
| **Union All** | Input mappings | SQL UNION ALL |
| **Merge / Merge Join** | Join type, sorted input requirement | SQL JOIN (ensure correct join type) |
| **Aggregate** | Group-by columns, aggregate functions | SQL GROUP BY |
| **Sort** | Sort columns, remove duplicates flag | ORDER BY / DISTINCT |
| **Row Count** | Variable for storing count | SELECT COUNT(*) or logging |
| **Slowly Changing Dimension** | SCD type, business key, changing/historical/fixed attributes | MERGE statement with Type 1/2 logic |
| **Script Component (Source/Transform/Dest)** | Full C#/VB.NET code | Rewrite as UDF, stored procedure, or external process |
| **Script Task** | Full C#/VB.NET code, variable usage | Stored procedure, external orchestration, or cloud function |
| **Execute SQL Task** | SQL statement, parameter mappings, result set type | Direct SQL execution in target |
| **Execute Package Task** | Child package reference, parameter passing | Task dependency or stored procedure call |
| **ForEach Loop Container** | Enumerator type (file, ADO, variable), variable mappings | Programmatic loop or file-based orchestration |
| **Precedence Constraints** | Success/Failure/Completion, expression conditions | Task dependencies with conditions in orchestrator |
| **Event Handlers** | OnError logging, OnPreExecute setup, etc. | Error handling in stored procedures or orchestrator |

## SSIS Expression to SQL Mapping

| SSIS Expression | SQL Equivalent |
|---|---|
| `(condition) ? true_val : false_val` | `CASE WHEN condition THEN true_val ELSE false_val END` |
| `(DT_STR, len, codepage)col` | `CAST(col AS VARCHAR(len))` |
| `(DT_I4)col` | `CAST(col AS INTEGER)` |
| `(DT_DBTIMESTAMP)col` | `CAST(col AS TIMESTAMP)` |
| `(DT_WSTR, len)col` | `CAST(col AS VARCHAR(len))` |
| `SUBSTRING(str, start, len)` | `SUBSTRING(str, start, len)` |
| `LEN(str)` | `LENGTH(str)` |
| `TRIM(str)` | `TRIM(str)` |
| `UPPER(str)` / `LOWER(str)` | `UPPER(str)` / `LOWER(str)` |
| `REPLACE(str, find, replace)` | `REPLACE(str, find, replace)` |
| `FINDSTRING(str, search, occurrence)` | `REGEXP_INSTR` or nested `POSITION` |
| `RIGHT(str, n)` / `LEFT(str, n)` | `RIGHT(str, n)` / `LEFT(str, n)` |
| `DATEADD(part, n, date)` | `DATEADD(part, n, date)` |
| `DATEDIFF(part, start, end)` | `DATEDIFF(part, start, end)` |
| `GETDATE()` | `CURRENT_TIMESTAMP()` |
| `YEAR(date)` / `MONTH(date)` / `DAY(date)` | `YEAR(date)` / `MONTH(date)` / `DAY(date)` |
| `ISNULL(col)` | `col IS NULL` |
| `NULL(DT_I4)` | `NULL::INTEGER` or `CAST(NULL AS INTEGER)` |
| `@[User::VarName]` | Pipeline variable / stored proc variable |
| `@[System::StartTime]` | `CURRENT_TIMESTAMP()` or pipeline metadata |

## SSIS Error Output Handling

Every source and transformation can have an error output with `ErrorCode` and `ErrorColumn` columns. Check the `errorRowDisposition` attribute:

| Value | Behavior | Migration Approach |
|---|---|---|
| `FailComponent` | Entire data flow fails on error | Use TRY_CAST / error table + MERGE |
| `IgnoreFailure` | Error is silently ignored, NULL inserted | Use TRY_CAST with COALESCE |
| `RedirectRow` | Row sent to error output path | Write to error/reject table with error details |

## SSIS Component Class IDs Reference

When parsing .dtsx XML, identify components by `componentClassID`:

| Class ID | Component |
|---|---|
| `Microsoft.OLEDBSource` | OLE DB Source |
| `Microsoft.OLEDBDestination` | OLE DB Destination |
| `Microsoft.Lookup` | Lookup Transformation |
| `Microsoft.DerivedColumn` | Derived Column |
| `Microsoft.ConditionalSplit` | Conditional Split |
| `Microsoft.Merge` | Merge |
| `Microsoft.MergeJoin` | Merge Join |
| `Microsoft.Aggregate` | Aggregate |
| `Microsoft.ScriptComponent` | Script Component |
| `Microsoft.FlatFileSource` / `Microsoft.FlatFileDestination` | Flat File Source/Dest |
| `Microsoft.UnionAll` | Union All |
| `Microsoft.Multicast` | Multicast |
| `Microsoft.SCD` | Slowly Changing Dimension |

Non-Microsoft `componentClassID` values indicate **third-party components** (CozyRoc, Pragmatic Works Task Factory, KingswaySoft, CDATA, Attunity connectors).

## SSIS Precedence Constraint Details

| Property | Values | Meaning |
|---|---|---|
| **EvalOp** | `Constraint` | Uses only execution result |
| | `Expression` | Uses only expression |
| | `ExpressionAndConstraint` | Both must be true |
| | `ExpressionOrConstraint` | Either can be true |
| **Value** | `Success` (green line) | Preceding task succeeded |
| | `Failure` (red line) | Preceding task failed |
| | `Completion` (blue line) | Task completed regardless of result |
| **LogicalAnd** | `True` / `False` | When multiple constraints target one task: AND vs OR |

## SSIS Features with No Direct Target Equivalent

Flag these during migration analysis - they require special handling:
- **Checkpoints**: Restart-from-failure using checkpoint files (no equivalent; redesign with idempotent tasks)
- **Event Handlers**: Per-task event workflows (map to orchestrator error handling)
- **MaxConcurrentExecutables**: Package-level parallelism control (map to orchestrator concurrency settings)
- **ForceExecutionResult**: Debug override property (remove during migration)
- **Protection Levels**: Package-level encryption (replace with cloud secret management)
- **Distributed Transactions**: Cross-task transaction enrollment (redesign as idempotent operations)
- **Buffer-Based Pipeline**: SSIS's in-memory buffer architecture (no equivalent; SQL-based transforms replace this)

## SSIS .dtsx XML Structure for Parsing

When programmatically analyzing SSIS packages, key XML namespaces and elements:

```xml
<!-- Key namespaces -->
<!-- DTS: = www.microsoft.com/SqlServer/Dts -->
<!-- SQLTask: = www.microsoft.com/sqlserver/dts/tasks/sqltask -->

<!-- Connection Managers -->
<DTS:ConnectionManager DTS:ObjectName="OLE_DB_Source" DTS:DTSID="{guid}">
  <DTS:PropertyExpression DTS:Name="ConnectionString">
    @[User::ConnectionString]
  </DTS:PropertyExpression>
</DTS:ConnectionManager>

<!-- Control Flow - Execute SQL Task -->
<DTS:Executable DTS:ExecutableType="Microsoft.ExecuteSQLTask">
  <DTS:ObjectData>
    <SQLTask:SqlTaskData SQLTask:SqlStatementSource="TRUNCATE TABLE staging"/>
  </DTS:ObjectData>
</DTS:Executable>

<!-- Data Flow Task (pipeline) -->
<DTS:Executable DTS:ExecutableType="Microsoft.Pipeline">
  <DTS:ObjectData>
    <pipeline>
      <components>
        <component componentClassID="Microsoft.OLEDBSource">
          <properties>
            <property name="SqlCommand">SELECT * FROM source</property>
          </properties>
        </component>
      </components>
      <paths>
        <path startId="output_id" endId="input_id"/>
      </paths>
    </pipeline>
  </DTS:ObjectData>
</DTS:Executable>

<!-- Precedence Constraints -->
<DTS:PrecedenceConstraint DTS:Value="Success" DTS:Expression="@[User::RowCount] > 0"
  DTS:EvalOp="ExpressionAndConstraint"/>
```

## SSIS Script Task/Component Deep Analysis

Script Tasks and Script Components contain C#/VB.NET code that often holds critical business logic:

**Script Task** (Control Flow - full .NET access):
```csharp
// Common patterns to look for:
public void Main()
{
    // File operations (rename, move, archive)
    string filePath = Dts.Variables["User::FilePath"].Value.ToString();
    File.Move(filePath, archivePath);

    // Web service / API calls
    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

    // Custom logging
    Dts.Events.FireInformation(0, "Script", "Processing complete", "", 0, ref fireAgain);

    // Variable manipulation
    Dts.Variables["User::RowCount"].Value = count;
    Dts.TaskResult = (int)ScriptResults.Success;
}
```

**Script Component** (Data Flow - row-by-row processing):
```csharp
// Source: generates rows
public override void CreateNewOutputRows()
{
    // Read from API, file, or custom source
    Output0Buffer.AddRow();
    Output0Buffer.Column1 = value;
}

// Transform: processes each row
public override void Input0_ProcessInputRow(Input0Buffer Row)
{
    Row.OutputColumn = CustomTransform(Row.InputColumn);
}

// Destination: writes rows
public override void Input0_ProcessInputRow(Input0Buffer Row)
{
    // Custom write logic (API call, custom file format, etc.)
}
```

**Migration approach**: Extract the business logic from Script Tasks/Components and rewrite as:
- SQL UDFs or stored procedures (if the logic is data transformation)
- External Python/shell scripts called by the orchestrator (if it's file operations or API calls)
- Cloud functions (Lambda/Azure Functions) for complex external integrations

## SSIS Deployment Model Considerations

| Model | Characteristics | Migration Impact |
|---|---|---|
| **Package Deployment** (legacy) | .dtsx files deployed to file system or MSDB, XML configurations | Extract config values from XML files and dtsx packages |
| **Project Deployment** (SSIS 2012+) | .ispac deployed to SSISDB catalog, project parameters, environment references | Query SSISDB catalog for parameter values and environment mappings |

**SSISDB Catalog queries for project deployment metadata:**
```sql
-- Extract all project parameters and their values
SELECT p.name AS project_name, pr.parameter_name, pr.default_value, pr.data_type
FROM SSISDB.catalog.projects p
JOIN SSISDB.catalog.object_parameters pr ON p.project_id = pr.project_id;

-- Extract environment variable mappings
SELECT e.name AS env_name, ev.name AS var_name, ev.value, ev.type
FROM SSISDB.catalog.environments e
JOIN SSISDB.catalog.environment_variables ev ON e.environment_id = ev.environment_id;
```

## SSIS Common ETL Patterns to Recognize

| Pattern | How to Identify | Migration Approach |
|---|---|---|
| **Truncate and Reload** | Execute SQL Task (TRUNCATE) -> Data Flow (full SELECT) | `CREATE OR REPLACE TABLE AS SELECT` or `INSERT OVERWRITE` |
| **Incremental Load** | Source SQL with `WHERE modified_date > ?` using variable | Snowflake Streams + Tasks or Databricks CDF |
| **SCD Type 1** | Lookup (match on business key) -> Conditional Split (changed vs new) -> OLE DB Command (UPDATE) + OLE DB Destination (INSERT) | `MERGE ... WHEN MATCHED THEN UPDATE WHEN NOT MATCHED THEN INSERT` |
| **SCD Type 2** | SSIS SCD Wizard component or Lookup + Derived Column (hash) + Conditional Split + multiple outputs | MERGE with hash comparison + INSERT for new versions |
| **File Processing Loop** | ForEach Loop (File Enumerator) -> Data Flow inside loop | Snowflake: COPY INTO with pattern. Databricks: Auto Loader |
| **Master Package** | Execute Package Tasks chained with precedence constraints | Workflow/DAG orchestration on target platform |
| **Error Row Capture** | Error output from component -> Flat File/Table destination | Error handling table + TRY_CAST for data quality |
| **Audit Logging** | Row Count transforms -> Execute SQL (INSERT into audit table) | Audit stored procedure or pipeline metadata logging |

## SSIS Variables: Scope and System Variables

**Variable Scope**: Variables are scoped to the container they are defined in. A package-scope variable is accessible everywhere; a variable inside a For Loop is only accessible within that loop.

**Key System Variables** (read-only, provided by SSIS runtime):
| Variable | Purpose | Migration Use |
|---|---|---|
| `System::PackageName` | Current package name | Pipeline name metadata |
| `System::StartTime` | Package start timestamp | Audit/logging |
| `System::ExecutionInstanceGUID` | Unique execution ID | Batch ID / correlation ID |
| `System::ErrorCode` / `System::ErrorDescription` | Error details in event handlers | Error logging |
| `System::SourceName` | Name of component that raised event | Error source tracking |

**Expression Variables**: When `EvaluateAsExpression = True`, the variable is computed at runtime. Common patterns:
- `GETDATE()` for dynamic timestamp
- `@[User::RootFolder] + "\\data\\" + @[User::FileName]` for dynamic paths
- `@[User::RowCount] > 0 ? "Success" : "NoData"` for conditional values

## SSIS Analysis Checklist

1. **Parse .dtsx XML** to extract all components programmatically for large package inventories (use DTS namespace: `www.microsoft.com/SqlServer/Dts`)
2. **Catalog all connection managers** and map to target connections (types: OLEDB, ADO.NET, FLATFILE, FILE, EXCEL, FTP, HTTP, SMTP)
3. **Document all variables and parameters** including scope (package, container, task level) and expression variables
4. **Trace precedence constraint expressions** - complex branching logic lives here (check EvalOp, Value, LogicalAnd)
5. **Extract and review all Script Task/Component code** - this is often where complex business logic hides
6. **Check Execute SQL Task result sets** - full result set, single row, or XML mapping to variables
7. **Document ForEach Loop patterns** - file enumerators need target-platform file handling
8. **Map event handlers** to error handling strategy on target
9. **Check for third-party components** (CozyRoc, Task Factory, KingswaySoft, Attunity, CDATA) and identify replacement strategy
10. **Identify configuration sources** (XML config, environment variable, SQL Server, package parameter) for deployment model
11. **Check error output dispositions** (FailComponent, IgnoreFailure, RedirectRow) for each data flow component
12. **Document checkpoint configuration** (CheckpointFileName, CheckpointUsage) for restart capability
13. **Map container hierarchy** including transaction boundaries (TransactionOption = Required)
