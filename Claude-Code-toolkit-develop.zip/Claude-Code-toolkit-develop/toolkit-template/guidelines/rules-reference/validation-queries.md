---
paths:
  - "src/validation/**/*.sql"
  - "tests/**/*.sql"
  - "validation/**/*.sql"
  - "qa/**/*.sql"
---

# Validation Query Rules

You are writing or reviewing **migration validation queries**.

## Standards

- Every validation query must output: test_name, source_value, target_value, status (PASS/FAIL)
- Follow the 4-level validation framework (Structural -> Data Content -> Statistical -> Functional)
- Apply tolerance thresholds: exact match for integers/decimals/NULL counts, <= 0.001% for floats
- Include the source object name and target object name in every test for traceability
- Group tests by validation level in the output
- Do NOT proceed to Level N+1 until Level N passes

## Validation Output Template

```sql
SELECT
    'test_name' AS test_name,
    'Level 1' AS validation_level,
    'source_object' AS source_object,
    'target_object' AS target_object,
    source_value,
    target_value,
    CASE WHEN source_value = target_value THEN 'PASS' ELSE 'FAIL' END AS status
FROM (source_query) s
CROSS JOIN (target_query) t;
```

## Level 1: Structural Validation Queries

```sql
-- Row count comparison
SELECT 'row_count' AS test_name, 'Level 1' AS level,
    (SELECT COUNT(*) FROM source_table) AS source_value,
    (SELECT COUNT(*) FROM target_table) AS target_value,
    CASE WHEN (SELECT COUNT(*) FROM source_table) = (SELECT COUNT(*) FROM target_table)
         THEN 'PASS' ELSE 'FAIL' END AS status;

-- Duplicate detection on business key
SELECT 'pk_uniqueness' AS test_name, 'Level 1' AS level,
    0 AS source_value,
    COUNT(*) AS target_value,
    CASE WHEN COUNT(*) = 0 THEN 'PASS' ELSE 'FAIL' END AS status
FROM (
    SELECT business_key, COUNT(*) AS cnt
    FROM target_table
    GROUP BY business_key
    HAVING COUNT(*) > 1
);
```

## Level 2: Data Content Validation Queries

```sql
-- Column checksum comparison (Snowflake)
SELECT 'checksum' AS test_name, 'Level 2' AS level,
    (SELECT SUM(HASH(col1, col2, col3)) FROM source_table) AS source_value,
    (SELECT SUM(HASH(col1, col2, col3)) FROM target_table) AS target_value,
    CASE WHEN source_value = target_value THEN 'PASS' ELSE 'FAIL' END AS status;

-- Boundary value checks
SELECT 'min_max_amount' AS test_name, 'Level 2' AS level,
    (SELECT MIN(amount) || '|' || MAX(amount) FROM source_table) AS source_value,
    (SELECT MIN(amount) || '|' || MAX(amount) FROM target_table) AS target_value,
    CASE WHEN source_value = target_value THEN 'PASS' ELSE 'FAIL' END AS status;
```

## Level 3: Statistical Validation Queries

```sql
-- Aggregate comparison
SELECT 'aggregate_amount' AS test_name, 'Level 3' AS level,
    (SELECT SUM(amount) FROM source_table) AS source_value,
    (SELECT SUM(amount) FROM target_table) AS target_value,
    CASE WHEN ABS(source_value - target_value) / NULLIF(source_value, 0) <= 0.00001
         THEN 'PASS' ELSE 'FAIL' END AS status;

-- NULL count comparison per column
SELECT 'null_count_' || column_name AS test_name, 'Level 3' AS level,
    source_nulls AS source_value,
    target_nulls AS target_value,
    CASE WHEN source_nulls = target_nulls THEN 'PASS' ELSE 'FAIL' END AS status
FROM null_count_comparison_view;

-- Distribution analysis
SELECT 'distribution_' || category AS test_name, 'Level 3' AS level,
    source_count AS source_value,
    target_count AS target_value,
    CASE WHEN source_count = target_count THEN 'PASS' ELSE 'WARN' END AS status
FROM (
    SELECT s.category, s.cnt AS source_count, t.cnt AS target_count
    FROM (SELECT category, COUNT(*) AS cnt FROM source_table GROUP BY category) s
    FULL OUTER JOIN (SELECT category, COUNT(*) AS cnt FROM target_table GROUP BY category) t
    ON s.category = t.category
);
```
