# Agent Authoring Guidelines

Ground rules for writing Claude Code agent definitions (`.claude/agents/*.md`). Every team member creating or modifying agents must follow these rules.

---

## Rule 1: One Agent, One Responsibility

Each agent has a single, clearly defined job. If you cannot describe what an agent does in one sentence, it is doing too much.

**Good — focused agents:**
- `source-a-analyzer-agent.md` — "Parses source A files and extracts structured findings"
- `planning-agent.md` — "Synthesizes all research outputs into unified plans"
- `output-builder-agent.md` — "Generates deliverables from plans"

**Bad — unfocused agents:**
- `data-agent.md` — "Parses all inputs, creates plans, generates outputs, and validates everything"
- `helper-agent.md` — "Assists other agents with various tasks as needed"

---

## Rule 2: Agents Orchestrate, Skills Execute

An agent definition describes **WHAT** needs to happen — the workflow, the inputs, the outputs, the quality criteria. A skill describes **HOW** to do the work — the parsing logic, the transformation code, the generation patterns.

| Belongs in Agent | Belongs in Skill |
|------------------|-----------------|
| Purpose and context | Implementation code (Python, etc.) |
| Processing steps (high-level) | Parsing algorithms |
| Input/output file paths | File I/O patterns |
| Quality criteria and success checks | Validation logic |
| Project-specific processing notes | Reusable transformation patterns |
| Error handling expectations | Error handling implementation |

**Rule of thumb:** If it contains a code block longer than 10 lines, it probably belongs in a skill, not the agent definition.

---

## Rule 3: Size Guideline — Under 250 Lines

Agent definitions should stay under **~250 lines**. This is a guideline, not a hard limit like the 500-line skill rule, but if your agent exceeds 250 lines, review whether you are putting skill-level detail into the agent.

**Typical line budget:**

| Section | Lines | Notes |
|---------|-------|-------|
| Purpose | 3-5 | One clear sentence + context |
| Trigger Commands | 3-5 | |
| Context | 5-10 | Background the agent needs |
| Skills Required | 3-5 | List skill names |
| Input Files | 10-20 | Be explicit about every file |
| Output Location | 5-10 | |
| Processing Steps | 30-50 | High-level, not code |
| Output Format | 30-60 | YAML/SQL/other examples of expected structure |
| Project-Specific Notes | 20-40 | Only if needed |
| Error Handling | 10-15 | What to do when things go wrong |
| Success Criteria | 10-15 | Checklist of "done" conditions |
| **Total** | **~130-235** | Target range |

---

## Rule 4: Required Structure

Every agent definition must include YAML frontmatter and the sections below.

### YAML Frontmatter (required)
```yaml
---
name: agent-name
description: "One-line description of what this agent does"
memory: project
skills:
  - self-review
---
```

- `memory: project` — enables native agent memory (auto-creates `.claude/agent-memory/{name}/`)
- `skills:` — must include `self-review`; add project-specific skills as needed

### Body Sections
```markdown
# [Agent Name] Agent

## Purpose
[One sentence: what this agent does and why it exists]

## Trigger Commands
- `command 1`
- `command 2`

## Context
[Background information the agent needs to do its job.
What part of the workflow does this agent handle?
What comes before and after this agent's work?]

## Skills Required
- `skill-name-1` - [what this skill provides]
- `skill-name-2` - [what this skill provides]

## Input Files
[Every file this agent reads, with explicit paths]
- `research/source-a/analysis.yaml` - Research findings from Phase 1
- `plans/MASTER_PLAN.yaml` - Unified plan (if applicable)

## Output Location
[Every file this agent produces, with explicit paths]
- `plans/component_plan.yaml` - Component-specific plan

## Processing Steps

### Step 1: [Action]
[What to do, not how to code it]

### Step 2: [Action]
[What to do, referencing which skill to use]

### Step N: [Action]
[Final step]

## Output Format
[YAML/JSON/SQL example showing expected output structure]

## Error Handling
[What to do when inputs are missing, malformed, or incomplete]

## Self-Review (Before Completing)
Run the self-review skill checklist, plus these agent-specific checks:
- [ ] Agent-specific check 1
- [ ] Agent-specific check 2

## Success Criteria
- [ ] Criterion 1
- [ ] Criterion 2
```

---

## Rule 5: Be Explicit About Files

Never use vague references like "read the input files" or "check the research outputs." Always list exact file paths.

**Bad:**
```markdown
## Input Files
- Research outputs
- Plans
```

**Good:**
```markdown
## Input Files
- `research/source-a/source_a_analysis.yaml` - Extracted structures and relationships
- `research/source-b/source_b_analysis.yaml` - Reference standard mappings
- `research/source-c/source_c_analysis.yaml` - Additional findings
```

---

## Rule 6: Processing Steps Are High-Level

Processing steps describe the workflow, not the code. Save code for skills.

**Bad — too much code in agent:**
```markdown
### Step 1: Parse input file
​```python
import xml.etree.ElementTree as ET
context = ET.iterparse(str(self.xml_path), events=('start', 'end'))
current_class = None
for event, elem in context:
    if event == 'end':
        if elem.tag.endswith('Class'):
            self._process_class(elem)
​```
```

**Good — high-level direction:**
```markdown
### Step 1: Parse input file
Use the `parse-source` skill to extract structured data.
Focus on:
- Key entity/component definitions
- Relationships and dependencies
- Attributes and metadata
```

---

## Rule 7: Agent vs. Skill — Decision Criteria

When you have new functionality to add, use this decision tree:

```
Is it a WORKFLOW (sequence of steps, inputs, outputs, quality criteria)?
  YES --> Agent definition (.claude/agents/)

Is it REUSABLE LOGIC (parsing, generation, validation patterns)?
  YES --> Skill file (.claude/skills/)

Is it REFERENCE CONTENT (specs, rules, mapping tables, source files)?
  YES --> Reference file (knowledgebase/ folder)

Is it a SOURCE DOCUMENT (files the team provided for analysis)?
  YES --> knowledgebase/ folder
```

### Common mistakes:

| What you have | Where people put it | Where it should go |
|---------------|--------------------|--------------------|
| Python parsing script | In the agent definition | In a skill |
| Bulk reference content (100+ lines) | In the skill | In a reference file in `knowledgebase/` |
| Multi-step workflow description | In a skill | In an agent definition |
| Small config mapping (10 entries) | In a reference file | In the skill (it's small enough to inline) |
| Large mapping table (200 entries) | In the skill | In a reference file in `knowledgebase/` |

---

## Rule 8: Define Success Criteria as Checkboxes

Every agent must have a Success Criteria section with checkboxes. These serve as the definition of "done" and are used by the reviewer agent during Phase 4 validation.

```markdown
## Success Criteria
- [ ] All source components identified and documented
- [ ] Relevant structures extracted (target: N+)
- [ ] Mappings to target outputs documented
- [ ] Gaps clearly identified with recommendations
- [ ] Output written to correct folder
- [ ] Output passes validity check
```

Do not use vague criteria like "agent completed successfully." Each criterion must be **verifiable** — someone should be able to check it by looking at a file or running a command.

---

## Good Example: What a Focused Agent Looks Like

A well-structured agent definition has these traits:

- **Clear purpose:** One sentence describing exactly what the agent does
- **Explicit inputs:** Exact file paths (e.g., `knowledgebase/reference_data.xlsx`)
- **Explicit outputs:** Exact paths (e.g., `research/component/analysis.yaml`)
- **Skills declared:** Lists which skills it uses
- **Steps are high-level:** Describes focus areas, not Python code
- **Success criteria:** Verifiable checkboxes
- **~100-150 lines total** — well within the 250-line guideline

---

## Bad Example: Bloated Agent

Signs an agent definition has gone wrong:

- **300+ lines** — agent is too large, likely contains skill-level code
- **Multiple code blocks over 10 lines** — implementation logic leaked into the agent
- **Vague inputs** — "reads from the research folder" without listing files
- **No skills referenced** — agent is trying to be self-contained instead of delegating to skills
- **No success criteria** — no way to verify the agent's work is done
- **Multiple unrelated responsibilities** — "parses data, creates plans, and generates output"

---

## Naming Conventions

| Type | Pattern | Example |
|------|---------|---------|
| Research agent | `{source}-analyzer-agent.md` | `source-a-analyzer-agent.md` |
| Planning agent | `planning-agent.md` | `planning-agent.md` |
| Builder agent | `{scope}-builder-agent.md` | `output-builder-agent.md` |
| Reviewer agent | `reviewer-agent.md` | `reviewer-agent.md` |
| Expert agent | `expert-{area}.md` | `expert-standards.md` |
| Orchestrator | `lead-orchestrator.md` | `lead-orchestrator.md` |

Use lowercase with hyphens. Always end with `-agent.md` or use the role as the suffix (e.g., `expert-`, `lead-`).

---

## Rule 9: Memory — Every Agent Must Have `memory: project`

Every agent definition must include `memory: project` in its YAML frontmatter. This enables native agent memory — the platform auto-creates `.claude/agent-memory/{name}/MEMORY.md` per agent. The first 200 lines are injected into the agent's context at startup.

Agents use memory to:
- Store significant assumptions made during tasks
- Record patterns discovered across multiple tasks
- Track lessons learned from escalations or failures
- Share context with their future selves across sessions

---

## Rule 10: Self-Review — Every Agent Must Include `self-review`

Every agent must include `self-review` in its `skills:` frontmatter list. Before marking any task as completed, agents run the self-review checklist (`.claude/skills/self-review.md`), which covers requirements verification, output validation, quality checks, and confidence assessment.

In addition to the standard checklist, each agent should define 2-3 **agent-specific checks** in a "Self-Review" section at the bottom of its definition.

---

## Rule 11: Escalation — Agents Follow the Escalation Protocol

All agents follow `.claude/rules/escalation.md` when stuck. The escalation protocol defines:
- **Stuck detection** — when to recognize you're stuck (missing inputs, ambiguity, repeated errors)
- **Severity levels** — L1 (self-resolve) through L4 (human required)
- **Escalation paths** — what to do at each level
- **Circuit breaker** — 3 failures → escalate to next level

Agents should never silently skip a requirement or fabricate missing information. When stuck, escalate.
