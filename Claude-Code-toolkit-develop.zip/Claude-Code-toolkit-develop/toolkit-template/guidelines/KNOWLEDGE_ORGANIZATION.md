# Knowledge Organization Guidelines

Ground rules for organizing reference data, source documents, and project files. This document defines what goes where and why.

---

## The Folder Map

There are four key areas that people confuse. Learn this map.

```
PROJECT ROOT
│
├── knowledgebase/           ← REFERENCE MATERIALS (stable)
│   │                          Standards, rules, conventions, best practices.
│   │                          Guides HOW the solution is built.
│   │                          Think of this as the "library."
│   │
│   ├── standards/           ← Industry specs, compliance docs
│   │   ├── naming_conventions.yaml
│   │   └── type_mappings.yaml
│   │
│   └── reference-data/      ← Structured reference files
│       ├── mappings.yaml
│       └── rules.yaml
│
├── inputs/                  ← SOURCE DATA (variable)
│   │                          Actual data the scripts process.
│   │                          Changes per project/run.
│   │                          Think of this as the "raw material."
│   │
│   ├── customer_model.xlsx
│   ├── legacy_schema.sql
│   └── source_data.csv
│
├── .claude/
│   ├── skills/              ← SKILL LOGIC (markdown with code)
│   │   │                      HOW to parse, transform, generate.
│   │   │                      Think of this as the "recipe book."
│   │   │
│   │   ├── parse-source.md
│   │   ├── validate-quality.md
│   │   └── self-review.md          ← Self-check before task completion
│   │
│   ├── agents/              ← AGENT DEFINITIONS (markdown)
│   │   │                      WHAT to do, in what order.
│   │   │                      Think of this as the "job descriptions."
│   │   │
│   │   ├── source-analyzer-agent.md
│   │   └── planning-agent.md
│   │
│   └── rules/               ← AUTO-LOADED RULES (markdown with paths: frontmatter)
│       │                      Escalation protocol and domain rules.
│       │                      Think of this as the "policy manual."
│       │                      Only files HERE are auto-loaded by Claude.
│       │
│       └── escalation.md           ← Always loaded (no paths: scope)
│                                      Add domain rules here by copying from
│                                      guidelines/rules-reference/
│
├── guidelines/
│   └── rules-reference/     ← GOLD STANDARD RULES (developer reference only)
│       │                      NOT auto-loaded by Claude. Study these, then
│       │                      copy relevant ones to .claude/rules/ to activate.
│       │
│       ├── source-teradata-sql.md       ← Teradata SQL reverse engineering
│       ├── source-informatica-xml.md    ← Informatica XML reverse engineering
│       ├── source-ssis-dtsx.md          ← SSIS .dtsx reverse engineering
│       ├── converted-snowflake-sql.md   ← Snowflake forward engineering
│       ├── converted-databricks-sql.md  ← Databricks forward engineering
│       ├── migration-methodology.md     ← 4-level validation, complexity scoring
│       ├── etl-python.md               ← Python ETL standards
│       └── validation-queries.md        ← Validation query templates
│
├── research/                ← GENERATED ANALYSIS (outputs from Phase 1)
│   │                          Created BY skills during research.
│   │
│   ├── source-a/analysis.yaml
│   └── expert/              ← Expert consultation outputs
│
├── plans/                   ← GENERATED PLANS (outputs from Phase 2)
│   ├── MASTER_PLAN.yaml
│   └── component_plan.yaml
│
├── scripts/                 ← GENERATED SCRIPTS (outputs from Phase 3)
│   └── generate_output.py
│
└── output/                  ← FINAL DELIVERABLES
    ├── deliverable_type_a/
    └── deliverable_type_b/
```

---

## Rule 1: Two Input Folders — `knowledgebase/` and `inputs/`

The toolkit uses two input folders with distinct purposes:

| Folder | Used By | Purpose | Examples |
|--------|---------|---------|---------|
| `knowledgebase/` | **Agent team** (pipeline) + **scripts** (runtime) | Reference materials the agents analyze to build scripts, and rules scripts apply at runtime | Standards, naming conventions, type mappings, source schemas, example models, best practices |
| `inputs/` | **Generated scripts** (runtime only) | Source data that scripts process to produce deliverables — agents do not access this folder | Production data files, actual datasets to transform |

Both folders are **read-only** — no agent or script may modify their contents. They are the ground truth.

**Default: flat structure.** Place files directly in each folder with descriptive names. This works well for most projects.

**Optional: subdirectories for 10+ files.** When your project has many files, organize into subdirectories by purpose:

**`knowledgebase/` subdirectories:**

| Subdirectory | Contains | Example Files |
|-------------|----------|---------------|
| `standards/` | External specifications or standards | Industry specs, compliance docs, naming conventions |
| `reference-data/` | Structured reference files skills read programmatically | `.yaml`, `.json` mappings, rules, type conversions |

**`inputs/` subdirectories:**

| Subdirectory | Contains | Example Files |
|-------------|----------|---------------|
| `source-data/` | Structured data files to process | `.xlsx`, `.csv`, `.sql`, `.xml` |
| `source-docs/` | Raw documents for initial analysis | `.md`, `.txt`, `.pdf` |
| (project-specific) | Other categories as needed | Organize by whatever makes sense for your project |

---

## Rule 2: `.claude/skills/` Is for Logic Only

This is the most common confusion. `.claude/skills/` holds **skill definitions** — markdown files with processing logic. It does NOT hold reference data.

| Folder | Contains | Example |
|--------|----------|---------|
| `.claude/skills/` | Skill logic definitions (markdown with code) | `parse-source.md` |
| `knowledgebase/` | Input material skills read from | `Source_Model.xlsx`, `rules.yaml` |

**Memory aid:**
- `.claude/skills/` = the **recipe** (instructions)
- `knowledgebase/` = the **seasoning** (reference rules and standards)
- `inputs/` = the **ingredients** (source data to process)

A skill in `.claude/skills/parse-source.md` reads reference rules from `knowledgebase/type_mappings.yaml` and source data from `inputs/customer_model.xlsx`. The skill file contains the parsing logic; knowledgebase contains the rules; inputs contains the data to parse.

---

## Rule 3: When to Create a Separate Reference File

Create a separate file in `knowledgebase/` when ANY of these apply:

| Condition | What it means |
|-----------|---------------|
| Content exceeds 50 lines | Too large to inline in a skill |
| Content is reused across multiple skills | Shared reference material |
| Content is maintained by a subject-matter expert | Not developer-authored |
| Content comes from an external source | Standards, specs, third-party models |
| Content is in a structured format | Excel, XML, CSV, JSON — not prose |

**Do NOT create a reference file when:**
- The content is under 50 lines (keep it inline as config in the skill)
- The content is specific to one skill and unlikely to change
- The content is a small lookup dictionary

---

## Rule 4: Naming Conventions

### Files in `knowledgebase/`

Use descriptive names that indicate the source and content type:

```
knowledgebase/
  # Good — clear source and content
  reference-data/
    source_a_model.xlsx
    conversion_rules.yaml
    type_mappings.yaml
  source-docs/
    project_requirements.md
    legacy_schema.sql

  # Bad — vague or ambiguous
  data.xlsx
  reference.yaml
  input.xml
  model.xlsx
```

**Rules:**
- Include the **source** name if the file comes from an external system or standard
- Include the **content type** (model, rules, mappings, dictionary, etc.)
- Use underscores for multi-word file names, hyphens for folder names
- Keep the original filename if it came from an external source

---

## Rule 5: Subdirectories for Large Projects

When you have more than 10 files in `knowledgebase/`, organize with subdirectories. Below 10 files, keep a flat structure — it's simpler and matches the default setup in SETUP_GUIDE.md Step 4a.

### By purpose (recommended default):

```
knowledgebase/
  reference-data/
    model_file_1.xlsx
    model_file_2.xlsx
    conversion_rules.yaml
  source-docs/
    requirements.md
    legacy_schema.sql
  standards/
    naming_conventions.md
    quality_rules.yaml
```

### By source (when inputs come from multiple systems):

```
knowledgebase/
  source-a/
    model_file_1.xlsx
    model_file_2.xlsx
  source-b/
    reference_spec.xml
  source-c/
    data_dictionary.xlsx
```

Choose whichever grouping makes sense for your project, but be consistent.

---

## Rule 6: Large File Handling

Files over 10MB need special treatment. Document the strategy in the skill that reads them.

| File Size | Strategy |
|-----------|----------|
| Under 1MB | Read directly, no special handling needed |
| 1-10MB | Note in skill that it may take time to process |
| 10-50MB | Use chunking or streaming in the skill implementation |
| Over 50MB | Split into smaller files before placing in `knowledgebase/`, or use a database |

If a skill processes a large file, it must:
1. Document the file size in the Input Files section
2. Implement chunking or streaming in the implementation
3. Include memory management (e.g., clearing processed elements)
4. Handle the case where the file is too large for memory

**Example skill header for a large file:**
```markdown
## Input
- `knowledgebase/reference-data/large_reference_file.xml` (~20MB)

## Notes
- Uses chunking approach due to large file size
- Elements are cleared after processing to manage memory
```

---

## Rule 7: Generated Outputs Stay in Their Lanes

Never mix human-authored files with generated files:

| Folder | Human-authored? | Generated? | Committed to git? |
|--------|----------------|------------|-------------------|
| `knowledgebase/` | Yes | No | Yes (if not sensitive) |
| `inputs/` | Yes | No | Yes (if not sensitive) |
| `.claude/skills/` | Yes | No | Yes |
| `.claude/agents/` | Yes | No | Yes |
| `research/` | No | Yes | Optional |
| `plans/` | No | Yes | Optional |
| `scripts/` | No | Yes | Optional |
| `output/` | No | Yes | Optional |
| `thoughts/` | No | Yes | No |

**Never put** your reference files in `research/` or `plans/`. Those are for generated outputs only.

**Never put** generated files in `knowledgebase/`. That is for human-provided inputs only.

---

## Rule 8: Document Every File in `prompts.md`

When you place files in `knowledgebase/` or `inputs/`, list every single file in `prompts.md` under the Source Materials section. Agents cannot discover files they don't know about.

```markdown
## Source Materials

### Reference Data (in knowledgebase/reference-data/)
1. `knowledgebase/reference-data/source_model.xlsx` - Source reference model
2. `knowledgebase/reference-data/conversion_rules.yaml` - Transformation rules
3. `knowledgebase/reference-data/type_mappings.yaml` - Type conversions

### Source Documents (in knowledgebase/source-docs/)
1. `knowledgebase/source-docs/project_requirements.md` - Scope and acceptance criteria
2. `knowledgebase/source-docs/legacy_schema.sql` - Existing schema to analyze
```

Do not assume agents will browse directories. Be explicit.

---

## Quick Decision Tree

```
You have a file. Where does it go?

Is it a Claude skill definition (markdown with logic)?
  → .claude/skills/

Is it a Claude agent definition (markdown with workflow)?
  → .claude/agents/

Is it a process rule (how agents should behave during a phase)?
  → .claude/rules/ (with paths: frontmatter for scoping)

Is it a domain rule (source/target technology specifics)?
  → .claude/rules/ (copy the template, customize for your domain)

Is it reference material (standards, rules, conventions)?
  → knowledgebase/

Is it source data to be processed by scripts?
  → inputs/

Is it generated by a skill or agent?
  → research/, plans/, scripts/, or output/ (depending on phase)

Is it a log or progress tracker?
  → thoughts/
```
