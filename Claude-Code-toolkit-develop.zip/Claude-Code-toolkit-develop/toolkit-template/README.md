# Toolkit Template — Claude Code Agent Teams

A generic, reusable project template using Claude Code's **agent teams** pattern. Give this to developers to build solutions for reverse engineering, forward engineering, data modeling, data governance, testing, or any other multi-phase project.

> **New here?** Start with `SETUP_GUIDE.md` — it walks you through everything from install to first run.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          DEVELOPER INPUTS                              │
│                                                                        │
│   prompts.md              knowledgebase/            GUARDRAILS.yaml    │
│   (your requirements)     (reference materials)     (quality rules)    │
└──────────┬──────────────────────┬──────────────────────────┬───────────┘
           │                      │                          │
           ▼                      ▼                          ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        LEAD ORCHESTRATOR                               │
│         Reads prompts.md → Consults experts → Creates tasks            │
└──────────┬──────────────────────────────────────────────────────────────┘
           │
           │ creates tasks with dependencies
           ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        SHARED TASK LIST                                 │
│    TaskCreate / TaskUpdate / TaskList / TaskGet                         │
│    (all agents communicate through here — no direct messaging)         │
└──┬──────────┬──────────────┬──────────────┬──────────────┬─────────────┘
   │          │              │              │              │
   ▼          ▼              ▼              ▼              ▼
┌────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────────────┐
│RESEARCH│ │ PLANNING  │ │  BUILD    │ │  REVIEW   │ │  DOMAIN EXPERTS   │
│  er    │ │ Analyz er │ │  Build er │ │ Review er │ │                   │
│        │ │           │ │           │ │           │ │ Standards Expert   │
│ Writes │ │ Writes    │ │ Writes    │ │ Writes    │ │ Architecture Expert│
│  to:   │ │  to:      │ │  to:      │ │  to:      │ │ Quality Expert    │
│research│ │ plans/    │ │ scripts/  │ │testscripts│ │                   │
│  /     │ │           │ │           │ │  /        │ │ Write to:         │
│        │ │           │ │           │ │           │ │ research/expert/  │
└───┬────┘ └─────┬─────┘ └─────┬─────┘ └─────┬─────┘ └───────────────────┘
    │            │              │              │
    ▼            ▼              ▼              ▼
┌────────┐ ┌─────────┐  ┌───────────┐  ┌───────────┐
│ GATE 1 │ │ GATE 2  │  │  GATE 3   │  │  FINAL    │
│validate│ │validate │  │ validate  │  │ guardrails│
│research│ │ plans   │  │  scripts  │  │  check    │
└────────┘ └─────────┘  └─────┬─────┘  └───────────┘
                               │
                               ▼
                       ┌──────────────┐
                       │   output/    │
                       │  (final      │
                       │ deliverables)│
                       └──────────────┘
```

**Key concepts:**
- **Developer provides** 3 things: `prompts.md` (what to build), `knowledgebase/` (reference materials), and `inputs/` (source data to process)
- **11 agents + 1 soul** work autonomously — 1 lead, 7 teammates (including peer reviewer and devil's advocate), 3 domain experts, plus 1 persona-based soul file
- **4 phases** run sequentially with **quality gates**, **checkpoints**, and **handoffs** between each
- **Agent memory** — every agent has native project memory that persists across sessions
- **Self-review** — every agent runs a self-check before marking tasks complete
- **Escalation protocol** — structured escalation path (L1-L4) when agents get stuck
- **Peer review + devil's advocate** — async code review and assumption-challenging during Phase 2-3
- **Rules** — auto-loaded process and domain rules in `.claude/rules/`
- **Two-layer architecture**: scripts-only mode for quick runs, or agentic mode (validator + refiner) for automated quality loops — run `setup agentic layer` after the pipeline completes. See `SOLUTION_APPROACH.md`
- **Agents never talk directly** — all coordination happens through the shared task list
- **Each agent writes to its own folder** — folder boundaries are enforced by guardrails

---

## How It Works

A **lead agent** breaks the project into tasks. **Teammate agents** claim tasks from a shared task list. **Domain experts** provide specialized guidance on demand. **Phase gates** validate quality between each phase.

```
LEAD ORCHESTRATOR
  |
  |-- Reads prompts.md (your requirements)
  |-- Consults domain experts for guidance
  |-- Creates tasks via TaskCreate
  |-- Sets dependencies via TaskUpdate(addBlockedBy)
  |
  Phase 1: Research (no blockers — runs in parallel)
  |   Researcher claims tasks, writes findings to research/
  |   Can consult Standards Expert or Architecture Expert
  |
  [GATE 1: Validate research completeness]
  |
  Phase 2: Planning (blocked by Gate 1)
  |   Analyzer claims tasks, writes plans to plans/
  |   Can consult Architecture Expert for design decisions
  |   Devil's Advocate challenges the plan (must PASS)
  |
  [GATE 2: Validate plan completeness + DA challenge passed]
  |
  Phase 3: Implementation (blocked by Gate 2)
  |   Builder claims tasks, writes scripts to scripts/
  |   Peer Reviewer reviews each script async (must PASS)
  |   Devil's Advocate challenges each script async (must PASS)
  |   Can consult Quality Expert for testing strategy
  |
  [GATE 3: Validate scripts + all reviews passed]
  |
  Phase 4: Review (blocked by Gate 3)
      Reviewer validates everything, consults experts as needed
      Creates fix tasks if issues found
```

## Quick Start

### 1. Copy the template
Copy this entire `toolkit-template/` folder to a new location for your project.

### 2. Enable agent teams
Add this to your Claude Code settings:
```json
{
  "env": {
    "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"
  }
}
```

### 3. Fill in prompts.md
Edit `prompts.md` with your project's:
- Objective and solution type
- Source materials (reference materials in `knowledgebase/`, source data in `inputs/`)
- Target deliverables
- Technical requirements
- Component structure

### 4. Set up knowledgebase and inputs
- **`knowledgebase/`** — Reference materials (standards, naming conventions, rules, type mappings). Stable across runs.
- **`inputs/`** — Source data the scripts process (Excel models, SQL schemas, CSV data). Changes per project.
- Use `snake_case` names that include the domain: `customer_model.xlsx`, `order_schema.sql`
- List every file in the `## Source Materials` section of `prompts.md` with descriptions

See `SETUP_GUIDE.md` Step 4 for detailed setup instructions.

### 5. Customize experts (optional)
Rename and edit the expert agents in `.claude/agents/expert-*.md` to match your domain:
- `expert-standards.md` — rename to your compliance domain (e.g., HIPAA, Basel III, SOX)
- `expert-architecture.md` — rename to your architecture domain (e.g., cloud, data, microservices)
- `expert-quality.md` — rename to your quality domain (e.g., data quality, QA automation)

### 6. Start the pipeline
Open Claude Code in the project directory and say:
```
start project
```
The lead orchestrator reads your `prompts.md`, consults experts, creates tasks, and the team starts working.

### 7. Set up the agentic layer (optional)
After the pipeline completes and `output/` has been generated, optionally add automated validation and refinement:
```
setup agentic layer
```
This generates `validator.py`, `refiner.py`, and `prompts.py` in `scripts/`, tailored to your project. See `SOLUTION_APPROACH.md` for details.

## Directory Structure

```
your-project/
├── .claude/
│   ├── settings.json              # Agent team config
│   ├── agents/                    # Agent definitions (11 agents + 1 soul)
│   │   ├── lead-orchestrator.md   # Lead — orchestrates everything
│   │   ├── researcher-agent.md    # Teammate — research
│   │   ├── analyzer-agent.md      # Teammate — planning
│   │   ├── builder-agent.md       # Teammate — implementation
│   │   ├── reviewer-agent.md      # Teammate — review
│   │   ├── peer-reviewer-agent.md # Teammate — async script review
│   │   ├── devils-advocate-agent.md # Teammate — challenges plans & scripts
│   │   ├── devils-advocate-soul.md  # [CUSTOMIZE] DA persona & domain checks
│   │   ├── expert-standards.md    # Expert — standards & compliance
│   │   ├── expert-architecture.md # Expert — architecture & design
│   │   ├── expert-quality.md      # Expert — quality & testing
│   │   └── agentic-setup-agent.md # Teammate — agentic layer setup
│   ├── skills/                    # Skills (5 shared)
│   │   ├── manage-tasks.md        # Task coordination patterns
│   │   ├── parse-input.md         # Input parsing patterns
│   │   ├── generate-output.md     # Output generation patterns
│   │   ├── validate-quality.md    # Quality validation patterns
│   │   └── self-review.md         # Self-check before task completion
│   └── rules/                     # Auto-loaded rules
│       └── escalation.md          # Escalation protocol (always loaded)
│                                  # Add domain rules here from guidelines/rules-reference/
├── prompts.md                     # YOUR REQUIREMENTS GO HERE
├── GUARDRAILS.yaml                # Quality rules and boundaries
├── guidelines/                    # Ground rules for the toolkit
│   ├── SKILL_AUTHORING.md         # How to write skills (500-line limit, reference files, etc.)
│   ├── AGENT_AUTHORING.md         # How to write agent definitions
│   ├── KNOWLEDGE_ORGANIZATION.md  # How to organize files in knowledgebase/
│   └── rules-reference/           # Gold standard rules (developer reference, NOT auto-loaded)
│       ├── README.md              # How to use the gold standard files
│       ├── source-teradata-sql.md       # Teradata SQL reverse engineering
│       ├── source-informatica-xml.md    # Informatica XML reverse engineering
│       ├── source-ssis-dtsx.md          # SSIS .dtsx reverse engineering
│       ├── converted-snowflake-sql.md   # Snowflake forward engineering
│       ├── converted-databricks-sql.md  # Databricks forward engineering
│       ├── migration-methodology.md     # 4-level validation, complexity scoring
│       ├── etl-python.md               # Python ETL/orchestration standards
│       └── validation-queries.md        # Validation query templates
├── knowledgebase/                  # Reference materials (standards, rules, conventions)
├── inputs/                        # Source data to process (variable per project)
├── research/                      # Output: researcher writes findings
│   └── expert/                    # Output: expert assessments
├── plans/                         # Output: analyzer writes plans
├── scripts/                       # Output: builder writes scripts
│   ├── base_parser.py             # Abstract base for parsers
│   ├── base_generator.py          # Abstract base for generators
│   ├── base_validator.py          # Abstract base for validators
│   ├── utils.py                   # Shared utilities
│   ├── build_all.py               # Runs all generators
│   ├── prompts.py                 # Centralized prompts for validator/refiner  (generated by "setup agentic layer")
│   ├── validator.py               # Validates output/ vs inputs/              (generated by "setup agentic layer")
│   └── refiner.py                 # Patches output/ based on validation errors (generated by "setup agentic layer")
├── output/                        # Final deliverables
├── guardrails/                    # Quality enforcement scripts
│   └── run_guardrails.py          # Run all checks
├── testscripts/                   # Reviewer's validation scripts
└── thoughts/logs/                 # Progress and logs
```

## The 11 Agents

### Core Teammates (do the work)

| Agent | Role | Owns Folder | What It Does |
|-------|------|-------------|--------------|
| **Lead Orchestrator** | lead | thoughts/ | Reads prompts.md, consults experts, creates tasks with dependencies and phase gates, monitors progress and escalations |
| **Researcher** | teammate | research/ | Analyzes input files in knowledgebase/, writes structured findings |
| **Analyzer** | teammate | plans/ | Synthesizes research into MASTER_PLAN.yaml + component plans |
| **Builder** | teammate | scripts/ | Creates Python scripts that generate deliverables |
| **Reviewer** | teammate | testscripts/ | Validates everything, creates fix tasks for other agents |
| **Peer Reviewer** | teammate | testscripts/ | Reviews individual scripts async during Phase 3, creates fix tasks |
| **Devil's Advocate** | teammate | testscripts/ | Challenges plans (Phase 2) and scripts (Phase 3). FAIL is a hard block. |
| **Agentic Setup** | teammate | scripts/ | Generates validator.py, refiner.py, prompts.py for the agentic layer |

### Domain Experts (consulted on demand)

| Expert | Specialty | Owns Folder | When Consulted |
|--------|-----------|-------------|----------------|
| **Standards Expert** | Compliance, regulations, best practices | research/expert/ | When work must align with external standards |
| **Architecture Expert** | Design patterns, structural decisions | research/expert/ | When there are multiple valid approaches |
| **Quality Expert** | Testing strategy, validation, phase gates | research/expert/ | When defining what "done" means |

## Agent Features

### Agent Memory

Every agent has `memory: project` in its YAML frontmatter, enabling native persistent memory.

**How it works:**
- The platform auto-creates `.claude/agent-memory/{agent-name}/MEMORY.md` per agent when they first run
- First 200 lines of each agent's `MEMORY.md` are injected into their context at startup
- Agents can create additional topic files (e.g., `debugging.md`, `patterns.md`) in their memory directory
- Memory persists across conversations within the same project

**What agents store in memory:**
- Assumptions made during tasks (so future runs don't repeat mistakes)
- Patterns discovered across multiple runs (e.g., "source data always has trailing spaces")
- Lessons learned from escalations or failures
- Confidence notes from self-review (MEDIUM confidence items)

**After the pipeline runs, you'll see:**
```
.claude/agent-memory/
  lead-orchestrator/MEMORY.md
  researcher/MEMORY.md
  analyzer/MEMORY.md
  builder/MEMORY.md
  reviewer/MEMORY.md
  ... (one directory per agent)
```

No pre-creation needed — the platform handles everything. Agents read and write their own memory automatically.

### Devil's Advocate Soul
The devil's advocate agent has a companion persona file (`.claude/agents/devils-advocate-soul.md`) that defines its domain-specific identity, expertise, and verification checks. This is the most important file to customize — it tells the devil's advocate WHAT to be skeptical about in your domain. Includes a commented-out example based on a regulatory banking project.

### Self-Review
Every agent runs the self-review checklist (`.claude/skills/self-review.md`) before marking any task complete. This covers requirements verification, output validation, quality checks, and confidence assessment.

### Escalation Protocol
All agents follow `.claude/rules/escalation.md` when stuck. Four severity levels (L1-L4) with structured escalation paths. The lead orchestrator monitors for escalation tasks and surfaces L4 issues to the user.

### Rules (Auto-Loaded)
`.claude/rules/` contains the escalation protocol (always loaded) and domain rule templates (scoped by file path). Domain templates are customized for your specific source/target technologies.

## Agent Teams Communication

Agents communicate exclusively through the **shared task list**:

- `TaskCreate` — create a new task (starts as `pending`)
- `TaskUpdate` — claim a task (`in_progress`), complete it (`completed`), or add dependencies (`addBlockedBy`)
- `TaskList` — see all tasks and their status
- `TaskGet` — get full details of a specific task

### Key Patterns

**Task dependencies**: The lead creates ALL tasks upfront with dependencies. Teammates poll `TaskList`, claim available (unblocked) tasks, and complete them. When all blockers for a downstream task are completed, it automatically becomes available.

**Expert consultation**: Any agent can create a consultation task prefixed with "Expert consult:". The relevant expert claims it, writes their assessment to `research/expert/`, and completes it. The requesting agent blocks on the consultation and reads the assessment when unblocked.

**Phase gates**: The lead creates GATE tasks between phases. These validate that the previous phase's output meets quality criteria before the next phase can begin. If a gate fails, fix tasks are created — the gate is not marked complete until fixes are done.

See `.claude/skills/manage-tasks.md` for detailed coordination patterns.

## Guidelines — Read Before Customizing

The `guidelines/` folder contains ground rules that every team member must follow. These exist to prevent wasted effort — read them before creating or modifying skills, agents, or knowledgebase files.

| Guideline | What It Covers | Key Rules |
|-----------|---------------|-----------|
| **`SKILL_AUTHORING.md`** | How to write skill files | 500-line hard limit; separate logic from reference content; one skill, one responsibility; reference data goes in `knowledgebase/` not inline |
| **`AGENT_AUTHORING.md`** | How to write agent definitions | Role boundaries, consultation patterns, folder ownership |
| **`KNOWLEDGE_ORGANIZATION.md`** | How to organize input files | Everything goes in `knowledgebase/`; flat structure by default, subdirectories for 10+ files; naming conventions; large file handling |

## Customization Guide

### Renaming expert agents for your domain
Edit the `.claude/agents/expert-*.md` files to match your domain. Examples:
- Banking: "Regulatory Expert" (KYC, AML, Basel III), "Data Architecture Expert"
- Healthcare: "HIPAA Compliance Expert", "Clinical Data Expert"
- Cloud: "Well-Architected Expert", "Security Architecture Expert"

### Adding a new agent
1. Create `.claude/agents/my-agent.md` following the existing agent format
2. Add the agent to `.claude/settings.json` under `agents`
3. Add folder boundaries to `GUARDRAILS.yaml`

### Adding a new expert
1. Create `.claude/agents/expert-myexpert.md` following the expert agent format
2. Add to `.claude/settings.json` with `"role": "expert"`
3. Add `"research/expert/"` to folder boundaries in `GUARDRAILS.yaml`

### Adding a new skill
1. Create `.claude/skills/my-skill.md` with patterns and templates
2. Add the skill to `.claude/settings.json` under `skills`

### Changing the workflow phases
1. Edit the `workflow` section in `.claude/settings.json`
2. Update `phase_dependencies` in `GUARDRAILS.yaml`
3. Update `lead-orchestrator.md` to reflect the new phases and gates

### Adding custom guardrails
1. Create a new `guardrails/my_guard.py` (follow existing pattern)
2. Import and add it to `guardrails/run_guardrails.py`

## Example Use Cases

This template can be used for any solution that follows a research-plan-build-review pattern:

- **Reverse Engineering**: Place schemas/code in knowledgebase/, agents analyze structure and build scripts, scripts process source data from inputs/ to produce documentation
- **Forward Engineering**: Place requirements/specs in knowledgebase/, agents design architecture and build scripts, scripts process inputs/ to generate code
- **Data Modeling**: Place source models in knowledgebase/, agents extract entities and build scripts, scripts process inputs/ to generate target model artifacts
- **Data Governance**: Place policies/metadata in knowledgebase/, agents design governance framework and build scripts, scripts process inputs/ to generate rules/reports
- **Testing**: Place specs/code in knowledgebase/, agents design test strategy and build scripts, scripts process inputs/ to generate test scripts

## Prerequisites

- Python 3.8+
- `pip install pyyaml pandas openpyxl` (install as needed based on your input formats)
