# Setup Guide — Toolkit Template

Step-by-step instructions for setting up the toolkit template for your project.

---

## Prerequisites

Before starting, ensure you have:

- [ ] **Visual Studio Code** installed (see Step 0 below)
- [ ] **Python 3.8+** installed (`python --version` to check)
- [ ] **PyYAML** installed (`pip install pyyaml`)
- [ ] **pandas + openpyxl** installed if working with Excel files (`pip install pandas openpyxl`)

---

## Step 0: Install Visual Studio Code

**Install VS Code** (if not already installed):
Download from https://code.visualstudio.com/download

**Verify the installation:**
- Launch VS Code and confirm it opens successfully

**Recommended VS Code extensions:**
1. Open VS Code
2. Press `Ctrl+Shift+X` to open the Extensions panel
3. Install any extensions required for your project (e.g., Python, YAML, etc.)

**Useful keyboard shortcuts:**

| Action | Shortcut |
|--------|----------|
| Open Extensions panel | `Ctrl+Shift+X` |
| Open integrated terminal | `` Ctrl+` `` |
| Open Settings | `Ctrl+,` |
| Open Command Palette | `Ctrl+Shift+P` |

---

## Step 1: Copy the Template

Copy the entire `toolkit-template/` folder to a new directory for your project.

```bash
cp -r toolkit-template/ my-project/
cd my-project/
```

Rename the folder to match your solution name (e.g., `reverse-engineering-solution/`, `data-governance-toolkit/`, etc.).

---

## Step 2: Enable Agent Teams

Agent teams is an experimental feature in Claude Code. Enable it by adding the following to your Claude Code settings.

**Option A — Project-level** (recommended): Create or edit `.claude/settings.local.json` in your project:

```json
{
  "env": {
    "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"
  }
}
```

**Option B — Global**: Add to your global Claude Code settings at `~/.claude/settings.json`:

```json
{
  "env": {
    "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"
  }
}
```

---

## Step 3: Fill in prompts.md

Open `prompts.md` and replace every placeholder with your project details. Follow the `PROMPT_TEMPLATE.md` guide for writing grounded, hallucination-free prompts.

**Sections to fill in:**

| Section | What to Write |
|---------|--------------|
| **Objective** | What your solution does, in one clear sentence |
| **Solution Type** | Check the box (reverse engineering, forward engineering, etc.) |
| **Source Materials** | List every file you'll place in `knowledgebase/`, with descriptions |
| **Target Deliverables** | List every output you expect in `output/` |
| **Technical Requirements** | Platform, naming conventions, standards |
| **Component Structure** | How the solution is organized (modules/domains) |
| **Quality Requirements** | What standards outputs must meet |
| **Success Criteria** | How to verify the project is complete |

---

## Step 4: Set Up the Knowledgebase and Inputs

The toolkit uses two input folders with distinct purposes:

| Folder | Used By | Purpose | Examples |
|--------|---------|---------|---------|
| `knowledgebase/` | **Agent team** during pipeline + **scripts** at runtime | Reference materials the agents analyze to build the solution, and rules scripts apply at runtime | Standards, naming conventions, type mappings, source schemas, example models, best practices |
| `inputs/` | **Generated scripts** at runtime only | Source data that scripts process to produce deliverables | Production data files, actual datasets to transform |

**Key distinction:** The agent team (Research → Plan → Build → Review) works exclusively with `knowledgebase/`. The `inputs/` folder only comes into play when you execute the generated scripts against actual source data.

### 4a. Organize Your Knowledgebase Files

Place all materials the agent team needs in `knowledgebase/`. For most projects, a **flat structure** works well:

```
knowledgebase/
├── customer_model.xlsx
├── order_schema.sql
├── api_spec.json
├── compliance_rules.yaml
├── legacy_code.py
├── reference_doc.txt
└── ...
```

For larger projects with **10+ files**, you may optionally organize into subdirectories:

```
knowledgebase/
├── reference-data/
│   ├── source_model.xlsx
│   └── conversion_rules.yaml
├── source-docs/
│   ├── requirements.md
│   └── legacy_schema.sql
└── standards/
    └── naming_conventions.yaml
```

See `guidelines/KNOWLEDGE_ORGANIZATION.md` Rule 5 for subdirectory guidance.

### 4b. File Naming Conventions

Use **descriptive, domain-aware filenames** so agents can understand what each file covers:

| Pattern | Example | Why It Helps |
|---------|---------|-------------|
| `{domain}_{type}.{ext}` | `customer_model.xlsx` | Agent knows this covers the customer domain |
| `{domain}_{type}.{ext}` | `order_schema.sql` | Agent knows this is an order schema definition |
| `{system}_{artifact}.{ext}` | `legacy_erp_tables.csv` | Agent knows the source system |
| `{standard}_{rules}.{ext}` | `hipaa_compliance.yaml` | Agent knows this contains compliance rules |

**Naming rules:**
- Use `snake_case` for all filenames
- Include the domain or subject area in the filename
- Include the file type/purpose (model, schema, spec, rules, config, etc.)
- Avoid generic names like `data.xlsx`, `input.csv`, or `file1.json`

### 4c. Supported Formats

| Format | Extensions | Best For |
|--------|-----------|----------|
| **Excel** | `.xlsx`, `.xls` | Data models, entity definitions, mapping tables, inventories |
| **CSV** | `.csv` | Flat data, lookup tables, simple lists |
| **SQL** | `.sql` | Schema definitions, DDL, stored procedures, queries |
| **JSON** | `.json` | API specs, config files, structured metadata |
| **XML** | `.xml` | Legacy configs, data exchange formats, WSDL/XSD |
| **YAML** | `.yaml`, `.yml` | Rules, configs, structured documentation |
| **Plain text** | `.txt`, `.md` | Requirements docs, specifications, notes |
| **Code files** | `.py`, `.java`, `.js`, etc. | Source code for reverse engineering |

The researcher agent auto-detects formats and creates parser subclasses based on what it finds. You don't need to configure parsers manually.

### 4d. Register Files in prompts.md

Every file in `knowledgebase/` **must** be listed in the `## Source Materials` section of `prompts.md` with a description. This is critical for preventing hallucination.

```markdown
## Source Materials
- `knowledgebase/customer_model.xlsx` - Entity definitions for the customer domain
  (Sheet "Entities" columns A-H, Sheet "Relationships" columns A-D)
- `knowledgebase/order_schema.sql` - Current production schema for order processing
- `knowledgebase/api_spec.json` - REST API specification for the payments service
```

**Why this matters:** Agents use this manifest to understand what files exist and what they contain. Without descriptions, agents may misinterpret file contents or skip files entirely.

### 4e. Handling Multiple Sources

When you have overlapping or related files:

1. **State priority order** in prompts.md: "If `customer_model.xlsx` and `legacy_erp_tables.csv` conflict, prefer `customer_model.xlsx`"
2. **Separate by domain**, not by format: Don't put all Excel files together. Name them by what they cover.
3. **Document relationships**: "The entities in `customer_model.xlsx` map to the tables in `order_schema.sql` via the CUSTOMER_ID column"

### 4f. What NOT to Put in Knowledgebase

- **Generated output** — that goes in `output/`
- **Agent research findings** — that goes in `research/`
- **Plans** — that goes in `plans/`
- **Credentials or secrets** — never place `.env`, API keys, or passwords here
- **Binary files** (images, compiled code) — agents cannot parse these

### 4g. Knowledgebase by Use Case

What you place in `knowledgebase/` depends on the type of solution you're building. Use the guide below for your solution type.

---

#### Reverse Engineering

**Goal:** Extract structure, logic, and documentation from existing systems.

| What to Place | Example Files | What Agents Extract |
|---------------|---------------|---------------------|
| Existing database schemas | `legacy_schema.sql`, `prod_ddl.sql` | Tables, columns, data types, constraints, relationships |
| Source code | `app_logic.py`, `stored_procs.sql`, `etl_jobs.py` | Business rules, transformation logic, dependencies |
| Exported metadata | `table_inventory.csv`, `column_metadata.xlsx` | Entity catalogs, attribute lists, data lineage |
| Config files | `db_config.xml`, `connection_settings.json` | System topology, environment mappings |
| API definitions | `api_swagger.json`, `wsdl_service.xml` | Endpoints, data contracts, integration points |
| Documentation (if available) | `system_overview.txt`, `architecture_notes.md` | Context, intent, historical decisions |

```
knowledgebase/
├── legacy_oracle_schema.sql        # Production DDL export
├── etl_transformations.py          # ETL pipeline source code
├── table_column_inventory.xlsx     # Metadata export from catalog tool
├── api_contracts.json              # REST API swagger definitions
└── system_architecture_notes.md    # Existing documentation
```

**prompts.md example:**
```markdown
## Source Materials
- `knowledgebase/legacy_oracle_schema.sql` - Full DDL export from Oracle production (240 tables)
- `knowledgebase/etl_transformations.py` - Python ETL scripts with business rule logic
- `knowledgebase/table_column_inventory.xlsx` - Sheet "Tables" (A-D), Sheet "Columns" (A-H)
- Do not infer tables or columns not found in these source files.
```

---

#### Forward Engineering

**Goal:** Build new systems from requirements and specifications.

| What to Place | Example Files | What Agents Extract |
|---------------|---------------|---------------------|
| Requirements documents | `business_requirements.md`, `user_stories.yaml` | Functional requirements, acceptance criteria |
| Technical specifications | `tech_spec.json`, `architecture_design.yaml` | System design, component structure, interfaces |
| Standards / templates | `coding_standards.md`, `naming_conventions.yaml` | Rules to follow during generation |
| Reference implementations | `reference_module.py`, `sample_api.json` | Patterns to replicate |
| Target platform docs | `snowflake_best_practices.md`, `aws_guidelines.yaml` | Platform-specific constraints |
| Data contracts / schemas | `input_schema.json`, `output_contract.yaml` | Expected inputs and outputs |

```
knowledgebase/
├── business_requirements.md        # What the system must do
├── technical_spec.yaml             # Architecture and component design
├── naming_conventions.yaml         # Naming rules for all generated code
├── reference_api_module.py         # Example module to follow as pattern
├── target_platform_guidelines.md   # Platform-specific rules
└── input_output_contracts.json     # Data contracts
```

**prompts.md example:**
```markdown
## Source Materials
- `knowledgebase/business_requirements.md` - 42 user stories with acceptance criteria
- `knowledgebase/technical_spec.yaml` - Component architecture with 6 modules
- `knowledgebase/naming_conventions.yaml` - All naming rules for code generation
- Only generate components defined in the technical spec. Do not add extra modules.
```

---

#### Data Modeling

**Goal:** Design or transform data models (conceptual, logical, physical).

| What to Place | Example Files | What Agents Extract |
|---------------|---------------|---------------------|
| Source data models | `source_model.xlsx`, `conceptual_erd.xml` | Entities, attributes, relationships |
| Existing schemas | `current_schema.sql`, `legacy_ddl.sql` | Table structures, keys, constraints |
| Mapping documents | `source_to_target_mapping.xlsx` | Transformation rules, field mappings |
| Business glossary | `business_glossary.yaml`, `term_definitions.csv` | Standardized names and definitions |
| Data samples | `sample_data.csv`, `test_records.json` | Data patterns, value ranges, formats |
| Standards | `data_modeling_standards.md`, `type_mappings.yaml` | Modeling rules, type conventions |

```
knowledgebase/
├── source_entity_model.xlsx        # Source entities and attributes
├── current_production_ddl.sql      # Existing physical schema
├── source_target_mapping.xlsx      # Field-level mappings
├── business_glossary.yaml          # Approved business terms
├── data_type_standards.yaml        # Type mapping rules (Oracle → Snowflake, etc.)
└── sample_customer_data.csv        # Representative data samples
```

**prompts.md example:**
```markdown
## Source Materials
- `knowledgebase/source_entity_model.xlsx` - Sheet "Entities" (A-F): entity definitions,
  Sheet "Attributes" (A-J): column details with types and nullability
- `knowledgebase/source_target_mapping.xlsx` - Sheet "Mappings" (A-H): source-to-target field map
- `knowledgebase/data_type_standards.yaml` - Type conversion rules from Oracle to Snowflake
- If an attribute has no data type in the source, use VARCHAR(255) and flag as "TYPE_NEEDS_REVIEW"
```

---

#### Data Governance

**Goal:** Catalog data assets, define policies, enforce quality rules.

| What to Place | Example Files | What Agents Extract |
|---------------|---------------|---------------------|
| Data catalogs / inventories | `data_catalog.xlsx`, `asset_inventory.csv` | Data assets, owners, classifications |
| Policy documents | `data_policies.md`, `retention_rules.yaml` | Governance policies, retention periods |
| Compliance requirements | `gdpr_requirements.yaml`, `hipaa_rules.md` | Regulatory constraints |
| Data quality rules | `quality_rules.xlsx`, `validation_thresholds.yaml` | Quality dimensions, thresholds |
| Metadata exports | `column_metadata.csv`, `lineage_export.json` | Metadata, lineage, dependencies |
| Classification schemas | `sensitivity_levels.yaml`, `data_domains.yaml` | Classification taxonomies |

```
knowledgebase/
├── enterprise_data_catalog.xlsx    # All data assets with owners and domains
├── data_governance_policies.md     # Governance policies and procedures
├── gdpr_compliance_rules.yaml     # GDPR-specific requirements
├── data_quality_rules.xlsx         # Quality rules per domain
├── column_sensitivity_tags.csv     # PII/sensitivity classifications
└── data_domain_taxonomy.yaml       # Domain and subdomain structure
```

**prompts.md example:**
```markdown
## Source Materials
- `knowledgebase/enterprise_data_catalog.xlsx` - Sheet "Assets" (A-L): 500+ data assets
  with owner, domain, sensitivity, and retention columns
- `knowledgebase/gdpr_compliance_rules.yaml` - 28 GDPR rules mapped to data categories
- `knowledgebase/data_quality_rules.xlsx` - Sheet "Rules" (A-G): quality checks per domain
- Only create governance artifacts for assets listed in the catalog. Do not invent assets.
```

---

#### Testing / Validation

**Goal:** Generate test cases, validation scripts, and quality checks.

| What to Place | Example Files | What Agents Extract |
|---------------|---------------|---------------------|
| Specifications to test against | `functional_spec.md`, `api_spec.json` | Expected behaviors, endpoints, rules |
| Source code under test | `app_module.py`, `service_handler.js` | Functions, classes, branches to cover |
| Existing test cases (if any) | `current_tests.py`, `test_scenarios.xlsx` | Coverage gaps, patterns to follow |
| Test data | `test_data_samples.csv`, `mock_responses.json` | Input data, expected outputs |
| Business rules | `business_rules.yaml`, `validation_logic.md` | Rules that must be validated |
| Bug reports / known issues | `known_bugs.yaml`, `defect_log.csv` | Regression scenarios |

```
knowledgebase/
├── functional_specification.md     # What the system should do
├── api_endpoints.json              # API contract to test against
├── source_code_module.py           # Code under test
├── existing_test_suite.py          # Current tests (to find gaps)
├── business_validation_rules.yaml  # Business rules needing test coverage
├── test_data_samples.csv           # Sample input/output pairs
└── known_defects.yaml              # Known bugs for regression tests
```

**prompts.md example:**
```markdown
## Source Materials
- `knowledgebase/functional_specification.md` - 35 functional requirements with acceptance criteria
- `knowledgebase/api_endpoints.json` - 12 REST endpoints with request/response schemas
- `knowledgebase/source_code_module.py` - Main application module (18 functions)
- `knowledgebase/business_validation_rules.yaml` - 50 business rules to validate
- Generate test cases for every requirement in the spec. Flag requirements with no testable criteria.
```

---

### 4h. Verify Your Knowledgebase

After placing files, run this quick check:

```bash
# List all files in knowledgebase
ls -la knowledgebase/

# Verify file count matches what's listed in prompts.md
echo "Files in knowledgebase:" && ls knowledgebase/ | wc -l
```

Then confirm:
- [ ] Every file in `knowledgebase/` is listed in the `## Source Materials` section of `prompts.md`
- [ ] Every file listed in `prompts.md` actually exists in `knowledgebase/`
- [ ] Each file has a clear, descriptive filename
- [ ] Each file has a description in `prompts.md` explaining what it contains
- [ ] No placeholder or empty files (remove `.gitkeep` after adding real files)

### 4i. Set Up the Inputs Folder (for Script Execution)

The `inputs/` folder is used **only at script execution time** — the agent team does not access it. Place the actual source data files here that your generated scripts will process.

```
inputs/
├── production_data.xlsx          # Actual data to transform
├── customer_records.csv          # Records to process
├── transaction_log.sql           # Data to migrate
└── ...
```

**When to populate `inputs/`:**
- After the agent team has generated the scripts (Phase 3 complete)
- Before running `python scripts/build_all.py`

**What goes in `inputs/` vs `knowledgebase/`:**
- If the agent team needs it to **understand the problem and build scripts** → `knowledgebase/`
- If the scripts need it as **actual data to process at runtime** → `inputs/`

---

## Step 5: Customize the Devil's Advocate Soul (Important)

The devil's advocate agent has a companion persona file (`.claude/agents/devils-advocate-soul.md`) that defines its **domain-specific identity, expertise, and verification checks**. This is what makes the devil's advocate effective for YOUR domain — without it, the agent knows HOW to review but not WHAT matters.

**Edit `.claude/agents/devils-advocate-soul.md`** and fill in the `[CUSTOMIZE]` sections:

| Section | What to Fill In | Example (Regulatory Banking) |
|---------|----------------|------------------------------|
| Identity | Your team/project name | "BIAN Data Products Regulatory Deep-Dive" |
| Domain Expertise | Specific knowledge areas | "MDRM code catalogs", "FIBO ontology hierarchy" |
| Core Philosophy | Non-negotiable principles | "Every MDRM code needs verification against FFIEC dictionary" |
| Verification Checks | Domain-specific checks | "Verify FIBO mappings are semantically correct" |
| Behavioral Rules | Domain-specific rejection criteria | "REJECT if no backing_material provided" |

The file includes a commented-out example based on a regulatory banking project. Delete the example section after you've customized the template above it.

---

## Step 5a: Customize Rules (Important)

Domain rules are **deep reference documents** (150-350 lines each) that teach agents about your specific technologies. They are loaded contextually via `paths:` frontmatter — only when agents work with matching files — which prevents context token waste.

### Gold Standard Reference: Legacy Data Stack Modernization

The toolkit ships with 8 **gold standard rule files** in `guidelines/rules-reference/`. These are production-quality reference documents for the "Legacy Data Stack Modernization" archetype (Teradata/Informatica/SSIS → Snowflake/Databricks).

> **These are NOT active rules.** Files in `guidelines/rules-reference/` are for developers to study. Only files copied to `.claude/rules/` are auto-loaded by Claude.

See `guidelines/rules-reference/README.md` for the full file list with descriptions.

**If your project is a legacy data stack modernization**, copy the relevant files to `.claude/rules/` to activate them:

```bash
# Copy only the rules that apply to your source/target technologies
cp guidelines/rules-reference/source-teradata-sql.md .claude/rules/
cp guidelines/rules-reference/converted-snowflake-sql.md .claude/rules/
cp guidelines/rules-reference/migration-methodology.md .claude/rules/
# ... see guidelines/rules-reference/README.md for full list
```

After copying, review the `paths:` frontmatter in each file and adjust to match your project's directory structure.

### Creating Rules for a New Archetype

If your project is a DIFFERENT archetype (e.g., data modeling, API modernization, cloud-native development):

1. **Study the gold standard files** in `guidelines/rules-reference/` — read `source-teradata-sql.md` (~243 lines) and `converted-snowflake-sql.md` (~319 lines) to understand the depth and structure expected
2. **Create your own rule files** in `.claude/rules/` following the same pattern:
   - `source-{your-tech}.md` for source technology rules
   - `converted-{your-platform}.md` for target platform rules
3. **Add `paths:` frontmatter** to scope to your file patterns
4. **Aim for 150-350 lines** per rule file — these are deep reference documents, not checklists
5. **Add cross-cutting rules** if needed (e.g., methodology, validation queries)

---

## Step 5b: Customize Expert Agents (Optional)

The template includes 3 generic expert agents. Rename and customize them for your domain.

**Files to edit** (in `.claude/agents/`):

| File | Rename To | Example |
|------|-----------|---------|
| `expert-standards.md` | Your compliance domain | "HIPAA Expert", "Basel III Expert", "SOX Expert" |
| `expert-architecture.md` | Your architecture domain | "Cloud Architecture Expert", "Data Mesh Expert" |
| `expert-quality.md` | Your quality domain | "Data Quality Expert", "Test Automation Expert" |

**What to customize inside each file:**
- The `## Role` section — describe the expert's specific domain knowledge
- The `## When You Are Consulted` section — list the specific questions this expert answers
- The `## Customization Note` at the bottom — remove it after customizing

**Also update** `.claude/settings.json`:
- Change the agent `description` and `triggers` to match the new expert names

---

## Step 6: Customize GUARDRAILS.yaml (Optional)

Edit `GUARDRAILS.yaml` to match your project's quality standards.

**Pipeline sections to customize:**

```yaml
project:
  name: "Your Project Name"    # <-- change this

content_standards:
  naming_conventions:
    file_naming: "snake_case"  # <-- change if needed
    # Add your own rules here

  required_yaml_fields:
    research_output:            # <-- fields required in research YAML
      - "metadata"
      - "summary"
      - "findings"
    plan_output:                # <-- fields required in plan YAML
      - "objective"
      - "components"
      - "decisions"

size_limits:
  max_file_size_kb: 500        # <-- adjust per your needs
  max_output_files: 100
```

**Agentic layer sections to customize (if using agentic mode):**

```yaml
refiner_constraints:
  diff_size_cap:
    max_lines_per_fix: 50      # <-- max lines a single output patch can change

loop_constraints:
  max_iterations:
    default: 3                 # <-- max refinement iterations before human review
  iteration_timeout:
    timeout_minutes: 10        # <-- max time per iteration

feedback_validation:           # <-- rules for validating human feedback
  relevance_check: ...         #     before the refiner accepts it
  actionability_check: ...
  source_consistency_check: ...

validation_report_integrity:   # <-- rules for validator output quality
  source_traceability: ...
  no_hallucinated_issues: ...
  accuracy_metric_consistency: ...
```

See `SOLUTION_APPROACH.md` for full details on the agentic layer (validator, refiner, feedback validation, refinement loop).

---

## Step 7: Verify the Setup

Run these checks to confirm everything is in place.

**Check 1 — Directory structure:**
```bash
ls -la knowledgebase/   # Should contain your reference materials
ls -la inputs/          # Should exist (populate before running scripts)
ls -la .claude/agents/  # Should show 12 .md files (11 agents + 1 soul)
ls -la .claude/skills/  # Should show 5 .md files
ls -la .claude/rules/   # Should show escalation.md (+ any domain rules you added)
ls -la scripts/         # Should show base_*.py, utils.py, build_all.py
```

**Check 2 — Config files are valid:**
```bash
python -c "import json; json.load(open('.claude/settings.json')); print('settings.json: OK')"
python -c "import yaml; yaml.safe_load(open('GUARDRAILS.yaml')); print('GUARDRAILS.yaml: OK')"
```

**Check 3 — Python scripts import correctly:**
```bash
cd scripts && python -c "from base_parser import BaseParser; from base_generator import BaseGenerator; print('Python imports: OK')" && cd ..
```

**Check 4 — prompts.md is filled in:**
```bash
python guardrails/input_guard.py
```
This will flag any missing sections or unfilled placeholders.

---

## Step 8: Start the Agent Team

Open Claude Code in your project directory and run:

```
start project
```

The lead orchestrator will:
1. Read your `prompts.md`
2. Consult domain experts for guidance
3. Create tasks with dependencies for all 4 phases
4. Insert phase-gate validation tasks between phases
5. Teammates start claiming and completing tasks

**Monitor progress** by asking:
```
show task list
```

### Agent Memory (Automatic)

Every agent has `memory: project` in its frontmatter. You do NOT need to create any memory files — the platform handles everything automatically.

**What happens at runtime:**
- When an agent runs for the first time, the platform auto-creates `.claude/agent-memory/{agent-name}/MEMORY.md`
- First 200 lines of each `MEMORY.md` are loaded into the agent's context at every startup
- Agents write to their own memory: assumptions, patterns, lessons learned, confidence notes
- If `MEMORY.md` grows beyond 200 lines, agents move detailed notes to separate topic files (e.g., `patterns.md`, `debugging.md`)

**After the pipeline runs, you'll see:**
```
.claude/agent-memory/
  lead-orchestrator/MEMORY.md   ← task coordination patterns, escalation history
  researcher/MEMORY.md          ← source data quirks, gap patterns
  analyzer/MEMORY.md            ← planning decisions, conflict resolutions
  builder/MEMORY.md             ← code patterns, fix history
  reviewer/MEMORY.md            ← common issues found across reviews
  devils-advocate/MEMORY.md     ← challenge patterns, recurring weak spots
  ...
```

**Why this matters:** On subsequent runs with the same project, agents start with context from prior work. The researcher already knows about source data quirks, the builder remembers what patterns worked, and the devil's advocate knows which areas had issues before.

**Memory scope options** (set in agent frontmatter):

| Scope | Location | Use When |
|-------|----------|----------|
| `memory: project` (current) | `.claude/agent-memory/{name}/` in project | Knowledge is specific to this codebase |
| `memory: user` | `~/.claude/agent-memory/{name}/` in home dir | Knowledge applies across all projects |
| `memory: local` | `.claude/agent-memory-local/{name}/` (git-ignored) | Knowledge shouldn't be committed to version control |

The toolkit uses `project` scope so agent memory is committed with the project and shared across the team.

---

## Step 9: Set Up the Agentic Layer (Optional)

After the pipeline completes and `output/` has been generated, you can optionally add the agentic validation and refinement layer.

Open Claude Code in your project directory and run:

```
setup agentic layer
```

This generates three project-specific scripts in `scripts/`:

| Script | Purpose |
|--------|---------|
| `scripts/prompts.py` | All prompts used by the validator and refiner, tailored to your project |
| `scripts/validator.py` | Compares `output/` against `inputs/` and `knowledgebase/`, produces a validation report |
| `scripts/refiner.py` | Patches `output/` files based on validation errors and human feedback |

**How to use the agentic layer after setup:**

```bash
# Run validation on current output
python scripts/validator.py

# Run the refinement loop (validation errors only)
python scripts/refiner.py

# Run with human feedback
python scripts/refiner.py --feedback feedback.txt
```

See `SOLUTION_APPROACH.md` for the full agentic architecture (refinement loop, feedback validation, guardrails).

---

## Project Workflow Overview

Once started, the agent team follows this pipeline:

```
[Expert Consultations]
        |
  Phase 1: Research
  Researcher analyzes files in knowledgebase/
  Writes findings to research/
        |
  [GATE 1: Validate research]
        |
  Phase 2: Planning
  Analyzer synthesizes research into plans
  Writes to plans/MASTER_PLAN.yaml + component plans
        |
  [GATE 2: Validate plans]
        |
  Phase 3: Implementation
  Builder creates Python scripts in scripts/
  Scripts read from inputs/ + knowledgebase/, write to output/
        |
  [GATE 3: Validate scripts and outputs]
        |
  Phase 4: Review
  Reviewer validates everything
  Creates fix tasks if needed
        |
  [Final guardrails check]
        |
  Done — deliverables in output/
```

---

## Folder Reference

| Folder | Purpose | Who Writes Here |
|--------|---------|-----------------|
| `knowledgebase/` | Reference materials (standards, rules, conventions) | Developer (you) |
| `inputs/` | Source data to process (models, schemas, data files) | Developer (you) |
| `research/` | Analysis findings | Researcher agent |
| `research/expert/` | Expert assessments | Expert agents |
| `plans/` | MASTER_PLAN.yaml + component plans | Analyzer agent |
| `scripts/` | Python scripts + agentic scripts | Builder agent; Agentic setup agent |
| `output/` | Final deliverables | Generated by scripts; patched by refiner in agentic mode |
| `testscripts/` | Validation scripts | Reviewer agent |
| `thoughts/logs/` | Progress logs | All agents |
| `guardrails/` | Quality enforcement scripts | Pre-built (you customize) |

---

## Troubleshooting

**Agent teams not working:**
- Verify `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS` is set to `"1"` in settings
- Restart Claude Code after changing settings

**Agents writing to wrong folders:**
- Check `folder_boundaries` in both `.claude/settings.json` and `GUARDRAILS.yaml`
- Run `python guardrails/folder_guard.py` to validate

**Phase 2 not starting:**
- Phase gates must pass before the next phase begins
- Run `python guardrails/phase_guard.py` to see which prerequisites are missing
- Check that research/ contains actual YAML files (not just .gitkeep)

**Agents producing fabricated data:**
- Review `PROMPT_TEMPLATE.md` and tighten your prompts.md
- Ensure all source files are in `knowledgebase/` — agents can't cite what doesn't exist
- Add explicit boundaries: "Do not include items not found in the source"

**Scripts failing to run:**
- Check Python dependencies: `pip install pyyaml pandas openpyxl`
- Run individual scripts to isolate: `python scripts/generate_X.py`
- Check `thoughts/logs/` for error details

**Need to restart from a specific phase:**
- Update `plans/MASTER_PLAN.yaml` phase statuses
- Tell the lead orchestrator: "resume from phase 3"

---

## Team Checklist

Use this checklist when handing the project to a new team member:

- [ ] Cloned/copied the toolkit template
- [ ] Agent teams feature enabled in Claude Code settings
- [ ] `prompts.md` filled in completely (no placeholders remaining)
- [ ] Reference materials placed in `knowledgebase/`
- [ ] Source data placed in `inputs/` (needed before running generated scripts, not before pipeline)
- [ ] Expert agents renamed for the domain (if applicable)
- [ ] Devil's advocate soul customized (`.claude/agents/devils-advocate-soul.md`) with domain-specific checks
- [ ] Domain rules customized (`.claude/rules/source-*.md` and `target-*.md`)
- [ ] `GUARDRAILS.yaml` project name updated
- [ ] 12 files present in `.claude/agents/` (11 agents + 1 soul, all with `memory: project` frontmatter)
- [ ] Escalation rule present in `.claude/rules/escalation.md`
- [ ] Domain rules added to `.claude/rules/` from `guidelines/rules-reference/` (if applicable)
- [ ] 8 gold standard reference files in `guidelines/rules-reference/`
- [ ] Setup verification checks all pass (Step 7)
- [ ] Reviewed `PROMPT_TEMPLATE.md` for writing grounded prompts
- [ ] Reviewed `README.md` for understanding the agent team workflow
- [ ] (Optional) Ran `setup agentic layer` to generate validator/refiner scripts
