"""
Guardrails Package - Safety and quality enforcement scripts.

This package contains:
- logger.py        : Centralized logging for guardrail checks
- input_guard.py   : Validates prompts.md has required sections
- folder_guard.py  : Enforces agent-to-folder boundaries
- phase_guard.py   : Checks phase prerequisites
- content_guard.py : Validates content standards
- run_guardrails.py: Master runner for all guards
"""
