"""
Phase Guard - Enforces phase dependency rules.

Checks that prerequisites for each phase are met before
allowing that phase to proceed. Uses completion markers
defined in GUARDRAILS.yaml.
"""

import sys
from pathlib import Path

from logger import setup_guard_logger, get_project_root, load_guardrails_config


def check_phase_prerequisites(project_root: Path) -> list:
    """Check that phase prerequisites are satisfied."""
    issues = []
    config = load_guardrails_config()
    phase_deps = config.get('phase_dependencies', {})

    if not phase_deps:
        issues.append({
            'severity': 'WARNING',
            'file': 'GUARDRAILS.yaml',
            'message': 'No phase_dependencies defined',
            'suggestion': 'Define phase_dependencies in GUARDRAILS.yaml'
        })
        return issues

    # Determine which phases are complete (have their completion marker)
    completed_phases = set()
    for phase_name, phase_config in phase_deps.items():
        marker = phase_config.get('completion_marker', '')
        marker_path = project_root / marker
        if marker_path.exists():
            # For directories, check if non-empty (excluding .gitkeep)
            if marker_path.is_dir():
                real_files = [
                    f for f in marker_path.iterdir()
                    if f.name != '.gitkeep'
                ]
                if real_files:
                    completed_phases.add(phase_name)
            else:
                completed_phases.add(phase_name)

    # Check each phase's prerequisites
    for phase_name, phase_config in phase_deps.items():
        prerequisites = phase_config.get('prerequisites', [])
        for prereq in prerequisites:
            if prereq not in completed_phases:
                issues.append({
                    'severity': 'INFO',
                    'file': phase_config.get('completion_marker', ''),
                    'message': (
                        f'Phase "{phase_name}" prerequisite not met: '
                        f'"{prereq}" is not yet complete'
                    ),
                    'suggestion': f'Complete {prereq} before starting {phase_name}'
                })

    return issues


def get_current_phase(project_root: Path) -> str:
    """Determine the current phase based on completion markers."""
    config = load_guardrails_config()
    phase_deps = config.get('phase_dependencies', {})

    current_phase = "not_started"
    for phase_name, phase_config in phase_deps.items():
        marker = phase_config.get('completion_marker', '')
        marker_path = project_root / marker
        if marker_path.exists():
            if marker_path.is_dir():
                real_files = [f for f in marker_path.iterdir() if f.name != '.gitkeep']
                if real_files:
                    current_phase = phase_name
            else:
                current_phase = phase_name

    return current_phase


def main():
    """Run phase guard validation."""
    logger = setup_guard_logger('phase_guard')
    root = get_project_root()

    logger.info("Validating phase dependencies...")
    current = get_current_phase(root)
    logger.info(f"Current phase: {current}")

    issues = check_phase_prerequisites(root)

    errors = [i for i in issues if i['severity'] == 'ERROR']
    infos = [i for i in issues if i['severity'] == 'INFO']

    for issue in errors:
        logger.error(issue['message'])
    for issue in infos:
        logger.info(issue['message'])

    if errors:
        logger.error(f"Phase guard FAILED: {len(errors)} error(s)")
        return False
    else:
        logger.info(f"Phase guard PASSED ({len(infos)} pending prerequisites)")
        return True


if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
