"""
Master Guardrails Runner - Executes all guardrail checks.

Runs all guard scripts in sequence and produces a combined report.

Usage:
    python guardrails/run_guardrails.py
"""

import sys
from pathlib import Path
from datetime import datetime

# Ensure guardrails/ is on the Python path
GUARDRAILS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(GUARDRAILS_DIR))

from logger import setup_guard_logger, get_project_root

# Import individual guards
import input_guard
import folder_guard
import phase_guard
import content_guard


def main():
    """Run all guardrail checks and report results."""
    logger = setup_guard_logger('run_guardrails')
    logger.info("=" * 60)
    logger.info("Guardrails Validation - Starting")
    logger.info(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info("=" * 60)

    guards = [
        ('Input Guard', input_guard.main),
        ('Folder Guard', folder_guard.main),
        ('Phase Guard', phase_guard.main),
        ('Content Guard', content_guard.main),
    ]

    results = {}
    for name, guard_fn in guards:
        logger.info(f"\n--- {name} ---")
        try:
            passed = guard_fn()
            results[name] = 'PASSED' if passed else 'FAILED'
        except Exception as e:
            logger.error(f"{name} raised exception: {e}")
            results[name] = 'ERROR'

    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("Guardrails Summary")
    logger.info("=" * 60)

    all_passed = True
    for name, status in results.items():
        icon = "PASS" if status == 'PASSED' else "FAIL"
        logger.info(f"  [{icon}] {name}: {status}")
        if status != 'PASSED':
            all_passed = False

    if all_passed:
        logger.info("\nAll guardrails PASSED")
    else:
        logger.warning("\nSome guardrails FAILED - review issues above")

    return all_passed


if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
