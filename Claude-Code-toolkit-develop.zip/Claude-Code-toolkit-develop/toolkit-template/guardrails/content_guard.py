"""
Content Guard - Validates content standards.

Checks naming conventions, required fields in YAML files,
and script quality standards as defined in GUARDRAILS.yaml.
"""

import re
import sys
from pathlib import Path

import yaml

from logger import setup_guard_logger, get_project_root, load_guardrails_config


def check_yaml_files(directory: Path, required_fields: list) -> list:
    """Validate all YAML files in a directory have required fields."""
    issues = []
    if not directory.exists():
        return issues

    for yaml_file in directory.glob('*.yaml'):
        try:
            with open(yaml_file, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
        except yaml.YAMLError as e:
            issues.append({
                'severity': 'ERROR',
                'file': str(yaml_file),
                'message': f'Invalid YAML: {e}',
                'suggestion': 'Fix YAML syntax errors'
            })
            continue

        if data is None:
            issues.append({
                'severity': 'WARNING',
                'file': str(yaml_file),
                'message': 'YAML file is empty',
                'suggestion': 'Populate with content or remove'
            })
            continue

        # Check required fields (look in top-level and one level deep)
        flat_keys = set()
        if isinstance(data, dict):
            flat_keys.update(data.keys())
            for v in data.values():
                if isinstance(v, dict):
                    flat_keys.update(v.keys())

        for field in required_fields:
            if field not in flat_keys:
                issues.append({
                    'severity': 'WARNING',
                    'file': str(yaml_file),
                    'message': f'Missing expected field: {field}',
                    'suggestion': f'Add "{field}" section to the file'
                })

    return issues


def check_script_quality(scripts_dir: Path, required_elements: list) -> list:
    """Validate Python scripts meet quality standards."""
    issues = []
    if not scripts_dir.exists():
        return issues

    for script in scripts_dir.glob('*.py'):
        if script.name == '__init__.py':
            continue

        content = script.read_text(encoding='utf-8')

        if 'docstring' in required_elements:
            if '"""' not in content and "'''" not in content:
                issues.append({
                    'severity': 'WARNING',
                    'file': str(script),
                    'message': 'Script missing docstring',
                    'suggestion': 'Add a module-level docstring'
                })

        if 'type_hints' in required_elements:
            # Simple heuristic: check for -> or : in function defs
            func_defs = re.findall(r'def \w+\(.*?\)', content)
            if func_defs and '->' not in content and ': ' not in content:
                issues.append({
                    'severity': 'WARNING',
                    'file': str(script),
                    'message': 'Script appears to lack type hints',
                    'suggestion': 'Add type hints to function signatures'
                })

        if 'error_handling' in required_elements:
            if 'try' not in content and 'except' not in content:
                # Only warn for scripts that do file I/O
                if 'open(' in content or 'read' in content or 'write' in content:
                    issues.append({
                        'severity': 'WARNING',
                        'file': str(script),
                        'message': 'Script with file I/O lacks error handling',
                        'suggestion': 'Add try/except around file operations'
                    })

    return issues


def check_naming_conventions(directory: Path, convention: str) -> list:
    """Check file naming conventions in a directory."""
    issues = []
    if not directory.exists():
        return issues

    patterns = {
        'snake_case': r'^[a-z][a-z0-9_]*\.[a-z]+$',
        'UPPER_SNAKE': r'^[A-Z][A-Z0-9_]*\.[a-z]+$',
        'kebab-case': r'^[a-z][a-z0-9\-]*\.[a-z]+$',
    }

    pattern = patterns.get(convention)
    if not pattern:
        return issues

    for file_path in directory.iterdir():
        if file_path.name.startswith('.'):
            continue
        if not re.match(pattern, file_path.name):
            issues.append({
                'severity': 'WARNING',
                'file': str(file_path),
                'message': f'File name "{file_path.name}" does not match {convention}',
                'suggestion': f'Rename to match {convention} convention'
            })

    return issues


def main():
    """Run content guard validation."""
    logger = setup_guard_logger('content_guard')
    root = get_project_root()
    config = load_guardrails_config()
    standards = config.get('content_standards', {})

    logger.info("Validating content standards...")
    all_issues = []

    # Check research YAML files
    research_fields = standards.get('required_yaml_fields', {}).get('research_output', [])
    all_issues.extend(check_yaml_files(root / 'research', research_fields))

    # Check plan YAML files
    plan_fields = standards.get('required_yaml_fields', {}).get('plan_output', [])
    all_issues.extend(check_yaml_files(root / 'plans', plan_fields))

    # Check script quality
    script_elements = standards.get('required_script_elements', [])
    all_issues.extend(check_script_quality(root / 'scripts', script_elements))

    # Check naming conventions
    naming = standards.get('naming_conventions', {})
    file_convention = naming.get('file_naming', 'snake_case')
    all_issues.extend(check_naming_conventions(root / 'scripts', file_convention))

    errors = [i for i in all_issues if i['severity'] == 'ERROR']
    warnings = [i for i in all_issues if i['severity'] == 'WARNING']

    for issue in errors:
        logger.error(f"[{issue['file']}] {issue['message']}")
    for issue in warnings:
        logger.warning(f"[{issue['file']}] {issue['message']}")

    if errors:
        logger.error(f"Content guard FAILED: {len(errors)} error(s), {len(warnings)} warning(s)")
        return False
    elif warnings:
        logger.warning(f"Content guard PASSED with {len(warnings)} warning(s)")
        return True
    else:
        logger.info("Content guard PASSED")
        return True


if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
