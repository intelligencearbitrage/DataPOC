---
name: self-review
description: "Self-check procedure every agent runs before marking a task complete"
---
# Self-Review Checklist

Run this checklist before calling `TaskUpdate(status: "completed")`.

## 1. Requirements Check
- [ ] Re-read the task description
- [ ] Every requirement in the task is addressed
- [ ] No requirements skipped or partially addressed

## 2. Output Verification
- [ ] Output file(s) exist at the expected path
- [ ] Output format matches the expected schema (YAML structure, file type, etc.)
- [ ] Output contains real content (not placeholders or TODOs)

## 3. Quality Check
- [ ] Output meets `GUARDRAILS.yaml` content standards
- [ ] Naming conventions followed (file names, YAML keys, etc.)
- [ ] Required fields are present in all output files

## 4. Consistency Check
- [ ] Output is consistent with inputs (no fabricated data)
- [ ] File references in output are valid (referenced files exist, paths are correct)
- [ ] Cross-references between outputs match (e.g., plan references match research findings)

## 5. Confidence Assessment
Rate your confidence: **HIGH** / **MEDIUM** / **LOW**
- If **MEDIUM**: document what is uncertain in your agent memory
- If **LOW**: escalate per `.claude/rules/escalation.md` before completing

## 6. Assumptions
List any assumptions you made during this task. Save significant assumptions to your agent memory so they can be referenced in future tasks.

## Outcome
- All checks pass → `TaskUpdate(status: "completed")`
- Any check fails → fix the issue before completing
- Cannot fix → escalate per `.claude/rules/escalation.md`
