---
name: generate-output
description: "Generic patterns for generating output artifacts from plans"
---
# Skill: Generate Output

## Description
Generic patterns for generating output artifacts from plans. Use these patterns when the builder agent creates scripts that produce deliverables.

## Base Pattern

All generators should extend `scripts/base_generator.py`:

```python
from base_generator import BaseGenerator
from pathlib import Path
from typing import Dict, Any

class MyGenerator(BaseGenerator):
    """Generator for [describe your deliverable type]."""

    def generate(self) -> None:
        """Read plans and produce deliverables."""
        plans = self.load_plans()
        for component_name, plan in plans.items():
            output = self.process_component(plan)
            self.save_output(output, f'{component_name}/{self.deliverable_name}')

    def process_component(self, plan: Dict[str, Any]) -> str:
        """Transform a component plan into a deliverable. Override this."""
        raise NotImplementedError
```

## Common Deliverable Patterns

### Text File Generation (SQL, code, configs)
```python
def process_component(self, plan):
    lines = []
    lines.append(f'-- Generated from: {plan["name"]}')
    for item in plan.get('items', []):
        lines.append(self.render_item(item))
    return '\n'.join(lines)
```

### YAML / Structured Data Generation
```python
import yaml

def process_component(self, plan):
    output_data = {
        'metadata': {'source_plan': plan['name']},
        'items': self.transform_items(plan.get('items', []))
    }
    return yaml.dump(output_data, default_flow_style=False, sort_keys=False)
```

### Diagram Generation (Mermaid, PlantUML, etc.)
```python
def process_component(self, plan):
    lines = ['```mermaid', 'graph TD']
    for item in plan.get('items', []):
        for rel in item.get('relationships', []):
            lines.append(f'    {item["name"]} --> {rel["target"]}')
    lines.append('```')
    return '\n'.join(lines)
```

### Template-Based Generation
```python
from string import Template

TEMPLATE = Template('''
# $title
Generated: $date

$content
''')

def process_component(self, plan):
    return TEMPLATE.substitute(
        title=plan['name'],
        date=datetime.now().strftime('%Y-%m-%d'),
        content=self.render_content(plan)
    )
```

## Key Principle
**Scripts produce deliverables. Agents produce scripts.**
This makes deliverables reproducible without AI — anyone can run `python scripts/build_all.py`.

## Data Flow
Scripts read from three sources:
- `plans/` — what to generate (structure, components, decisions)
- `knowledgebase/` — how to generate (rules, standards, conventions)
- `inputs/` — what to process (source data files)

## Output
Generators write to `output/` using `self.save_output(content, relative_path)`.
