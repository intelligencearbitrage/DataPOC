---
name: manage-tasks
description: "Coordination patterns for agent teams using Claude Code's shared task list"
---
# Skill: Manage Tasks (Agent Teams Coordination)

## Description
This skill defines how ALL agents coordinate using Claude Code's shared task list. This is the core communication mechanism for agent teams.

## The Shared Task List

Claude Code provides four tools for task management:

| Tool | Purpose |
|------|---------|
| `TaskCreate` | Create a new task (starts as `pending`) |
| `TaskUpdate` | Update status, dependencies, or description |
| `TaskList` | See all tasks with status summary |
| `TaskGet` | Get full details of a specific task |

## Task Lifecycle

```
pending  -->  in_progress  -->  completed
                  |
                  +--> (create new task if more work discovered)
```

## Task Fields

When creating tasks, always provide:
- **subject**: Imperative verb + clear outcome (e.g., "Parse configuration files")
- **description**: Full context — input files, expected output, quality criteria, which agent should claim it
- **activeForm**: Present continuous form for spinner display (e.g., "Parsing configuration files")

---

## Coordination Patterns

### Pattern 1: Lead Creates Tasks with Dependencies

The lead agent creates ALL tasks at the start, then sets up dependencies so teammates auto-discover work as predecessors complete.

```
# Lead creates Phase 1 tasks (no dependencies — can run in parallel)
TaskCreate("Research source A", description="...", activeForm="Researching source A")
  --> gets taskId "1"
TaskCreate("Research source B", description="...", activeForm="Researching source B")
  --> gets taskId "2"

# Lead creates Phase 2 tasks (blocked by Phase 1)
TaskCreate("Create unified inventory", description="...", activeForm="Creating inventory")
  --> gets taskId "3"
TaskUpdate(taskId: "3", addBlockedBy: ["1", "2"])

# Lead creates Phase 3 tasks (blocked by Phase 2)
TaskCreate("Build generator script", description="...", activeForm="Building generator")
  --> gets taskId "4"
TaskUpdate(taskId: "4", addBlockedBy: ["3"])
```

### Pattern 2: Teammate Claims Work

Teammates poll `TaskList` to find available work.

```
# Teammate checks for work
TaskList
  --> sees task "1" (pending, no blockers) — AVAILABLE
  --> sees task "3" (pending, blocked by 1,2) — NOT YET

# Teammate claims task
TaskUpdate(taskId: "1", status: "in_progress")

# Teammate does work...

# Teammate completes task
TaskUpdate(taskId: "1", status: "completed")

# Task "3" auto-unblocks when both "1" and "2" complete
```

### Pattern 3: Teammate Creates Follow-Up Tasks

If a teammate discovers additional work during execution:

```
# Researcher finds an additional source to analyze
TaskCreate("Research newly discovered source C",
  description="Found additional reference in source A findings...",
  activeForm="Researching source C")
  --> gets taskId "5"

# Update downstream task to also wait for this new task
TaskUpdate(taskId: "3", addBlockedBy: ["5"])
```

### Pattern 4: Reviewer Creates Fix Tasks

Reviewer finds issues and creates targeted fix tasks:

```
TaskCreate("Fix missing error handling in generator script",
  description="scripts/generate_report.py line 45: file open without try/except.
    Expected: wrap in try/except per GUARDRAILS.yaml required_script_elements.
    Suggested fix: add try/except around Path.read_text() call.",
  activeForm="Fixing missing error handling")
```

### Pattern 5: Expert Consultation

Any agent can request domain expert guidance by creating a consultation task:

```
# Teammate needs expert input
TaskCreate("Expert consult: [topic needing expertise]",
  description="EXPERT CONSULTATION REQUEST
    Requesting agent: [your agent name]
    Context: [what you're working on]
    Question: [specific question needing expert input]
    Relevant files: [list files the expert should read]
    Needed by: [which of your tasks depends on this answer]",
  activeForm="Consulting [expert type] expert")
  --> gets taskId "10"

# Block your own task on the consultation
TaskUpdate(taskId: my_current_task, addBlockedBy: ["10"])

# Expert claims, writes assessment to research/expert/, completes task
# Your task auto-unblocks and you can read the expert's guidance
```

**Who can consult whom:**
- Any teammate can consult any expert at any time
- Expert assessments are written to `research/expert/` for all agents to read
- Consultations are optional — only use when domain expertise adds value

### Pattern 6: Phase-Gate Validation

The lead creates GATE tasks between phases that must pass before the next phase starts:

```
# Lead creates a gate after Phase 1
TaskCreate("GATE: Validate Phase 1 research completeness",
  description="PHASE-GATE VALIDATION
    Check that:
    - All expected outputs exist
    - Required fields are present
    - Quality criteria from research/expert/ are met
    If validation FAILS: create fix tasks, do NOT proceed.
    If validation PASSES: mark complete so Phase 2 unblocks.",
  activeForm="Validating Phase 1")
  --> gets taskId "gate1"

# Block gate on all Phase 1 tasks
TaskUpdate(taskId: "gate1", addBlockedBy: [all_phase1_ids])

# Block Phase 2 tasks on the gate
TaskUpdate(taskId: "phase2_task", addBlockedBy: ["gate1"])
```

**Gate validation flow:**
```
Phase 1 tasks complete
    --> GATE task unblocks
    --> Reviewer/Lead validates
    --> If PASS: mark gate complete --> Phase 2 tasks unblock
    --> If FAIL: create fix tasks --> re-validate after fixes
```

### Pattern 7: Async Per-Script Review (Phase 3)

When the builder completes a script, the lead creates peer review and devil's advocate tasks for it. These run asynchronously while the builder moves on to the next script.

```
# Builder completes a script
TaskUpdate(taskId: "build_report", status: "completed")

# Lead creates review tasks (blocked on the build task)
TaskCreate("Peer review: generate_report.py",
  description="PEER REVIEW
    Review scripts/generate_report.py against plans/report_plan.yaml.
    Run the review checklist. Produce PASS/WARN/FAIL verdict.
    If FAIL: create fix tasks for builder.",
  activeForm="Peer reviewing report script")
  --> gets taskId "review_report"

TaskCreate("Devil's advocate: challenge generate_report.py",
  description="DEVIL'S ADVOCATE CHALLENGE
    Challenge assumptions in scripts/generate_report.py.
    Check edge cases, verify logic, look for incorrect assumptions.
    Produce PASS/WARN/FAIL verdict. FAIL is a hard block.",
  activeForm="Challenging report script")
  --> gets taskId "da_report"

# Block reviews on the build task
TaskUpdate(taskId: "review_report", addBlockedBy: ["build_report"])
TaskUpdate(taskId: "da_report", addBlockedBy: ["build_report"])

# Block GATE 3 on ALL review tasks
TaskUpdate(taskId: "gate3", addBlockedBy: ["review_report", "da_report"])
```

**Key points:**
- Builder doesn't wait for reviews — moves to next script immediately
- Both peer review AND devil's advocate must PASS independently
- Either can FAIL and block the gate
- Fix tasks go back to builder, who addresses them between other work

### Pattern 8: Escalation Tasks

When an agent is stuck, it creates an escalation task following `.claude/rules/escalation.md`:

```
# L3 escalation — agent is blocked and needs lead intervention
TaskCreate("ESCALATION L3: Cannot resolve conflict between research sources",
  description="ESCALATION — Level 3 (Blocking)
    Agent: analyzer
    Blocked task: 'Create master plan' (taskId: 12)
    What happened: research/source_a_findings.yaml says X but
      research/source_b_findings.yaml says Y — contradictory.
    What was tried: checked both sources, consulted expert guidance.
    What is needed: lead decision on which source takes priority.
    Impact: blocks MASTER_PLAN.yaml creation and all Phase 3 work.",
  activeForm="Escalating conflict to lead")

# L4 escalation — needs human intervention
TaskCreate("ESCALATION L4 - HUMAN REQUIRED: Missing source data",
  description="ESCALATION — Level 4 (Human Required)
    Agent: researcher
    Impact: Phase 1 cannot complete, blocks entire pipeline.
    What happened: prompts.md references knowledgebase/critical_spec.xlsx
      but the file does not exist.
    What was tried: searched all directories, checked alternate names.
    What is needed: user must provide the missing file.",
  activeForm="Escalating missing file to human")
```

**Key points:**
- Lead monitors for ESCALATION tasks in TaskList
- L3: Lead resolves by making a decision and updating the blocked task
- L4: Lead surfaces to the user immediately
- Always include: agent, blocked task, what happened, what was tried, what is needed

---

## Best Practices

1. **Task descriptions must be self-contained** — another agent must be able to complete the task without asking questions. Include file paths, expected format, quality criteria.

2. **Use activeForm** — always provide present-continuous form for spinner display.

3. **Check TaskList before creating** — avoid duplicate tasks.

4. **Update status promptly** — set to `in_progress` when starting, `completed` when done.

5. **Create granular tasks** — prefer many small tasks over few large ones. This enables better parallelism.

6. **Use dependencies for ordering** — never assume task execution order. Always use `addBlockedBy` to enforce ordering.

7. **Pass information through files, not task descriptions** — write findings to `research/`, plans to `plans/`, etc. Task descriptions should say WHERE to find information, not contain the information itself.
