---
name: parse-input
description: "Generic patterns for reading and parsing input files of any format"
---
# Skill: Parse Input

## Description
Generic patterns for reading and parsing input files of any format. Use these patterns when building scripts that read source data from `inputs/` and reference materials from `knowledgebase/`.

## Base Pattern

All parsers should extend `scripts/base_parser.py`:

```python
from base_parser import BaseParser
from pathlib import Path
from typing import Dict, List, Any

class MyParser(BaseParser):
    """Parser for [describe your input format]."""

    def discover_files(self) -> List[Path]:
        """Find all input files of this type."""
        return list(self.input_dir.glob('*.ext'))

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse a single file and return structured data."""
        # Your parsing logic here
        return {
            'name': file_path.stem,
            'items': [],
            'metadata': {}
        }
```

## Format-Specific Patterns

### Excel / CSV
```python
import pandas as pd

def parse_file(self, file_path):
    df = pd.read_excel(file_path)  # or pd.read_csv()
    return {
        'name': file_path.stem,
        'columns': list(df.columns),
        'row_count': len(df),
        'items': df.to_dict(orient='records')
    }
```

### XML
```python
import xml.etree.ElementTree as ET

def parse_file(self, file_path):
    tree = ET.parse(file_path)
    root = tree.getroot()
    return {
        'name': file_path.stem,
        'root_tag': root.tag,
        'items': [{'tag': child.tag, 'attrib': child.attrib} for child in root]
    }
```

### JSON
```python
import json

def parse_file(self, file_path):
    with open(file_path) as f:
        data = json.load(f)
    return {
        'name': file_path.stem,
        'items': data if isinstance(data, list) else [data]
    }
```

### SQL / Code Files
```python
import re

def parse_file(self, file_path):
    content = file_path.read_text(encoding='utf-8')
    # Extract structures using regex or string parsing
    return {
        'name': file_path.stem,
        'content_length': len(content),
        'items': []  # populate based on what you extract
    }
```

## Output
Parsers write deliverables to `output/` using `self.save_analysis(filename)`.

## Dependencies
- `pandas` + `openpyxl` for Excel
- `lxml` for complex XML
- `PyYAML` for YAML output
- Standard library for JSON, CSV, SQL, code files
