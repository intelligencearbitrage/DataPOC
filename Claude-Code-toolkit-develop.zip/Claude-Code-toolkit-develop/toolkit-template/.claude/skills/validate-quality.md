---
name: validate-quality
description: "Patterns for validating output quality and running guardrail checks"
---
# Skill: Validate Quality

## Description
Patterns for validating output quality. Use these patterns when the reviewer agent checks artifacts or when running `guardrails/run_guardrails.py`.

## Validation Pattern

All validators should extend `scripts/base_validator.py`:

```python
from base_validator import BaseValidator
from pathlib import Path
from typing import List, Dict

class MyValidator(BaseValidator):
    """Validator for [describe what you validate]."""

    def validate(self) -> List[Dict]:
        """Run all checks, return list of issues found."""
        issues = []
        issues.extend(self.check_files_exist())
        issues.extend(self.check_content_valid())
        issues.extend(self.check_conventions())
        return issues
```

## Common Validation Checks

### File Existence
```python
def check_files_exist(self):
    issues = []
    for expected_file in self.expected_files:
        if not Path(expected_file).exists():
            issues.append({
                'severity': 'ERROR',
                'file': expected_file,
                'message': f'Expected file not found: {expected_file}'
            })
    return issues
```

### YAML Validity
```python
import yaml

def check_yaml_valid(self, file_path):
    issues = []
    try:
        with open(file_path) as f:
            data = yaml.safe_load(f)
        if data is None:
            issues.append({
                'severity': 'ERROR',
                'file': str(file_path),
                'message': 'YAML file is empty'
            })
    except yaml.YAMLError as e:
        issues.append({
            'severity': 'ERROR',
            'file': str(file_path),
            'message': f'Invalid YAML: {e}'
        })
    return issues
```

### Required Fields
```python
def check_required_fields(self, data, required_fields, file_path):
    issues = []
    for field in required_fields:
        if field not in data:
            issues.append({
                'severity': 'ERROR',
                'file': str(file_path),
                'message': f'Missing required field: {field}'
            })
    return issues
```

### Script Quality
```python
def check_script_quality(self, script_path):
    issues = []
    content = script_path.read_text()

    if '"""' not in content and "'''" not in content:
        issues.append({
            'severity': 'WARNING',
            'file': str(script_path),
            'message': 'Script missing docstring'
        })

    if 'from pathlib' not in content and 'import pathlib' not in content:
        issues.append({
            'severity': 'WARNING',
            'file': str(script_path),
            'message': 'Script should use pathlib for file operations'
        })

    return issues
```

### Naming Convention
```python
import re

def check_naming(self, name, convention='snake_case'):
    patterns = {
        'snake_case': r'^[a-z][a-z0-9_]*$',
        'UPPER_SNAKE': r'^[A-Z][A-Z0-9_]*$',
        'camelCase': r'^[a-z][a-zA-Z0-9]*$',
        'PascalCase': r'^[A-Z][a-zA-Z0-9]*$',
    }
    pattern = patterns.get(convention, patterns['snake_case'])
    if not re.match(pattern, name):
        return {
            'severity': 'WARNING',
            'message': f'"{name}" does not match {convention} convention'
        }
    return None
```

## Issue Format
All validators return issues as:
```yaml
- severity: "ERROR" | "WARNING" | "INFO"
  file: "path/to/file"
  message: "What is wrong"
  suggestion: "How to fix it"
```

## Running Validators
Use `guardrails/run_guardrails.py` to run all validators, or run individually:
```bash
python guardrails/content_guard.py
python guardrails/folder_guard.py
python guardrails/phase_guard.py
```
