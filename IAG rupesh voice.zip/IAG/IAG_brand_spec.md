# Intelligence Arbitrage Group — Brand Spec & Reconstruction Guide
## Figma / Adobe Illustrator Reference Document

---

## 1. Brand Colors

| Token | Hex | Usage |
|---|---|---|
| Navy | `#0B1E3D` | Brain outline (light), background (dark), wordmark (light) |
| Teal | `#00A8B5` | All knowledge graph nodes and edges, GROUP subtext |
| White | `#FFFFFF` | Brain outline (dark version), wordmark (dark version) |
| Cream | `#F4F1EC` | Light version background |

---

## 2. Typography

| Element | Font | Weight | Size (at full lockup ~480px wide) | Tracking |
|---|---|---|---|---|
| INTELLIGENCE ARBITRAGE | Helvetica Neue (or Inter) | Medium 500 | 34px | +120 (0.12em) |
| GROUP | Helvetica Neue (or Inter) | Medium 500 | 14px | +480 (0.48em) |

**Figma note:** Use `Inter` if Helvetica Neue is unavailable. It is visually equivalent for this mark.  
**Illustrator note:** Set tracking in the Character panel. 34pt × 0.12em = ~4pt between letters.

---

## 3. Mark Construction: Brain Lobes

The mark uses **two completely separate closed paths** — one per hemisphere — with a ~8px fissure gap between them. Both share the same shared inner edge at x=80 (left lobe) and x=84 (right lobe) in a 160×180 coordinate system.

### Left Lobe SVG Path
```
M 76,14
C 72,6  58,2  46,6
C 34,10 22,18 16,30
C 8,44  8,58  10,66
C 8,74  6,86  10,96
C 7,108 8,122 14,132
C 20,148 34,162 50,168
C 60,172 70,170 76,162
C 80,154 80,138 80,120
C 80,100 80,80  80,60
C 80,42  79,26  76,14
Z
```

### Right Lobe SVG Path (mirror)
```
M 84,14
C 88,6  102,2 114,6
C 126,10 138,18 144,30
C 152,44 152,58 150,66
C 153,74 154,86 150,96
C 153,108 152,122 146,132
C 140,148 126,162 110,168
C 100,172 90,170 84,162
C 80,154 80,138 80,120
C 80,100 80,80  80,60
C 80,42  81,26  84,14
Z
```

### Stroke Specs
- Stroke color: `#0B1E3D` (light) / `#FFFFFF` (dark)
- Stroke width: **3px** at mark size (160×180); scale proportionally
- Fill: **None**
- Join: Round
- Cap: Round

**Figma tip:** Paste each path into a Frame, set stroke to Inside, align to pixel grid.  
**Illustrator tip:** Use the Pen tool to paste the path data via Object → Path → Paste SVG. Set stroke alignment to Center.

---

## 4. Knowledge Graph: Node + Edge Coordinates

### Left Lobe Graph (6 nodes, 7 edges)

| Node | X | Y | Radius |
|---|---|---|---|
| Apex | 50 | 48 | 5 |
| Mid-Left | 36 | 72 | 3.5 |
| Mid-Right | 62 | 72 | 3.5 |
| Lower-Left | 44 | 104 | 3.5 |
| Lower-Right | 56 | 104 | 3.5 |
| Base | 50 | 132 | 4.5 |

| Edge | From | To |
|---|---|---|
| 1 | Apex (50,48) | Mid-Left (36,72) |
| 2 | Apex (50,48) | Mid-Right (62,72) |
| 3 | Mid-Left (36,72) | Mid-Right (62,72) |
| 4 | Mid-Left (36,72) | Lower-Left (44,104) |
| 5 | Mid-Right (62,72) | Lower-Right (56,104) |
| 6 | Lower-Left (44,104) | Lower-Right (56,104) |
| 7 | Lower-Center (50,104) | Base (50,132) |

### Right Lobe Graph (mirror — add 60px to X coordinates)

| Node | X | Y | Radius |
|---|---|---|---|
| Apex | 110 | 48 | 5 |
| Mid-Left | 98 | 72 | 3.5 |
| Mid-Right | 124 | 72 | 3.5 |
| Lower-Left | 104 | 104 | 3.5 |
| Lower-Right | 116 | 104 | 3.5 |
| Base | 110 | 132 | 4.5 |

### Edge Specs
- Stroke: `#00A8B5`
- Stroke width: **2px** at mark size; scale proportionally
- Cap: Round

### Node Specs
- Fill: `#00A8B5`
- No stroke

---

## 5. Divider Line (lockup only)

Separates mark from wordmark in horizontal lockup:
- X1=X2 (vertical line)
- Position: 28px right of mark's right edge
- Height: 70% of mark height, vertically centered
- Color: `#0B1E3D` at 20% opacity (light) / `#FFFFFF` at 25% opacity (dark)
- Width: 1.5px

---

## 6. Lockup Spacing

```
[MARK 160×180] [28px gap] [1.5px divider] [22px gap] [WORDMARK]
```

Wordmark block:
- "INTELLIGENCE ARBITRAGE" — line 1
- "GROUP" — line 2, 28px below line 1 baseline
- Vertically centered against full mark height

---

## 7. Minimum Sizes

| Format | Min Width | Notes |
|---|---|---|
| Horizontal lockup | 320px | Below this, drop wordmark |
| Mark + stacked text | 120px wide | |
| Mark only (icon) | 48px | Drop internal edges below 32px |
| Favicon | 32px | Use 3 nodes per lobe only, no edges |

---

## 8. Figma Layer Structure (recommended)

```
IAG Logo (Frame)
├── Mark (Group)
│   ├── Left Lobe (Vector) — stroke #0B1E3D
│   ├── Right Lobe (Vector) — stroke #0B1E3D
│   ├── Left Graph (Group)
│   │   ├── Edges (Group) — stroke #00A8B5
│   │   └── Nodes (Group) — fill #00A8B5
│   └── Right Graph (Group)
│       ├── Edges (Group) — stroke #00A8B5
│       └── Nodes (Group) — fill #00A8B5
├── Divider (Line) — stroke #0B1E3D 20%
└── Wordmark (Group)
    ├── Intelligence Arbitrage (Text)
    └── Group (Text)
```

---

## 9. Illustrator Layer Structure (recommended)

```
Layer 1: Mark
  Sublayer: Lobe Outlines (Stroke only, no fill)
  Sublayer: Graph Edges (Stroke #00A8B5)
  Sublayer: Graph Nodes (Fill #00A8B5, no stroke)
Layer 2: Divider
Layer 3: Wordmark
```

Use **Outline Stroke** when finalizing for print to convert strokes to filled paths.

---

## 10. File Formats to Export

| Use | Format | Notes |
|---|---|---|
| Web / digital | SVG | Keep as vector |
| Print / large format | PDF (vector) | Export from AI |
| Social avatar (1:1) | PNG 400×400 | Navy bg + white mark |
| Favicon | ICO / PNG 32×32 | Mark only, simplified |
| Email signature | PNG 2× | 320px wide on navy or transparent |
| Pitch deck | EMF or SVG | Import into PowerPoint/Keynote |

---

*Spec version 1.0 — Intelligence Arbitrage Group*
