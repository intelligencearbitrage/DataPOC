# CoCo Toolkit Template — Project Instructions

## Role & Context

You are operating within the **CoCo Toolkit Template** — a framework for building multi-phase AI pipelines using Cortex Code (CoCo). Your primary task is to follow the 4-phase pipeline (Research → Plan → Build → Review) to analyze inputs and produce deliverables.

This project uses **CoCo skills** (in `.snowflake/cortex/skills/`) to guide each phase, **subagents** (via the `task` tool) for parallel review work, and **Snowflake-native tools** for enhanced validation.

---

## General Principles

### Pipeline Mindset
- **Follow the phases**: Research thoroughly before planning. Plan completely before building. Review everything before delivering.
- **Evidence over assumption**: Every claim must trace back to a source file. If you can't cite the source, flag it as an assumption.
- **Reproducibility**: You produce scripts. Scripts produce deliverables. Anyone can re-run the scripts without AI.
- **Quality gates are non-negotiable**: Each phase ends with a human approval gate. Never skip validation.

### How You Coordinate Work
- **`system_todo_write` is your task tracker**: Break each phase into todos. Mark in_progress when starting, completed when done.
- **Skills guide your behavior**: Load the relevant phase skill at each stage.
- **Subagents handle independent reviews**: Spawn devil's advocate and peer-review subagents via the `task` tool.
- **`ask_user_question` is your gate mechanism**: Use it for phase approvals, clarifications, and escalations.
- **Write findings to files, not conversation**: Use `research/`, `plans/`, `scripts/`, `output/` folders. Keep the conversation focused on decisions.

### Escalation Protocol
When stuck, follow this hierarchy:
- **L1 (Minor)**: Self-resolve technical decisions. Document the assumption in `/memories/`.
- **L1.5 (Clarification)**: Use `ask_user_question` for business/domain ambiguity. Block until answered.
- **L2 (Moderate)**: Spawn an expert consultation subagent for specialized knowledge.
- **L3 (Blocking)**: Surface the blocker to the user with full context and options.
- **L4 (Critical)**: HARD STOP. Present the issue, impact analysis, and what you need before proceeding.
- **Circuit breaker**: 3 failures on the same step → escalate to the next level.

---

## Folder Conventions

| Folder | Purpose | Who Writes | Immutable? |
|--------|---------|------------|------------|
| `knowledgebase/` | Reference materials (standards, rules, conventions) | Human | Yes — never modify |
| `inputs/` | Source data for scripts to process | Human | Yes — never modify |
| `research/` | Analysis findings from Phase 1 | CoCo (Phase 1) | No |
| `research/expert/` | Expert consultation results | Subagents | No |
| `plans/` | Master plan and component plans from Phase 2 | CoCo (Phase 2) | No |
| `scripts/` | Python scripts from Phase 3 | CoCo (Phase 3) | No |
| `output/` | Final deliverables (produced by running scripts) | Scripts at runtime | No |
| `testscripts/` | Review reports and validation results from Phase 4 | CoCo (Phase 4) | No |
| `thoughts/logs/` | Progress and guardrail logs | CoCo + guardrails | No |
| `guardrails/` | Python enforcement scripts | Human | Yes — never modify |

### Immutability Rules
- NEVER write to `knowledgebase/` or `inputs/` — these are the ground truth.
- NEVER write to `guardrails/` — these are the enforcement mechanism.
- Scripts write ONLY to `output/`. Scripts never modify themselves or other folders.

---

## Code Quality Standards

All generated scripts must:
- Be **idempotent** (safe to re-run)
- Use **pathlib** for all file operations
- Include **error handling** for file I/O
- Include **type hints** and **docstrings** (Google style)
- Read from `inputs/` + `knowledgebase/`, write to `output/`
- Follow naming conventions in `GUARDRAILS.yaml`
- Contain **no hardcoded values** — read configuration from plans
- Extend `BaseParser` or `BaseGenerator` from `scripts/`

---

## Snowflake-Enhanced Capabilities

This template leverages CoCo's Snowflake integration for higher-quality results:

| Capability | How to Use | When |
|---|---|---|
| **DDL validation** | `snowflake_sql_execute(sql, only_compile=true)` | Phase 3+4: Verify generated SQL compiles |
| **Schema discovery** | `snowflake_object_search(query)` | Phase 1: Discover existing tables/views |
| **Docs research** | `snowflake_product_docs(query)` | Phase 1-2: Research Snowflake features/syntax |
| **Cortex AI** | `cortex-ai-function-studio` skill | Phase 4+Layer 2: Semantic validation |
| **SQL execution** | `snowflake_sql_execute(sql)` | Phase 4: Run generated SQL in sandbox |

### Safety Rules for Snowflake Operations
- Use `only_compile=true` for validation (no data changes)
- Never execute DDL that creates/alters/drops objects without explicit user approval (Gate = 🔴 HIGH)
- Use the configured sandbox warehouse (`SF_SANDBOX_WH`) for any test execution
- All SQL must be validated with `sql-verify` subagent before execution

---

## Available Skills

| Skill | Invoke When | Purpose |
|-------|-------------|---------|
| `pipeline-orchestrator` | "start project" | Full 4-phase workflow orchestration |
| `research-phase` | Phase 1 | Analyze knowledgebase/, produce findings |
| `planning-phase` | Phase 2 | Synthesize research into actionable plans |
| `build-phase` | Phase 3 | Create scripts that produce deliverables |
| `review-phase` | Phase 4 | Validate everything, run scripts, verify output |
| `devils-advocate` | Phase 2-3 gates | Adversarial challenge of plans/scripts |
| `peer-review` | Phase 3 (per script) | Code quality review |
| `expert-consult` | Any phase (on demand) | Specialized domain consultation |
| `self-review` | Before completing any task | Completion quality checklist |
| `agentic-loop` | After Phase 4 (optional) | Automated validate/refine cycle |

---

## Key Documents

| Document | What It Tells You |
|----------|-------------------|
| `prompts.md` | What to build — source materials, components, deliverables |
| `GUARDRAILS.yaml` | Quality standards — folder boundaries, naming, phase gates |
| `SETUP_GUIDE.md` | How to configure and customize this project |
| `SOLUTION_APPROACH.md` | Architecture and pipeline design |

---

## Workflow Summary

```
"start project"
    │
    ▼
Phase 1: Research ──→ Gate 1 (user reviews) ──→
Phase 2: Plan     ──→ DA Challenge ──→ Gate 2 (MANDATORY user approval) ──→
Phase 3: Build    ──→ Peer Review + DA per script ──→ Gate 3 (user reviews) ──→
Phase 4: Review   ──→ Gate 4 (final) ──→
[Optional] Layer 2: Agentic validate/refine loop
```
