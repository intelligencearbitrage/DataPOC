# CoCo Toolkit Template

A reusable project template for Cortex Code (CoCo) that turns one "build me this asset" request into a coordinated 4-phase pipeline producing runnable Python scripts.

## What It Does

```
prompts.md + knowledgebase/ → [Research → Plan → Build → Review] → scripts/ → output/
```

The pipeline produces Python scripts as deliverables. Scripts read from `inputs/`, apply transformation logic using `knowledgebase/` rules, and generate output — reproducible without AI.

## Quick Start

1. Copy this template and rename for your project
2. Fill `prompts.md` with your requirements
3. Add reference materials to `knowledgebase/`
4. Add source data to `inputs/`
5. In CoCo, say: **"start project"**

See `SETUP_GUIDE.md` for full instructions.

## Structure

```
├── CLAUDE.md                      # Project instructions for CoCo
├── prompts.md                     # YOUR requirements (fill this)
├── GUARDRAILS.yaml                # Quality rules
├── SETUP_GUIDE.md                 # How to use this template
├── .snowflake/cortex/skills/      # 10 CoCo skills (pipeline phases + quality)
├── knowledgebase/                 # YOUR reference materials
├── inputs/                        # YOUR source data
├── scripts/                       # Generated Python scripts (Phase 3 output)
├── output/                        # Deliverables (produced by running scripts)
├── research/                      # Phase 1 output
├── plans/                         # Phase 2 output
├── testscripts/                   # Phase 4 output
└── guardrails/                    # Python enforcement scripts
```

## Pipeline Phases

| Phase | What Happens | Gate |
|-------|-------------|------|
| 1. Research | Analyze `knowledgebase/`, produce YAML findings | Optional approval |
| 2. Plan | Synthesize into master plan + DA challenge | **Mandatory** approval |
| 3. Build | Create scripts + peer review + DA per script | Optional approval |
| 4. Review | Validate everything, verify output | Mandatory approval |
| Layer 2 | (Optional) Automated validate/refine loop | Entry + exit approval |

## Key Differences from Claude Code Agent Teams Version

- **Single CoCo thread + subagents** (not 11 autonomous agents)
- **Skills guide behavior** (not agent definitions)
- **Sequential phases with parallel reviews** (not fully parallel)
- **Snowflake-enhanced**: SQL validation, Cortex AI, object search
- **Interactive conversation flow**: intervene at any point

## Requirements

- Cortex Code (CoCo) Desktop
- Python 3.8+ with PyYAML (`pip install pyyaml`)
- Active Snowflake connection (for enhanced features)
