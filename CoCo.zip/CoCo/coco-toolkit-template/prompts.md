# Project Requirements — prompts.md

> Fill this template with your project-specific requirements. This is the single source of truth for what the pipeline builds.

---

## Objective

<!-- What are you building? One clear sentence. -->
Build a [DESCRIBE YOUR ACCELERATOR/SOLUTION] that [WHAT IT DOES].

---

## Source Materials

### knowledgebase/ — Reference Knowledge
<!-- List the reference materials you've placed in knowledgebase/. These are standards, rules, conventions that both agents and scripts use. -->

| File | Contains |
|------|----------|
| `knowledgebase/[file1]` | [Description] |
| `knowledgebase/[file2]` | [Description] |

### inputs/ — Source Data to Process
<!-- List the source data files the generated scripts will process at runtime. -->

| File | Format | Contains |
|------|--------|----------|
| `inputs/[file1]` | [Excel/SQL/JSON/XML/CSV] | [Description] |

---

## Deliverables

<!-- What should appear in output/ after running the scripts? Be specific about format and structure. -->

| Deliverable | Format | Location | Description |
|-------------|--------|----------|-------------|
| [Name] | [SQL/YAML/MD/JSON] | `output/[path]` | [What it contains] |

---

## Components

<!-- Break the deliverables into logical components that map to individual scripts. -->

1. **[Component 1 name]** — [What this component does]
2. **[Component 2 name]** — [What this component does]
3. **[Component 3 name]** — [What this component does]

---

## Success Criteria

<!-- How do you know the output is correct? These become validation checks. -->

- [ ] [Criterion 1 — e.g., "Every table in source appears in output"]
- [ ] [Criterion 2 — e.g., "All data types mapped per knowledgebase/type_mappings.yaml"]
- [ ] [Criterion 3 — e.g., "Generated SQL compiles against Snowflake"]
- [ ] [Criterion 4 — e.g., "No source data missing from output"]

---

## Constraints

<!-- Any rules or constraints the solution must follow. -->

- [Constraint 1 — e.g., "Output DDL must be Snowflake-compatible"]
- [Constraint 2 — e.g., "Scripts must handle files up to 10MB"]
- [Constraint 3 — e.g., "No external API dependencies in scripts"]

---

## Out of Scope

<!-- Explicitly list what is NOT part of this project. -->

- [Not in scope 1]
- [Not in scope 2]

---

## Snowflake Configuration (Optional)

<!-- If using Snowflake-enhanced features, specify your target environment. -->

| Setting | Value |
|---------|-------|
| Target database | `[DATABASE]` |
| Target schema | `[SCHEMA]` |
| Warehouse | `[WAREHOUSE]` |
| Validate DDL? | Yes / No |
| Execute DDL? | No (scripts-only) / Yes (with approval) |
