# Ontology on Snowflake: Implementation Playbook

**Version:** 1.0 | **Date:** 2026-06-12 | **Authors:** Deloitte Data & AI Practice  
**Audience:** Technical implementers, data engineers, and solution architects  
**Prerequisite:** Read the Design Guide first for architecture context.

---

## How to Implement Ontology on Snowflake for a New Client Domain

This playbook walks you through the complete process from blank slate to production-ready ontology-powered agent.

---

## Phase 0: Discovery & Data Profiling

### Step 0.1: Identify the Domain Scope

Before touching any SQL, answer these questions with the client:

| Question | Why It Matters | Example Answer |
|----------|---------------|----------------|
| What business questions do users ask today? | Drives metric and dimension design | "What's our revenue by region?" "Which suppliers are at risk?" |
| What questions can't they answer today? | Identifies if KG is needed | "How is this customer connected to that fraud ring?" |
| What source systems exist? | Maps the data landscape | SAP, Salesforce, internal data lake |
| What entities matter most? | Prioritizes ontology scope | Customer, Product, Order, Supplier |
| Are relationships important? | Decides Phase A vs Phase B | "We need to trace supply chain dependencies" → KG |
| What's the data volume? | Impacts design decisions | 1M customers, 50M transactions |

### Step 0.2: Profile the Source Data

Run this profiling on each candidate source table:

```sql
-- Table shape
SELECT COUNT(*) AS row_count,
       COUNT(*) - COUNT(DISTINCT <primary_key>) AS duplicate_keys
FROM <source_table>;

-- Column inventory
DESCRIBE TABLE <source_table>;

-- Cardinality check (which columns are dimensions vs. measures)
SELECT
    COLUMN_NAME,
    COUNT(DISTINCT <column>) AS distinct_values,
    COUNT(*) AS total_rows,
    ROUND(COUNT(DISTINCT <column>) / COUNT(*) * 100, 1) AS cardinality_pct
FROM <source_table>
GROUP BY ALL;

-- Foreign key detection (look for _ID columns that reference other tables)
SELECT COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = '<table>'
  AND (COLUMN_NAME LIKE '%_ID' OR COLUMN_NAME LIKE '%_KEY');

-- Data freshness
SELECT MIN(<date_col>) AS earliest, MAX(<date_col>) AS latest,
       DATEDIFF(DAY, MAX(<date_col>), CURRENT_DATE()) AS days_stale
FROM <source_table>;
```

### Step 0.3: Map Entities and Relationships (Whiteboard Exercise)

Draw a simple entity-relationship diagram with the client:

```
[Customer] --owns--> [Account] --holds--> [Instrument]
     |                    |
     |--transacts_at--> [Branch]
     |
     |--beneficiary_of--> [Customer]
```

Key outputs from this exercise:
1. **Entity list** — the nouns (Customer, Account, Product, Order, etc.)
2. **Relationship list** — the verbs (owns, holds, reports_to, supplies, etc.)
3. **Hierarchy list** — the classification trees (product taxonomy, org hierarchy, geography)
4. **Alias list** — business terms that map to entities ("client" = Customer)

---

## Phase 1: Build the Lightweight Ontology

### Step 1.1: Create Schema and Load Source Data

```sql
CREATE DATABASE IF NOT EXISTS <CLIENT>_ONTOLOGY_DB;
CREATE SCHEMA IF NOT EXISTS <CLIENT>_ONTOLOGY_DB.<DOMAIN>_ONTOLOGY;
```

If source data is in another database, create views or copy into your schema. Prefer views to avoid duplication.

### Step 1.2: Build Ontology Metadata Tables

Create these four tables — they are the "control plane":

#### ONT_ENTITY_TYPES
```sql
CREATE TABLE ONT_ENTITY_TYPES (
    ENTITY_TYPE_ID INT,
    ENTITY_NAME STRING NOT NULL,        -- PascalCase canonical name
    DESCRIPTION STRING,                 -- What this entity represents in the business
    IS_ABSTRACT BOOLEAN DEFAULT FALSE,  -- TRUE for parent-only types (never instantiated)
    PARENT_ENTITY STRING,               -- Inheritance: what does this specialize?
    SOURCE_TABLE STRING,                -- Which physical table holds these?
    IDENTIFIER_COLUMN STRING,           -- Primary key column in source table
    DISPLAY_NAME_COLUMN STRING,         -- How to show a human-readable name
    CREATED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);
```

**How to populate:**
- One row per distinct entity type identified in Step 0.3
- Add abstract parents for generalization (e.g., `FinancialEntity` as parent of `Customer` and `Supplier`)
- Abstract entities have `IS_ABSTRACT=TRUE` and no `SOURCE_TABLE`

#### ONT_RELATIONSHIP_TYPES
```sql
CREATE TABLE ONT_RELATIONSHIP_TYPES (
    RELATIONSHIP_TYPE_ID INT,
    RELATIONSHIP_NAME STRING NOT NULL,   -- snake_case verb (owns, holds, reports_to)
    DESCRIPTION STRING,
    FROM_ENTITY STRING NOT NULL,         -- Source entity type
    TO_ENTITY STRING NOT NULL,           -- Target entity type
    CARDINALITY STRING,                  -- one-to-one, one-to-many, many-to-many
    INVERSE_NAME STRING,                 -- Reverse: "owns" inverse is "owned_by"
    IS_TEMPORAL BOOLEAN DEFAULT FALSE,   -- Does this relationship have start/end dates?
    SOURCE_TABLE STRING,                 -- Where does this relationship live physically?
    FROM_KEY_COLUMN STRING,
    TO_KEY_COLUMN STRING,
    CREATED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);
```

#### ONT_HIERARCHIES
```sql
CREATE TABLE ONT_HIERARCHIES (
    HIERARCHY_ID INT,
    HIERARCHY_NAME STRING NOT NULL,      -- e.g., "ProductTaxonomy", "OrgStructure"
    DESCRIPTION STRING,
    ENTITY_TYPE STRING NOT NULL,         -- Which entity does this classify?
    LEVEL_NUM INT NOT NULL,              -- 1 = top, N = leaf
    LEVEL_NAME STRING NOT NULL,          -- Human name for this level
    SOURCE_COLUMN STRING,               -- Column in source table for this level
    CREATED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);
```

#### ONT_ALIASES
```sql
CREATE TABLE ONT_ALIASES (
    ALIAS_ID INT,
    CANONICAL_NAME STRING NOT NULL,      -- The official ontology term
    ALIAS STRING NOT NULL,               -- What users/systems call it
    CONTEXT STRING,                      -- When does this alias apply?
    CREATED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);
```

### Step 1.3: Create Convenience Views

Pattern for each entity:
```sql
CREATE OR REPLACE VIEW V_<ENTITY> AS
SELECT
    <primary_key>,
    <display_name>,
    <key_attributes>,
    <dimension_columns>
FROM <source_table>;
```

Pattern for each relationship:
```sql
CREATE OR REPLACE VIEW V_<RELATIONSHIP> AS
SELECT
    <from_entity_key>,
    <to_entity_key>,
    <relationship_attributes>
FROM <source_table_or_join>;
```

Pattern for abstract views (union of concrete types):
```sql
CREATE OR REPLACE VIEW VW_ONT_<ABSTRACT_ENTITY> AS
SELECT <id>, <name>, '<ConcreteType1>' AS entity_class, <shared_attrs>
FROM <source_1>
UNION ALL
SELECT <id>, <name>, '<ConcreteType2>' AS entity_class, <shared_attrs>
FROM <source_2>;
```

### Step 1.4: Build the Semantic View

Use the `CREATE SEMANTIC VIEW` DDL:

```sql
CREATE OR REPLACE SEMANTIC VIEW <DOMAIN>_SEMANTIC_VIEW
  TABLES (
    <entity_alias> AS <schema>.<view>
      PRIMARY KEY (<pk_col>)
      WITH SYNONYMS ('<alias1>', '<alias2>')
      COMMENT = '<what this entity represents>',
    ...
  )
  RELATIONSHIPS (
    <name> AS <table_a> (<fk_col>) REFERENCES <table_b>,
    ...
  )
  FACTS (
    <table>.<fact_name> AS <expression>
      COMMENT = '<what this measures>',
    ...
  )
  DIMENSIONS (
    <table>.<dim_name> AS <expression>
      WITH SYNONYMS = ('<alias>')
      COMMENT = '<what this categorizes>',
    ...
  )
  METRICS (
    <table>.<metric_name> AS <aggregation>(<fact>)
      COMMENT = '<business meaning>',
    ...
  )
  COMMENT = '<overall description>'
  AI_SQL_GENERATION '<instructions for how to generate SQL>'
  AI_QUESTION_CATEGORIZATION '<what to reject or clarify>';
```

**Key decisions:**
- Every business term in ONT_ALIASES should appear as a synonym somewhere
- Every hierarchy level in ONT_HIERARCHIES should appear as a dimension
- AI_SQL_GENERATION should encode ordering rules, rounding, and disambiguation logic

### Step 1.5: Create the Cortex Agent

```sql
CREATE OR REPLACE AGENT <DOMAIN>_AGENT
  COMMENT = '<description>'
  FROM SPECIFICATION
  $$
  models:
    orchestration: claude-4-sonnet

  instructions:
    response: "<how to format answers, what assumptions to state>"
    orchestration: "<when to use which tool>"
    sample_questions:
      - question: "<common question 1>"
      - question: "<common question 2>"

  tools:
    - tool_spec:
        type: "cortex_analyst_text_to_sql"
        name: "<ToolName>"
        description: "<when to use this tool — be specific>"

  tool_resources:
    <ToolName>:
      semantic_view: "<database>.<schema>.<semantic_view>"
  $$;
```

---

## Phase 2: Add the Knowledge Graph (If Needed)

### Step 2.1: Create KG Tables

```sql
CREATE TABLE KG_NODE (
    NODE_ID STRING NOT NULL,        -- Pattern: <TYPE>-<id> e.g., CUST-42
    NODE_TYPE STRING NOT NULL,
    NAME STRING,
    PROPS VARIANT,                  -- Flexible attributes as JSON
    TS_INGESTED TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    PRIMARY KEY (NODE_ID)
) CLUSTER BY (NODE_TYPE);

CREATE TABLE KG_EDGE (
    EDGE_ID STRING NOT NULL,
    SRC_ID STRING NOT NULL,
    DST_ID STRING NOT NULL,
    EDGE_TYPE STRING NOT NULL,
    WEIGHT FLOAT DEFAULT 1.0,
    PROPS VARIANT,
    EFFECTIVE_START DATE,
    EFFECTIVE_END DATE,
    TS_INGESTED TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    PRIMARY KEY (EDGE_ID)
) CLUSTER BY (EDGE_TYPE, SRC_ID, DST_ID);

-- Bidirectional view for traversal
CREATE VIEW V_KG_EDGE_BIDIR AS
SELECT SRC_ID, DST_ID, EDGE_TYPE FROM KG_EDGE
UNION ALL
SELECT DST_ID, SRC_ID, 'inverse_' || EDGE_TYPE FROM KG_EDGE;
```

### Step 2.2: Load Entities and Relationships

Pattern for loading nodes:
```sql
INSERT INTO KG_NODE (NODE_ID, NODE_TYPE, NAME, PROPS)
SELECT
    '<TYPE_PREFIX>-' || <primary_key>,
    '<EntityType>',
    <display_name>,
    OBJECT_CONSTRUCT('key1', val1, 'key2', val2, ...)
FROM <source_table>;
```

Pattern for loading edges:
```sql
INSERT INTO KG_EDGE (EDGE_ID, SRC_ID, DST_ID, EDGE_TYPE, WEIGHT, PROPS, EFFECTIVE_START)
SELECT
    '<EDGE_PREFIX>-' || <edge_key>,
    '<SRC_TYPE>-' || <src_fk>,
    '<DST_TYPE>-' || <dst_fk>,
    '<relationship_name>',
    <weight_or_1.0>,
    OBJECT_CONSTRUCT(...),
    <start_date>
FROM <relationship_source>;
```

### Step 2.3: Build Traversal Procedures

Three core procedures handle 90% of graph questions:

1. **FIND_PATH(source, target, max_hops)** — "How are X and Y connected?"
2. **GET_CONNECTED_ENTITIES(start, max_hops, edge_filter)** — "What's near this node?"
3. **GET_BLAST_RADIUS(start, max_hops)** — "What's affected if this node fails?"

All use recursive CTEs with:
- Cycle detection via `ARRAY_CONTAINS(dst::VARIANT, visited_path)`
- Depth limiting via `MAX_HOPS` parameter
- Bidirectional traversal via `V_KG_EDGE_BIDIR`

### Step 2.4: Extend the Agent

Add the KG semantic view as a second tool, and update orchestration instructions:

```yaml
tools:
  - tool_spec:
      type: "cortex_analyst_text_to_sql"
      name: "DomainAnalyst"
      description: "Use for aggregations, filtering, rankings, time-series"
  - tool_spec:
      type: "cortex_analyst_text_to_sql"
      name: "KGAnalyst"
      description: "Use for counting relationships, listing entity types, direct connections"

instructions:
  orchestration: |
    Use DomainAnalyst for standard data questions.
    Use KGAnalyst for graph structure questions.
    For multi-hop traversal, tell the user to call:
    - FIND_PATH(source_id, target_id, max_hops)
    - GET_CONNECTED_ENTITIES(start_id, max_hops, edge_filter)
    - GET_BLAST_RADIUS(start_id, max_hops)
```

---

## How to Derive the Initial Ontology

### Method 1: Schema-First Discovery (Most Common)

When: Client has Snowflake tables but no formal ontology.

1. **Introspect tables** — Run `DESCRIBE TABLE` on all candidate tables
2. **Classify each table:**
   - Tables with mostly unique rows → **Entities** (Customer, Product, Order)
   - Tables with two foreign keys → **Relationships** (junction/bridge tables)
   - Tables with low cardinality → **Lookups/Hierarchies** (Status, Category)
3. **Identify relationships** from foreign key columns (`*_ID`, `*_KEY`)
4. **Extract hierarchies** from columns that classify entities (CATEGORY, TYPE, TIER, REGION)
5. **Interview SMEs** — What do they call things? What synonyms exist? What's ambiguous?

### Method 2: OWL/RDF Import (When Formal Ontology Exists)

When: Client already has an industry ontology (FIBO for finance, SNOMED for healthcare, GS1 for supply chain).

1. Parse OWL/RDF/Turtle file to extract classes and properties
2. Map classes to existing Snowflake tables
3. Map object properties to relationships (edges)
4. Map data properties to facts/dimensions

### Method 3: Hybrid (Most Robust)

1. Start with Schema-First Discovery
2. Validate against industry ontology (if one exists)
3. Iterate with business users

---

## How to Iterate Over the Ontology

### The Iterate Cycle

```
Design → Deploy → Test → Measure → Refine → Redeploy
  ↑                                              |
  └──────────────────────────────────────────────┘
```

### Iteration Triggers

| Trigger | Action |
|---------|--------|
| Cortex Analyst generates wrong SQL | Add/fix verified queries (VQRs), improve column descriptions |
| User uses a term not in aliases | Add to ONT_ALIASES + semantic view synonyms |
| New entity type discovered | Add to ONT_ENTITY_TYPES, create view, update semantic view |
| New relationship needed | Add to ONT_RELATIONSHIP_TYPES, create view/edge, update semantic view |
| Agent picks wrong tool | Improve tool descriptions in agent spec |
| Metric returns wrong number | Check aggregation logic, verify join cardinality |
| Performance is slow | Check recursive CTE depth, add clustering, consider limiting MAX_HOPS |

### Version Control

- Store all DDL scripts in git
- Tag versions: `v1.0-initial`, `v1.1-added-supplier-entity`, etc.
- Never modify ontology metadata without updating the semantic view to match
- Use `CREATE OR REPLACE` for idempotent deployments

---

## How to Test the Ontology

### Level 1: Structural Tests (Automated)

```sql
-- All entity types have a source table (unless abstract)
SELECT * FROM ONT_ENTITY_TYPES
WHERE IS_ABSTRACT = FALSE AND SOURCE_TABLE IS NULL;
-- Should return 0 rows

-- All relationship types reference valid entity types
SELECT r.*
FROM ONT_RELATIONSHIP_TYPES r
LEFT JOIN ONT_ENTITY_TYPES e1 ON e1.ENTITY_NAME = r.FROM_ENTITY
LEFT JOIN ONT_ENTITY_TYPES e2 ON e2.ENTITY_NAME = r.TO_ENTITY
WHERE e1.ENTITY_NAME IS NULL OR e2.ENTITY_NAME IS NULL;
-- Should return 0 rows

-- All KG nodes have a matching type in metadata
SELECT n.NODE_TYPE, COUNT(*)
FROM KG_NODE n
LEFT JOIN ONT_ENTITY_TYPES e ON e.ENTITY_NAME = n.NODE_TYPE
WHERE e.ENTITY_NAME IS NULL
GROUP BY n.NODE_TYPE;
-- Should return 0 rows
```

### Level 2: Semantic View Tests (Semi-Automated)

Create a test dataset of 20-30 questions with expected SQL or expected results:

```sql
-- Test: "Total balance by tier" should return 4 rows (one per tier)
SELECT COUNT(*) FROM SEMANTIC_VIEW(
    <semantic_view>
    METRICS accounts.total_balance
    DIMENSIONS customers.customer_tier
);
-- Expected: 4
```

Use Cortex Analyst evaluation:
```sql
-- Run via agent evaluation framework
-- Measures: answer_correctness, tool_selection_accuracy, logical_consistency
```

### Level 3: Agent End-to-End Tests

Test the full agent with:
1. **Happy path questions** — should answer correctly
2. **Out-of-scope questions** — should refuse gracefully
3. **Ambiguous questions** — should clarify or state assumptions
4. **Graph questions (Phase B)** — should route to correct procedure

### Level 4: KG Traversal Tests (Phase B)

```sql
-- Test: path between known-connected entities should return results
CALL FIND_PATH('<known_source>', '<known_target>', 4);
-- Expected: at least 1 path

-- Test: blast radius from a well-connected node
CALL GET_BLAST_RADIUS('<hub_node>', 2);
-- Expected: multiple entities at distance 1 and 2

-- Test: disconnected nodes should return empty
CALL FIND_PATH('<isolated_node_a>', '<isolated_node_b>', 4);
-- Expected: 0 rows
```

---

## How to Know If It's Good Enough

### Minimum Viable Ontology Checklist

- [ ] All critical business entities are modeled (from Step 0.3)
- [ ] All user-facing business terms have aliases
- [ ] Semantic view answers 80%+ of sample questions correctly
- [ ] Agent routes to correct tool 90%+ of the time
- [ ] No SQL compilation errors on test suite
- [ ] Response latency <10s for P95 of questions
- [ ] Client SMEs validate entity/relationship definitions

### Signs You Need More Work

| Symptom | Root Cause | Fix |
|---------|-----------|-----|
| "I asked about X but got Y" | Missing alias or wrong synonym | Add to ONT_ALIASES + semantic view |
| "The number is wrong" | Incorrect aggregation or join fan-out | Fix metric definition or add grain constraint |
| "It can't answer this question" | Missing entity, relationship, or metric | Extend ontology + semantic view |
| "It's too slow" | Recursive CTE on dense graph | Limit MAX_HOPS, add clustering, pre-compute common paths |
| "It routes to wrong tool" | Tool description is ambiguous | Rewrite tool description with explicit "use for" / "do NOT use for" |
| "Different users get different answers" | Non-deterministic agent responses | Add verified queries (VQRs) for common questions |

---

## Improvements & Advanced Patterns

### After Phase A is Stable

1. **Add Verified Queries (VQRs)** — anchor the most common 10-20 questions with exact SQL
2. **Add Cortex Search** — for unstructured document/policy lookup alongside structured data
3. **Add Named Filters** — pre-built filters like "active customers only", "this quarter"
4. **Add Time Intelligence** — YoY, MoM, QTD metrics via semantic view patterns

### After Phase B is Stable

1. **Scheduled KG Refresh** — Snowflake Tasks to sync KG_NODE/KG_EDGE from source nightly
2. **Identity Resolution** — match entities across systems (DUNS numbers, email normalization)
3. **Pre-computed Paths** — for frequently-queried hubs, cache shortest paths
4. **Graph Analytics via SPCS** — deploy NetworkX for PageRank, community detection, centrality
5. **Temporal Graph Queries** — "What did the relationship look like on date X?"

### What This Architecture Does NOT Solve

| Gap | Why | Alternative |
|-----|-----|-------------|
| Real-time streaming ingestion | KG is batch-loaded | Snowpipe + Snowflake Tasks for near-real-time |
| Fuzzy entity matching | Deterministic joins only | Cortex AI functions (EMBED, SIMILARITY) for ML matching |
| Inference / reasoning rules | No OWL reasoner | Pre-compute inferred relationships as additional edges |
| Cross-account federation | Single Snowflake account | Data sharing or Iceberg tables |
| Access control on graph | KG tables have flat RBAC | Apply row-access policies on KG_NODE/KG_EDGE |

---

## Quick-Start Template

To implement for a new domain, copy and adapt:

```
1. CREATE SCHEMA <domain>_ontology
2. Load/reference source tables
3. CREATE TABLE ONT_ENTITY_TYPES      → populate from Step 0.3 entity list
4. CREATE TABLE ONT_RELATIONSHIP_TYPES → populate from Step 0.3 relationship list
5. CREATE TABLE ONT_HIERARCHIES       → populate from Step 0.3 hierarchy list
6. CREATE TABLE ONT_ALIASES           → populate from SME interviews
7. CREATE VIEW V_<each_entity>        → one per concrete entity
8. CREATE VIEW V_<each_relationship>  → one per relationship type
9. CREATE SEMANTIC VIEW               → facts + dimensions + metrics
10. CREATE AGENT                      → with semantic view tool

If Phase B needed:
11. CREATE TABLE KG_NODE + KG_EDGE    → load from source
12. CREATE VIEW V_KG_EDGE_BIDIR      → for traversal
13. CREATE PROCEDURE FIND_PATH       → path finding
14. CREATE PROCEDURE GET_CONNECTED_ENTITIES → neighborhood
15. CREATE PROCEDURE GET_BLAST_RADIUS → impact analysis
16. Extend agent with KG tool
```

---

## Reference: Financial Services Demo

All code for the working example is deployed in `COCO_RD.FINSERV_ONTOLOGY`. Use it as a reference implementation:

| Component | Object Name |
|-----------|-------------|
| Phase A Agent | `FINSERV_AGENT` |
| Phase B Agent | `FINSERV_AGENT_KG` |
| Semantic View | `FINSERV_SEMANTIC_VIEW` |
| KG Semantic View | `FINSERV_KG_SEMANTIC_VIEW` |
| Path Finding | `FIND_PATH(source, target, hops)` |
| Neighborhood | `GET_CONNECTED_ENTITIES(start, hops, filter)` |
| Impact Analysis | `GET_BLAST_RADIUS(start, hops)` |
