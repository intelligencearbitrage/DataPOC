# Plan: Financial Services Ontology on Snowflake

## Context

The user wants to build a working ontology example on Snowflake to understand the concepts from the Ontology on Snowflake blog series. The approach is two-phase: start lightweight (Phase A) to understand ontology metadata, semantic views, and Cortex Agent, then extend to a full knowledge graph (Phase B) to see the incremental value of graph-structured data and traversal.

**Target:** `COCO_RD.FINSERV_ONTOLOGY`  
**Data size:** Medium (~500 customers, 1000 accounts, 5000 transactions)  
**No external software required** — everything runs as native Snowflake SQL, semantic views, and Cortex Agent.

## Architecture

```mermaid
flowchart TB
    subgraph phaseA [Phase A: Lightweight Ontology]
        SRC[Source Tables] --> ONT[Ontology Metadata Tables]
        SRC --> VIEWS[Convenience Views]
        ONT --> ABSTRACT[Abstract Views]
        VIEWS --> SV[Semantic View]
        ABSTRACT --> SV
        SV --> AGENT_A[Cortex Agent v1]
    end

    subgraph phaseB [Phase B: Full KG Stack]
        SRC2[Source Tables] --> KG[KG_NODE + KG_EDGE]
        KG --> PROCS[Traversal Procedures]
        KG --> KG_SV[KG Semantic View]
        PROCS --> AGENT_B[Cortex Agent v2]
        KG_SV --> AGENT_B
        SV2[Phase A Semantic View] --> AGENT_B
    end
```

## Domain Model

### Entities (Node Types)

| Entity | Description | Source Table |
|--------|-------------|-------------|
| Customer | Individual or corporate client | CUSTOMERS |
| Account | Checking, savings, brokerage, loan | ACCOUNTS |
| Instrument | Stock, bond, mutual fund, ETF | INSTRUMENTS |
| Branch | Physical office location | BRANCHES |
| Transaction | Deposit, withdrawal, transfer, trade | TRANSACTIONS |

### Relationships (Edge Types)

| Relationship | From | To | Description |
|-------------|------|-----|-------------|
| owns | Customer | Account | Customer owns an account |
| holds | Account | Instrument | Brokerage account holds instruments |
| transacts_at | Customer | Branch | Customer's primary branch |
| transfers_to | Account | Account | Money transfer between accounts |
| beneficiary_of | Customer | Customer | Named beneficiary |
| guarantor_of | Customer | Account | Loan guarantor |

### Hierarchies

| Hierarchy | Levels | Example |
|-----------|--------|---------|
| Instrument taxonomy | Asset Class > Category > Sub-category > Instrument | Equity > Large Cap > Technology > AAPL |
| Customer tier | Tier > Sub-tier | Premium > Private Banking > Ultra HNW |
| Geography | Region > State > City > Branch | Southwest > Texas > Houston > Main St |

## Implementation Steps

### Phase A: Lightweight Ontology

#### Step 1: Create schema and sample data

Create `COCO_RD.FINSERV_ONTOLOGY` schema. Generate synthetic data:

- `CUSTOMERS` (~500 rows): customer_id, name, customer_type (individual/corporate), tier, city, state, created_date
- `ACCOUNTS` (~1000 rows): account_id, customer_id, account_type, balance, opened_date, status
- `TRANSACTIONS` (~5000 rows): txn_id, account_id, txn_type, amount, txn_date, counterparty_account_id
- `INSTRUMENTS` (~100 rows): instrument_id, name, ticker, asset_class, category, sub_category
- `BRANCHES` (~20 rows): branch_id, name, city, state, region
- `ACCOUNT_HOLDINGS` (~2000 rows): account_id, instrument_id, quantity, market_value
- `CUSTOMER_RELATIONSHIPS` (~200 rows): from_customer_id, to_customer_id, relationship_type

#### Step 2: Build ontology metadata tables

Declarative metadata that defines what the business concepts mean:

- `ONT_ENTITY_TYPES`: id, entity_name, description, source_table, identifier_column
- `ONT_RELATIONSHIP_TYPES`: id, relationship_name, from_entity, to_entity, cardinality, description
- `ONT_HIERARCHIES`: id, hierarchy_name, entity_type, level_num, level_name, parent_level
- `ONT_ALIASES`: id, canonical_name, alias, context

This is the "control plane" — meaning defined as configuration, not code.

#### Step 3: Create convenience and abstract views

Convenience views (one per entity, extracting meaningful columns):
- `V_CUSTOMER`, `V_ACCOUNT`, `V_TRANSACTION`, `V_INSTRUMENT`, `V_BRANCH`

Relationship views:
- `V_OWNS` (Customer -> Account join)
- `V_HOLDS` (Account -> Instrument join via ACCOUNT_HOLDINGS)
- `V_TRANSFERS_TO` (Account -> Account via TRANSACTIONS where type = 'transfer')

Abstract views (cross-entity reasoning):
- `VW_ONT_FINANCIAL_ENTITY` — unions Customer + Corporate entities
- `VW_ONT_ASSET` — unions Account + Instrument as "anything with a value"

#### Step 4: Build semantic view

Author a Cortex Analyst semantic view YAML:
- Entities: customers, accounts, instruments, transactions
- Relationships: customer owns account, account holds instrument
- Metrics: total_balance, total_aum, transaction_volume, avg_transaction_size
- Dimensions: customer_tier, account_type, asset_class, region, state
- Verified queries for common patterns

#### Step 5: Create Cortex Agent (lightweight)

Deploy agent with:
- One semantic view tool (for SQL-expressible questions)
- Agent description and routing instructions
- Test with questions like:
  - "What is the total AUM for premium customers?"
  - "Which customers hold technology stocks?"
  - "Show transaction volume by branch for the last quarter"

### Phase B: Full KG Stack

#### Step 6: Build KG_NODE and KG_EDGE tables

```sql
-- Universal node storage
KG_NODE (NODE_ID, NODE_TYPE, NAME, PROPS VARIANT, TS_INGESTED)

-- Universal edge storage  
KG_EDGE (EDGE_ID, SRC_ID, DST_ID, EDGE_TYPE, WEIGHT, PROPS VARIANT, EFFECTIVE_START, EFFECTIVE_END)
```

Load all entities as nodes, all relationships as typed edges.

#### Step 7: Build graph traversal procedures

Pure SQL with recursive CTEs:
- `GET_DESCENDANTS(node_id, max_depth)` — expand hierarchy downward
- `GET_ANCESTORS(node_id)` — trace upward to root
- `FIND_PATH(source_id, target_id, max_hops)` — find connection between two entities
- `GET_CONNECTED_ENTITIES(node_id, edge_type, hops)` — neighborhood expansion

#### Step 8: Extend agent and compare

Add to the Cortex Agent:
- KG semantic view (for graph-specific queries)
- Traversal tools as Snowflake functions

Comparison queries that show KG value:
- "How are Customer A and Customer B connected?" (multi-hop traversal)
- "What's the blast radius if account X is compromised?" (fan-out from a node)
- "Find all customers within 2 degrees of this high-risk entity" (neighborhood)
- "Which customers form a natural community?" (clustering)

## Verification

After each phase:
- Run sample queries to confirm data integrity
- Test semantic view with natural language questions via Cortex Analyst
- Test Cortex Agent end-to-end with business questions
- Compare Phase A vs Phase B responses for the same questions

## Critical Files

All artifacts will be SQL scripts and YAML files. Key outputs:

- Schema DDL + sample data INSERT statements (Step 1)
- Ontology metadata DDL + seed data (Step 2)
- View definitions (Step 3)
- Semantic view YAML (Step 4)
- Cortex Agent configuration (Steps 5 and 8)
- KG tables + traversal procedures (Steps 6-7)
