# Plan: Ontology Builder Toolkit (CoCo)

## Context

### What we're building
A reusable **CoCo toolkit** that generates the full Ontology-on-Snowflake stack from client source tables. We're adapting the `coco-toolkit-template` framework (4-phase pipeline: Research, Plan, Build, Review) to produce ontology-specific deliverables.

### Source framework
Located at: `c:\Users\rudandekar\Downloads\Claude-Code-toolkit-develop\coco-toolkit-template\`

Key framework components to reuse as-is:
- `CLAUDE.md` — project instructions (adapt for ontology context)
- `GUARDRAILS.yaml` — quality rules (customize for ontology checks)
- `scripts/base_parser.py`, `scripts/base_generator.py`, `scripts/base_validator.py`, `scripts/build_all.py`, `scripts/utils.py` — pipeline infrastructure (copy as-is)
- `.snowflake/cortex/skills/` — 10 CoCo skills (copy, adapt descriptions)
- `guardrails/` — enforcement scripts (copy as-is)

### What changes
- `prompts.md` — filled with ontology-builder requirements
- `knowledgebase/` — ontology-specific reference materials (DDL templates, patterns, decision rules)
- `GUARDRAILS.yaml` — ontology-specific content standards and checks
- `CLAUDE.md` — ontology-domain context added
- Skills — minimal edits to descriptions for ontology context

### Target location
`c:\Users\rudandekar\Downloads\CoCo\Ontology\ontology-builder-toolkit\`

---

## Architecture

```mermaid
flowchart TB
    subgraph inputs_sub [inputs/]
        DDL[Client DDL exports]
        GLOSSARY[Business glossary]
        QUESTIONS[Business questions]
    end

    subgraph kb [knowledgebase/]
        TEMPLATES[DDL templates for ONT tables]
        PATTERNS[Ontology design patterns]
        DECISION[Lightweight vs KG decision rules]
        EXAMPLES[FinServ reference output]
        SVPATTERNS[Semantic view patterns]
    end

    subgraph phase1 [Phase 1: Research]
        PROFILER[parse_schema.py - profile tables]
        CLASSIFIER[Classify: entity/relationship/lookup]
    end

    subgraph phase2 [Phase 2: Plan]
        ONTDESIGN[Proposed ontology design]
        DECISION_OUT[Phase A vs A+B recommendation]
    end

    subgraph phase3 [Phase 3: Build]
        GEN_META[generate_ontology_metadata.py]
        GEN_VIEWS[generate_views.py]
        GEN_SV[generate_semantic_view.py]
        GEN_AGENT[generate_agent.py]
        GEN_KG[generate_kg.py - optional]
    end

    subgraph output_sub [output/]
        SQL_META[01_ontology_metadata.sql]
        SQL_VIEWS[02_views.sql]
        SQL_SV[03_semantic_view.sql]
        SQL_AGENT[04_agent.sql]
        SQL_KG[05_kg_tables.sql - optional]
        SQL_PROCS[06_kg_procedures.sql - optional]
    end

    inputs_sub --> phase1
    kb --> phase1
    phase1 --> phase2
    kb --> phase2
    phase2 --> phase3
    kb --> phase3
    phase3 --> output_sub
```

---

## Implementation Steps

### Step 1: Copy the coco-toolkit-template

Copy the entire `coco-toolkit-template/` directory to `ontology-builder-toolkit/`. This gives us the full framework skeleton with all skills, guardrails, and base scripts.

### Step 2: Fill prompts.md with ontology-builder requirements

This is the master requirements document. It tells the pipeline what to build:
- **Objective**: Build ontology metadata + semantic view + agent for {domain}
- **Source Materials**: knowledgebase (DDL templates, patterns) + inputs (client DDL, glossary)
- **Deliverables**: 4-6 SQL scripts in `output/`
- **Components**: schema profiler, metadata generator, view generator, semantic view generator, agent generator, (optional) KG generator
- **Success Criteria**: all SQL compiles, all entities mapped, semantic view answers test questions, agent routes correctly

### Step 3: Populate knowledgebase/ with ontology reference materials

Create 5-6 reference files:
- `ontology_ddl_templates.sql` — CREATE TABLE statements for ONT_ENTITY_TYPES, ONT_RELATIONSHIP_TYPES, ONT_HIERARCHIES, ONT_ALIASES, KG_NODE, KG_EDGE
- `ontology_design_patterns.md` — rules for entity classification, relationship naming, hierarchy design, alias mapping
- `decision_framework.md` — when to use lightweight vs full KG (from our guide)
- `semantic_view_patterns.sql` — CREATE SEMANTIC VIEW DDL examples with TABLES, RELATIONSHIPS, FACTS, DIMENSIONS, METRICS
- `agent_spec_patterns.yaml` — CREATE AGENT FROM SPECIFICATION examples
- `finserv_reference_output/` — the actual SQL we produced for the FinServ demo (as a gold-standard reference)

### Step 4: Customize GUARDRAILS.yaml for ontology domain

Add ontology-specific rules:
- Content standards for generated SQL (DDL must compile, naming conventions)
- Ontology-specific validation checks (every entity needs source table, all relationships reference valid entities, no orphan nodes in KG)
- Phase gate additions (ontology design must be approved before generation)
- Size limits adjusted for SQL output

### Step 5: Customize CLAUDE.md with ontology context

Add a section explaining:
- What the ontology stack is (layers 1-5)
- How the pipeline maps to ontology construction
- Snowflake-specific guidance (semantic view syntax, agent syntax, recursive CTE patterns)
- Domain-adaptation guidance (how to profile a new client schema)

### Step 6: Write the generator scripts

The core deliverables. Each script reads from `plans/` (populated by Phase 2) and writes SQL to `output/`:

1. **`scripts/parse_schema.py`** (BaseParser subclass)
   - Reads client DDL files from `inputs/`
   - Extracts: table names, columns, data types, FKs, primary keys
   - Classifies tables as: entity, relationship/junction, lookup/hierarchy
   - Outputs structured analysis YAML

2. **`scripts/generate_ontology_metadata.py`** (BaseGenerator subclass)
   - Reads the plan (entity types, relationships, hierarchies, aliases)
   - Produces `output/01_ontology_metadata.sql` (CREATE TABLE + INSERT statements)

3. **`scripts/generate_views.py`** (BaseGenerator subclass)
   - Reads the plan (convenience views, relationship views, abstract views)
   - Produces `output/02_views.sql` (CREATE VIEW statements)

4. **`scripts/generate_semantic_view.py`** (BaseGenerator subclass)
   - Reads the plan (tables, relationships, facts, dimensions, metrics)
   - Produces `output/03_semantic_view.sql` (CREATE SEMANTIC VIEW DDL)

5. **`scripts/generate_agent.py`** (BaseGenerator subclass)
   - Reads the plan (agent instructions, tools, sample questions)
   - Produces `output/04_agent.sql` (CREATE AGENT DDL)

6. **`scripts/generate_kg.py`** (BaseGenerator subclass, optional)
   - Only invoked if plan recommends Phase B (KG)
   - Produces `output/05_kg_tables.sql` and `output/06_kg_procedures.sql`

7. **`scripts/validate_ontology.py`** (BaseValidator subclass)
   - Checks: all entities have source tables, relationships valid, DDL compiles
   - Produces validation report

### Step 7: Test against FinServ domain

Use the FinServ data we already built as a validation target:
- Put FinServ DDL exports in `inputs/`
- Run the full pipeline
- Compare `output/` against what we manually deployed to `COCO_RD.FINSERV_ONTOLOGY`
- This proves the toolkit produces equivalent output

---

## Verification

1. **Structural**: All framework files present, skills load, `python scripts/build_all.py` runs without error on empty state
2. **Unit**: Each generator script produces valid SQL when given a test plan YAML
3. **Integration**: Full pipeline (Research → Plan → Build → Review) produces deployable SQL for the FinServ domain
4. **Compilation**: Generated SQL validates with `snowflake_sql_execute(sql, only_compile=true)`
5. **End-to-end**: Deploy generated output to Snowflake and verify semantic view + agent work

---

## Critical Files

- `ontology-builder-toolkit/prompts.md` — Defines what the toolkit builds (the "contract")
- `ontology-builder-toolkit/knowledgebase/ontology_ddl_templates.sql` — Gold-standard DDL patterns
- `ontology-builder-toolkit/scripts/parse_schema.py` — Core parser that profiles client data
- `ontology-builder-toolkit/scripts/generate_semantic_view.py` — Most complex generator (semantic view DDL)
- `ontology-builder-toolkit/GUARDRAILS.yaml` — Ontology-specific quality rules
