# Ontology on Snowflake: Design Guide & Decision Framework

**Version:** 1.0 | **Date:** 2026-06-12 | **Authors:** Deloitte Data & AI Practice  
**Audience:** Client-facing consultants, architects, and technical leads

---

## Executive Summary

Enterprise AI agents fail not because of bad models, but because of a **Context Gap** — AI systems reason over raw, fragmented data instead of a cohesive business model. Ontology on Snowflake bridges this gap by modeling business concepts (entities, relationships, hierarchies) as metadata *within* Snowflake, enabling Cortex Analyst and Cortex Agent to deliver business-aware insights without external ontology engines.

This guide covers:
1. **Two architecture options** — Lightweight Ontology vs. Full Knowledge Graph
2. **When to use each** — decision framework with trade-offs
3. **How to implement** — step-by-step playbook for new client domains
4. **How to test and iterate** — quality gates, benchmarks, and improvement patterns

---

## 1. The Two Architectures

### Option A: Lightweight Ontology (Metadata + Semantic Views + Agent)

```
Source Tables → Ontology Metadata Tables → Convenience/Abstract Views → Semantic View → Cortex Agent
```

**What it is:** A declarative metadata layer that defines what business concepts mean, paired with views that expose those concepts, a semantic view for Cortex Analyst, and a Cortex Agent for orchestration.

**No data duplication.** Views sit on top of existing tables. The ontology metadata tables are configuration — they declare meaning, not store data.

#### Data Structures

| Object | Purpose | Example |
|--------|---------|---------|
| `ONT_ENTITY_TYPES` | Declares what entities exist, their source tables, parent types | "Customer is a FinancialEntity, sourced from CUSTOMERS table" |
| `ONT_RELATIONSHIP_TYPES` | Declares how entities connect, cardinality, inverse names | "Customer *owns* Account (one-to-many), inverse: owned_by" |
| `ONT_HIERARCHIES` | Declares classification levels for each entity type | "Instrument: Asset Class > Category > Sub-Category > Security" |
| `ONT_ALIASES` | Maps business synonyms to canonical names | "client" = Customer, "portfolio" = Account (when type=Brokerage) |
| Convenience Views | One per entity, extracting meaningful columns from source | `V_CUSTOMER`, `V_ACCOUNT`, `V_INSTRUMENT` |
| Relationship Views | Materialize joins between entities | `V_OWNS` (Customer→Account), `V_HOLDS` (Account→Instrument) |
| Abstract Views | Cross-entity unions for higher-level reasoning | `VW_ONT_FINANCIAL_ENTITY` (all customers regardless of type) |
| Semantic View | Cortex Analyst interface with metrics, dimensions, facts | Natural language → SQL translation |
| Cortex Agent | Orchestration layer that routes questions to the right tool | "What's our total AUM by region?" → FinServAnalyst tool |

#### What It Can Answer
- Aggregations: "Total balance by customer tier"
- Filtering: "Which Premium customers hold technology stocks?"
- Rankings: "Top 10 customers by AUM"
- Time-series: "Transaction volume by month"
- Cross-entity joins: "Holdings by asset class for Private Banking customers"

#### What It Cannot Answer
- Multi-hop traversal: "How are customer A and customer B connected?"
- Impact analysis: "What's affected if this account is compromised?"
- Network analysis: "Find all customers within 2 degrees of this entity"
- Community detection: "Which customers form natural clusters?"

---

### Option B: Full Knowledge Graph (KG_NODE + KG_EDGE + Traversal)

```
Source Tables → KG_NODE / KG_EDGE Tables → Recursive CTE Procedures → KG Semantic View → Extended Agent
         ↘                                                                                    ↗
          → Ontology Metadata → Convenience Views → Semantic View (reused from Phase A) ──→
```

**What it adds on top of Phase A:** A universal node-edge graph structure that enables multi-hop relationship traversal via recursive CTEs.

#### Additional Data Structures

| Object | Purpose | Schema |
|--------|---------|--------|
| `KG_NODE` | Universal entity storage — one row per entity | NODE_ID, NODE_TYPE, NAME, PROPS (VARIANT) |
| `KG_EDGE` | Universal relationship storage — one row per connection | EDGE_ID, SRC_ID, DST_ID, EDGE_TYPE, WEIGHT, PROPS, EFFECTIVE_START/END |
| `V_KG_EDGE_BIDIR` | Bidirectional edge view for traversal in both directions | Unions forward + inverse edges |
| `FIND_PATH` | Stored procedure: finds connection paths between two nodes | Recursive CTE with cycle detection |
| `GET_CONNECTED_ENTITIES` | Stored procedure: expands neighborhood N hops from a node | Recursive CTE with edge-type filtering |
| `GET_BLAST_RADIUS` | Stored procedure: impact analysis from a starting node | Bidirectional recursive CTE |

#### What It Adds (Beyond Phase A)
- Path finding: "How is customer 42 connected to customer 156?" → Found via shared instrument holdings
- Blast radius: "If account 677 is compromised, what's affected?" → 82 entities within 2 hops
- Neighborhood: "Show everything within 2 hops of this customer" → Accounts, instruments, branches, related customers
- Temporal relationships: Track when relationships started/ended

---

## 2. Decision Framework: Which Architecture?

### Use Lightweight (Phase A) When:

| Signal | Why |
|--------|-----|
| Primary use case is analytics/reporting | Aggregations, filters, rankings are all SQL-expressible |
| Data relationships are simple (star/snowflake schema) | Standard joins suffice |
| No requirement for "how are X and Y connected?" questions | No graph traversal needed |
| Speed to value is priority | Phase A deploys in hours, not days |
| Client's data is already well-modeled | Good dimension/fact tables exist |
| Budget/timeline is constrained | Less infrastructure, less testing |

### Add Full KG (Phase B) When:

| Signal | Why |
|--------|-----|
| Domain is relationship-heavy | Supply chain, fraud, patient journeys, org charts |
| Users ask "how are things connected?" | Multi-hop traversal is the core question |
| Impact/risk analysis is required | "What breaks if this supplier goes down?" |
| Identity resolution is needed | Same entity appears differently across systems |
| Hierarchy expansion beyond simple parent-child | Transitive closure, ancestor/descendant at arbitrary depth |
| Network analysis matters | Centrality, clustering, community detection |

### Decision Matrix

```
                          Relationship Complexity
                    Low                          High
                ┌──────────────────┬──────────────────────┐
    High        │                  │                      │
    Query       │   Phase A        │   Phase B            │
    Volume      │   (Semantic View │   (Full KG +         │
                │    handles it)   │    Semantic View)     │
                ├──────────────────┼──────────────────────┤
    Low         │                  │                      │
    Query       │   Phase A        │   Phase B            │
    Volume      │   (sufficient)   │   (if traversal      │
                │                  │    questions exist)   │
                └──────────────────┴──────────────────────┘
```

---

## 3. Trade-offs Comparison

| Dimension | Phase A (Lightweight) | Phase B (Full KG) |
|-----------|----------------------|-------------------|
| **Deployment time** | Hours | 1-2 days additional |
| **Data duplication** | None (views over source) | Yes (KG_NODE/KG_EDGE copy data) |
| **Storage cost** | Minimal (metadata only) | Proportional to entity + relationship count |
| **Maintenance** | Low — views auto-reflect source changes | Medium — KG tables need refresh when source changes |
| **Query types** | Aggregation, filtering, ranking, time-series | + Path finding, blast radius, neighborhood expansion |
| **Query performance** | Fast (standard SQL optimizer) | Varies — recursive CTEs can be expensive on large graphs |
| **Complexity** | Low | Medium-high (recursive CTEs, VARIANT columns, bidirectional views) |
| **Agent accuracy** | High for relational questions | High for relational + good for graph (but graph routing is harder) |
| **Hallucination risk** | Low — SQL generation is deterministic | Slightly higher — agent must correctly decide SQL vs. procedure |
| **Scalability** | Excellent (Snowflake handles it) | Good to millions of nodes; recursive CTEs have depth limits |
| **External tools needed** | None | None for basic; SPCS/NetworkX for advanced algorithms |

### Pros & Cons Summary

#### Phase A: Lightweight
**Pros:**
- Zero data duplication
- Fast to implement
- Easy to maintain (views update automatically)
- Cortex Analyst handles SQL generation well
- Low hallucination risk

**Cons:**
- Cannot answer relationship/graph questions
- No multi-hop traversal
- No impact analysis
- Limited to what SQL JOINs can express

#### Phase B: Full KG
**Pros:**
- Answers all Phase A questions PLUS graph questions
- Multi-hop path finding between any entities
- Impact/blast radius analysis
- Temporal relationship tracking
- Foundation for advanced analytics (if SPCS/NetworkX added later)

**Cons:**
- Data duplication (must sync KG tables with source)
- Recursive CTEs can be expensive on very large graphs
- More complex agent orchestration (more tools = more routing decisions)
- Slightly higher hallucination risk in tool selection
- Maintenance overhead for KG refresh

---

## 4. Addressing Hallucinations & Quality Risks

### Where Hallucinations Can Occur

| Risk Area | Cause | Mitigation |
|-----------|-------|------------|
| **Wrong tool selection** | Agent uses semantic view for a graph question or vice versa | Clear tool descriptions with "use for" / "do NOT use for" guidance |
| **Fabricated entities** | Agent invents customer names or IDs | Verified queries (VQRs) anchor common patterns; agent instructions say "only return data from queries" |
| **Incorrect aggregation** | SUM when should be AVG, or wrong granularity | Semantic view metrics pre-define correct aggregations; AI_SQL_GENERATION instructions |
| **Ambiguous terms** | "Revenue" means different things to different teams | ONT_ALIASES table + semantic view COMMENT fields resolve ambiguity |
| **Stale KG data** | Source table updated but KG not refreshed | Scheduled refresh tasks; add TS_INGESTED checks |
| **Recursive CTE runaway** | Unbounded traversal on dense graph | MAX_HOPS parameter with hard limits; cycle detection via ARRAY_CONTAINS |

### Deterministic vs. Non-Deterministic Questions

| Question Type | Determinism | Approach |
|---------------|-------------|----------|
| "Total balance by tier" | Fully deterministic | Semantic view metric — same SQL every time |
| "Which customers hold AAPL?" | Fully deterministic | Semantic view filter — exact match |
| "How are X and Y connected?" | Deterministic (given the graph) | Stored procedure — recursive CTE, ordered by depth |
| "What should we do about risk?" | Non-deterministic (requires judgment) | Agent response instruction — state assumptions, present data, do not recommend actions |
| "Summarize our portfolio" | Semi-deterministic | Semantic view provides data; agent formatting may vary |

### Performance Considerations

| Concern | Phase A | Phase B |
|---------|---------|---------|
| Simple aggregation | <2s (standard SQL) | Same (uses Phase A semantic view) |
| Multi-table join (5+ tables) | 2-5s | Same |
| Recursive CTE (depth 2) | N/A | 2-5s for <10K nodes |
| Recursive CTE (depth 4) | N/A | 5-30s depending on graph density |
| Blast radius (dense node) | N/A | Can return thousands of rows; limit with MAX_HOPS |
| Full graph algorithms (PageRank) | N/A | Requires SPCS/NetworkX — seconds to minutes |

---

## 5. Metrics for "Good Enough"

### Phase A Quality Gates

| Metric | Target | How to Measure |
|--------|--------|----------------|
| Cortex Analyst accuracy | >85% on 20+ test questions | Run evaluation dataset against semantic view |
| Tool routing accuracy | >90% correct tool selection | Agent evaluation with `tool_selection_accuracy` metric |
| Query execution success | >95% (no SQL errors) | Run test suite, count failures |
| Response latency P95 | <10s | Monitor agent response times |
| Alias coverage | All common business terms mapped | Review ONT_ALIASES vs. actual user vocabulary |
| Metric correctness | 100% match to manual calculation | Spot-check 5-10 metrics against direct SQL |

### Phase B Quality Gates (in addition to above)

| Metric | Target | How to Measure |
|--------|--------|----------------|
| Path finding success | >90% for connected entities | Test with known-connected pairs |
| Blast radius accuracy | Complete at depth N | Compare recursive CTE results to manual trace |
| KG coverage | >95% of source entities loaded | COUNT(KG_NODE) vs COUNT(source tables) |
| KG freshness | <24h lag from source | Compare TS_INGESTED to source update timestamps |
| Graph query latency P95 | <30s for depth-3 traversal | Benchmark on representative queries |

---

## 6. When to Graduate from Phase A to Phase B

Start with Phase A. Add Phase B when any of these triggers fire:

1. **User asks graph questions** — "How are X and Y related?" comes up repeatedly
2. **Compliance requires impact analysis** — "Show everything affected by this entity"
3. **Fraud/risk use case emerges** — Need to find hidden connections between entities
4. **Identity resolution needed** — Same real-world entity appears in multiple source systems
5. **Hierarchy depth exceeds simple parent-child** — Need transitive closure at arbitrary depth

Phase B is **additive** — it does not replace Phase A. The semantic view continues to handle 80% of questions. The KG handles the remaining 20%.

---

## Next Steps

See the **Implementation Playbook** (appendix document) for:
- Step-by-step guide to implementing for a new client domain
- Data profiling methodology
- Ontology derivation process
- Iteration and testing workflow
- Production readiness checklist
