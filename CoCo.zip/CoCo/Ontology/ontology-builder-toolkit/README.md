# Ontology Builder Toolkit

A CoCo-native toolkit that generates the complete **Ontology-on-Snowflake** stack from client source table DDL definitions.

## What It Produces

Given source table DDL + a business glossary + business questions, this toolkit generates:

| Output | Description |
|--------|-------------|
| `01_ontology_metadata.sql` | ONT_ENTITY_TYPES, ONT_RELATIONSHIP_TYPES, ONT_HIERARCHIES, ONT_ALIASES |
| `02_convenience_views.sql` | V_* entity views, relationship views, VW_ONT_* abstract views |
| `03_semantic_view.sql` | CREATE SEMANTIC VIEW with full Cortex Analyst support |
| `04_cortex_agent.sql` | CREATE AGENT with tool routing |
| `05_kg_tables.sql` | KG_NODE + KG_EDGE + data loading (optional, Phase B) |
| `06_kg_procedures.sql` | FIND_PATH, GET_CONNECTED_ENTITIES, GET_BLAST_RADIUS (optional) |

## Quick Start

### Path A: From a Snowflake Schema (Most Common)

```bash
# Auto-generate inputs from a live Snowflake schema
python scripts/generate_inputs_from_schema.py --database MY_DB --schema MY_SCHEMA --ontology-name DOMAIN --path both

# Review and enhance the generated drafts:
#   inputs/config.yaml         → confirm path choice
#   inputs/business_glossary.yaml → add real synonyms from SME interviews
#   inputs/business_questions.yaml → replace templates with actual user questions

# Then open in CoCo Desktop and say "start project"
```

### Path B: From an OWL Ontology (Protege/Industry Standard)

```bash
# Place your .owl or .ttl file in inputs/
cp my_ontology.owl inputs/

# Also provide the source DDL (so the pipeline knows which tables to map to)
python scripts/generate_inputs_from_schema.py --database MY_DB --schema MY_SCHEMA

# Parse the OWL file to extract entity/relationship candidates
python scripts/parse_owl.py

# Open in CoCo Desktop and say "start project"
# The planning phase will merge OWL analysis + schema analysis
```

### Path C: Manual (Small Schemas Only)

1. Fill `inputs/config.yaml` with target database/schema/ontology name
2. Put client DDL in `inputs/source_ddl.sql`
3. Fill `inputs/business_glossary.yaml` with domain terms
4. Fill `inputs/business_questions.yaml` with expected questions
5. Open in CoCo Desktop and say **"start project"**
6. Follow the 4-phase pipeline (Research → Plan → Build → Review)
7. Deploy generated SQL from `output/` to Snowflake

## Structure

```
ontology-builder-toolkit/
├── CLAUDE.md                 # CoCo project instructions
├── GUARDRAILS.yaml           # Quality rules and phase gates
├── prompts.md                # What the toolkit builds (contract)
├── inputs/                   # YOUR source data (immutable)
│   ├── config.yaml           # Target environment config
│   ├── source_ddl.sql        # Client table DDL
│   ├── business_glossary.yaml
│   └── business_questions.yaml
├── knowledgebase/            # Reference patterns (immutable)
│   ├── ontology_ddl_templates.sql
│   ├── ontology_design_patterns.md
│   ├── decision_framework.md
│   ├── semantic_view_patterns.sql
│   ├── agent_spec_patterns.yaml
│   └── naming_conventions.md
├── scripts/                  # Generator scripts
│   ├── base_parser.py        # ABC for parsers
│   ├── base_generator.py     # ABC for generators
│   ├── base_validator.py     # ABC for validators
│   ├── build_all.py          # Master orchestrator
│   ├── utils.py              # Shared utilities
│   ├── generate_inputs_from_schema.py  # NEW: Auto-generates inputs/ from live Snowflake schema
│   ├── parse_schema.py       # Schema profiler (from DDL files)
│   ├── parse_owl.py          # NEW: OWL/RDF/Turtle parser (from Protege)
│   ├── generate_ontology_metadata.py
│   ├── generate_views.py
│   ├── generate_semantic_view.py
│   ├── generate_agent.py
│   ├── generate_kg.py        # Optional (Phase B)
│   └── validate_ontology.py
├── .snowflake/cortex/skills/ # CoCo pipeline skills
├── guardrails/               # Enforcement scripts
├── research/                 # Phase 1 output
├── plans/                    # Phase 2 output
├── output/                   # Generated SQL (Phase 3)
└── testscripts/              # Validation reports (Phase 4)
```

## Three Entry Paths

| Path | Starting Point | Automation Level |
|------|---------------|-----------------|
| **A: Schema Introspection** | Live Snowflake schema | ~70% automated (DDL + profiling) |
| **B: OWL Import** | Protege .owl/.ttl file | ~60% automated (class/property extraction) |
| **C: Manual** | Hand-written YAML/SQL | 0% automated (smallest schemas only) |

All three paths converge at the same pipeline (Research → Plan → Build → Review) and produce the same output.

## Two Architecture Paths

- **Lightweight** (`path: lightweight`): Ontology metadata + views + semantic view + agent
- **Full KG** (`path: both`): All of the above + KG_NODE/KG_EDGE + traversal procedures

See `knowledgebase/decision_framework.md` for when to use which.

## Framework

Built on the CoCo Toolkit Template (4-phase pipeline):
1. **Research**: Profile source schema, classify tables
2. **Plan**: Design ontology (entities, relationships, hierarchies)
3. **Build**: Generate SQL scripts
4. **Review**: Validate output, check coverage
