# Ontology Builder Toolkit — Project Instructions (CLAUDE.md)

## Role & Context

You are operating within the **Ontology Builder Toolkit** — a CoCo-native framework that generates the complete Ontology-on-Snowflake stack from client source tables. Your primary task is to follow the 4-phase pipeline (Research → Plan → Build → Review) to analyze a client's data schema and produce deployable Snowflake SQL for ontology metadata, views, semantic views, and agents.

This project uses **CoCo skills** (in `.snowflake/cortex/skills/`) to guide each phase, **subagents** (via the `task` tool) for parallel review work, and **Snowflake-native tools** for DDL validation and schema discovery.

---

## Domain Context: Ontology on Snowflake

### What Is an Ontology Stack?

An ontology stack adds a **semantic layer of meaning** on top of raw data tables:

| Layer | What It Contains | Purpose |
|-------|-----------------|---------|
| Source tables | Raw client data | Facts storage |
| ONT_* metadata tables | Entity types, relationships, hierarchies, aliases | Declares what business concepts mean |
| Convenience views (V_*) | One view per entity/relationship | Clean query interface |
| Abstract views (VW_ONT_*) | Cross-entity unions | Higher-level reasoning |
| Semantic view | Cortex Analyst interface | Natural language → SQL |
| Cortex Agent | Orchestration | Routes questions to right tool |
| KG tables (optional) | KG_NODE + KG_EDGE | Graph traversal for multi-hop queries |

### The Two Paths

- **Phase A (Lightweight)**: Metadata + Views + Semantic View + Agent. No data duplication. Handles ~80% of business questions (aggregations, filters, rankings).
- **Phase B (Full KG)**: Adds KG_NODE/KG_EDGE + traversal procedures. Handles the remaining ~20% (path finding, blast radius, network analysis). Always additive to Phase A.

### Three Entry Points (How Inputs Are Created)

| Entry Point | Script | When to Use |
|-------------|--------|-------------|
| **Schema Introspection** | `generate_inputs_from_schema.py` | Client has Snowflake tables, no formal ontology. Most common path. |
| **OWL Import** | `parse_owl.py` | Client has a Protege ontology or industry standard (FIBO, SNOMED, GS1). |
| **Manual** | N/A (hand-write inputs/) | Very small schemas (<5 tables). |

All three entry points converge at the Research phase. The planning phase merges findings from schema analysis AND/OR OWL analysis into a single MASTER_PLAN.yaml.

### Decision Rule

Check `inputs/config.yaml` for the `path` value:
- `lightweight` → Generate Phase A only (output files 00-04)
- `kg` or `both` → Generate Phase A AND Phase B (output files 00-06)

---

## General Principles

### Pipeline Mindset
- **Follow the phases**: Research thoroughly before planning. Plan completely before building. Review everything before delivering.
- **Evidence over assumption**: Every entity classification must trace to a source table column. If you can't cite the source, flag it as a gap.
- **Reproducibility**: You produce scripts. Scripts produce SQL. Anyone can re-run the scripts without AI.
- **Quality gates are non-negotiable**: Each phase ends with a human approval gate.

### How You Coordinate Work
- **`system_todo_write` is your task tracker**: Break each phase into todos.
- **Skills guide your behavior**: Load the relevant phase skill at each stage.
- **Subagents handle reviews**: Spawn devil's advocate and peer-review subagents via the `task` tool.
- **`ask_user_question` is your gate mechanism**: Use for phase approvals and clarifications.
- **Write findings to files, not conversation**: Use `research/`, `plans/`, `scripts/`, `output/` folders.

### Escalation Protocol
- **L1 (Minor)**: Self-resolve technical decisions (e.g., choosing column names). Document in plans.
- **L1.5 (Clarification)**: Use `ask_user_question` for business/domain ambiguity (e.g., "Is ORDERS an entity or an event?").
- **L2 (Moderate)**: Spawn expert consultation subagent for ontology design questions.
- **L3 (Blocking)**: Surface to user with options (e.g., "The schema has no clear FK relationships — should I infer from naming patterns?").
- **L4 (Critical)**: HARD STOP (e.g., "Source DDL has syntax errors — cannot parse").

---

## Folder Conventions

| Folder | Purpose | Who Writes | Immutable? |
|--------|---------|------------|------------|
| `knowledgebase/` | DDL templates, design patterns, decision framework, naming conventions | Human | Yes |
| `inputs/` | Client DDL, business glossary, business questions, config | Human | Yes |
| `research/` | Schema analysis findings from Phase 1 | CoCo (Phase 1) | No |
| `plans/` | MASTER_PLAN.yaml + component plans from Phase 2 | CoCo (Phase 2) | No |
| `scripts/` | Python generator scripts from Phase 3 | CoCo (Phase 3) | No |
| `output/` | Generated SQL files (produced by running scripts) | Scripts at runtime | No |
| `testscripts/` | Validation reports from Phase 4 | CoCo (Phase 4) | No |
| `guardrails/` | Enforcement scripts | Human | Yes |

---

## Code Quality Standards

All generated scripts must:
- Be **idempotent** (safe to re-run)
- Use **pathlib** for all file operations
- Include **error handling** for file I/O
- Include **type hints** and **docstrings** (Google style)
- Read from `inputs/` + `knowledgebase/` + `plans/`, write to `output/`
- Follow naming conventions in `GUARDRAILS.yaml`
- Contain **no hardcoded database/schema values** — read from `inputs/config.yaml`
- Extend `BaseParser` or `BaseGenerator` from `scripts/`
- Only depend on PyYAML + Python standard library

---

## Snowflake-Enhanced Capabilities

| Capability | How to Use | When |
|---|---|---|
| **DDL validation** | `snowflake_sql_execute(sql, only_compile=true)` | Phase 4: Verify generated SQL compiles |
| **Schema discovery** | `snowflake_object_search(query)` | Phase 1: Discover existing client tables |
| **Docs research** | `snowflake_product_docs(query)` | Phase 1-2: Research semantic view/agent syntax |
| **SQL execution** | `snowflake_sql_execute(sql)` | Phase 4: Optionally deploy to sandbox |

### Safety Rules for Snowflake Operations
- Use `only_compile=true` for validation (no data changes)
- Never execute DDL that creates/alters/drops objects without explicit user approval
- All SQL must be validated with `sql-verify` subagent before execution

---

## Available Skills

| Skill | Invoke When | Purpose |
|-------|-------------|---------|
| `pipeline-orchestrator` | "start project" | Full 4-phase workflow orchestration |
| `research-phase` | Phase 1 | Profile source schema, classify tables |
| `planning-phase` | Phase 2 | Design ontology, decide Phase A vs B |
| `build-phase` | Phase 3 | Create generator scripts |
| `review-phase` | Phase 4 | Validate output, run scripts, verify |
| `devils-advocate` | Phase 2-3 gates | Challenge ontology design decisions |
| `peer-review` | Phase 3 (per script) | Code quality review |
| `expert-consult` | Any phase | Ontology design expertise |
| `self-review` | Before completing any task | Completion quality checklist |
| `agentic-loop` | After Phase 4 (optional) | Automated validate/refine cycle |

---

## Workflow Summary

```
"start project"
    │
    ▼
Phase 1: Research (profile schema, classify tables, identify relationships)
    → Gate 1 (user reviews schema analysis)
    ▼
Phase 2: Plan (design ontology: entities, relationships, hierarchies, aliases)
    → DA Challenge → Gate 2 (MANDATORY user approval of ontology design)
    ▼
Phase 3: Build (create generator scripts)
    → Peer Review per script → Gate 3 (user reviews)
    ▼
Phase 4: Review (run scripts, validate output SQL, check coverage)
    → Gate 4 (MANDATORY final approval)
    ▼
[Optional] Layer 2: Agentic validate/refine loop
```

---

## Key Documents

| Document | What It Tells You |
|----------|-------------------|
| `prompts.md` | What to build — deliverables, components, success criteria |
| `GUARDRAILS.yaml` | Quality standards — ontology validation rules, naming conventions |
| `knowledgebase/ontology_design_patterns.md` | How to classify tables and design relationships |
| `knowledgebase/decision_framework.md` | When to recommend Phase A vs Phase B |
| `knowledgebase/naming_conventions.md` | How to name all generated objects |
| `knowledgebase/ontology_ddl_templates.sql` | DDL templates for all ontology objects |
