"""
Ontology Validator — Cross-checks generated SQL against the ontology plan.

Validates:
- All entities have source tables
- All relationships reference valid entities
- SQL file structure is correct
- Deployment manifest is consistent

Usage:
    python scripts/validate_ontology.py
"""

from pathlib import Path
from typing import Any, Dict, List

from base_validator import BaseValidator
from utils import load_yaml, save_yaml


class OntologyValidator(BaseValidator):
    """Validates generated ontology SQL output."""

    def __init__(self):
        super().__init__()
        self.output_dir = Path('output')
        self.plans_dir = Path('plans')
        self.config = load_yaml(Path('inputs/config.yaml'))
        self.issues: List[Dict[str, str]] = []

    def validate(self) -> Dict[str, Any]:
        """Run all validation checks."""
        plan = load_yaml(self.plans_dir / 'MASTER_PLAN.yaml')
        if not plan:
            return {'status': 'FAIL', 'reason': 'No MASTER_PLAN.yaml found'}

        self._check_output_files_exist()
        self._check_entity_coverage(plan)
        self._check_relationship_validity(plan)
        self._check_sql_syntax()
        self._check_semantic_view_limits(plan)
        self._check_deployment_manifest()

        status = 'PASS' if not self.issues else 'FAIL'
        result = {
            'status': status,
            'checks_run': 6,
            'issues_found': len(self.issues),
            'issues': self.issues,
        }

        save_yaml(result, Path('testscripts/validation_report.yaml'))
        return result

    def _check_output_files_exist(self) -> None:
        """Verify all expected output files exist."""
        expected = [
            '01_ontology_metadata.sql',
            '02_convenience_views.sql',
            '03_semantic_view.sql',
            '04_cortex_agent.sql',
        ]

        path = self.config.get('path', 'lightweight')
        if path in ('kg', 'both'):
            expected += ['05_kg_tables.sql', '06_kg_procedures.sql']

        for fname in expected:
            if not (self.output_dir / fname).exists():
                self.issues.append({
                    'severity': 'ERROR',
                    'check': 'output_files_exist',
                    'message': f"Expected output file missing: {fname}",
                })

    def _check_entity_coverage(self, plan: Dict) -> None:
        """Verify all planned entities appear in generated metadata SQL."""
        entities = plan.get('ontology_design', {}).get('entity_types', [])
        metadata_file = self.output_dir / '01_ontology_metadata.sql'

        if not metadata_file.exists():
            return

        content = metadata_file.read_text(encoding='utf-8')
        for entity in entities:
            name = entity.get('name', '')
            if name and f"'{name}'" not in content:
                self.issues.append({
                    'severity': 'ERROR',
                    'check': 'entity_coverage',
                    'message': f"Entity '{name}' defined in plan but not found in generated SQL",
                })

    def _check_relationship_validity(self, plan: Dict) -> None:
        """Verify all relationships reference valid entities."""
        entities = plan.get('ontology_design', {}).get('entity_types', [])
        relationships = plan.get('ontology_design', {}).get('relationship_types', [])

        entity_names = {e.get('name', '') for e in entities}

        for rel in relationships:
            from_e = rel.get('from_entity', '')
            to_e = rel.get('to_entity', '')
            if from_e and from_e not in entity_names:
                self.issues.append({
                    'severity': 'ERROR',
                    'check': 'relationship_validity',
                    'message': f"Relationship '{rel.get('name')}' references unknown from_entity: '{from_e}'",
                })
            if to_e and to_e not in entity_names:
                self.issues.append({
                    'severity': 'ERROR',
                    'check': 'relationship_validity',
                    'message': f"Relationship '{rel.get('name')}' references unknown to_entity: '{to_e}'",
                })

    def _check_sql_syntax(self) -> None:
        """Basic SQL syntax checks (semicolons, CREATE statements)."""
        for sql_file in sorted(self.output_dir.glob('*.sql')):
            content = sql_file.read_text(encoding='utf-8')
            if 'CREATE' not in content.upper():
                self.issues.append({
                    'severity': 'WARNING',
                    'check': 'sql_syntax',
                    'message': f"{sql_file.name} contains no CREATE statements",
                })

    def _check_semantic_view_limits(self, plan: Dict) -> None:
        """Check semantic view doesn't exceed practical limits."""
        sv_design = plan.get('semantic_view_design', {})
        facts = sv_design.get('facts', [])
        dimensions = sv_design.get('dimensions', [])
        total_cols = len(facts) + len(dimensions)

        if total_cols > 50:
            self.issues.append({
                'severity': 'WARNING',
                'check': 'semantic_view_limits',
                'message': f"Semantic view has {total_cols} columns (facts+dimensions). Practical limit is ~50.",
            })

    def _check_deployment_manifest(self) -> None:
        """Verify deployment manifest exists and is consistent."""
        manifest_path = self.output_dir / 'deployment_manifest.yaml'
        if not manifest_path.exists():
            self.issues.append({
                'severity': 'WARNING',
                'check': 'deployment_manifest',
                'message': "deployment_manifest.yaml not found in output/",
            })
            return

        manifest = load_yaml(manifest_path)
        scripts = manifest.get('execution_order', [])
        for script_name in scripts:
            if not (self.output_dir / script_name).exists():
                self.issues.append({
                    'severity': 'ERROR',
                    'check': 'deployment_manifest',
                    'message': f"Manifest references '{script_name}' but file doesn't exist in output/",
                })

    def report(self) -> str:
        """Generate human-readable report."""
        if not self.issues:
            return "VALIDATION PASSED: All checks passed."

        lines = [f"VALIDATION {'PASSED' if not any(i['severity'] == 'ERROR' for i in self.issues) else 'FAILED'}"]
        lines.append(f"Issues found: {len(self.issues)}")
        lines.append("")
        for issue in self.issues:
            lines.append(f"  [{issue['severity']}] {issue['check']}: {issue['message']}")

        return "\n".join(lines)


def main():
    """Run ontology validation."""
    validator = OntologyValidator()
    result = validator.validate()
    print(validator.report())
    print(f"\nValidation report saved to: testscripts/validation_report.yaml")


if __name__ == '__main__':
    main()
