"""
Generate Inputs from Schema — Connects to Snowflake and auto-generates toolkit inputs.

Introspects a live Snowflake schema to produce:
  - inputs/source_ddl.sql (complete DDL for all tables)
  - inputs/config.yaml (pre-filled with database/schema/warehouse)
  - inputs/business_glossary.yaml (draft from comments, tags, naming patterns)
  - inputs/business_questions.yaml (template questions from column analysis)

Prerequisites:
  - Snowflake connection configured (~/.snowflake/connections.toml or config.toml)
  - pip install snowflake-connector-python pyyaml

Usage:
    python scripts/generate_inputs_from_schema.py --database MY_DB --schema MY_SCHEMA

    # Or with explicit connection:
    python scripts/generate_inputs_from_schema.py --database MY_DB --schema MY_SCHEMA --connection my_conn

    # Specify ontology name and path:
    python scripts/generate_inputs_from_schema.py --database MY_DB --schema MY_SCHEMA --ontology-name FINSERV --path both
"""

import argparse
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

try:
    import snowflake.connector
    from snowflake.connector import DictCursor
except ImportError:
    print("ERROR: snowflake-connector-python is required.")
    print("Install with: pip install snowflake-connector-python")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Snowflake Connection
# ---------------------------------------------------------------------------

def get_connection(connection_name: Optional[str] = None) -> snowflake.connector.SnowflakeConnection:
    """Connect to Snowflake using configured connection."""
    if connection_name:
        return snowflake.connector.connect(connection_name=connection_name)
    return snowflake.connector.connect(connection_name="default")


# ---------------------------------------------------------------------------
# Schema Introspection
# ---------------------------------------------------------------------------

def get_tables(conn, database: str, schema: str) -> List[Dict[str, Any]]:
    """Get all tables in the schema with row counts."""
    cur = conn.cursor(DictCursor)
    cur.execute(f"SHOW TABLES IN {database}.{schema}")
    tables = cur.fetchall()
    return [{'name': t['name'], 'rows': t.get('rows', 0),
             'comment': t.get('comment', '')} for t in tables]


def get_ddl(conn, database: str, schema: str, table_name: str) -> str:
    """Get CREATE TABLE DDL for a specific table."""
    cur = conn.cursor()
    cur.execute(f"SELECT GET_DDL('TABLE', '{database}.{schema}.{table_name}')")
    row = cur.fetchone()
    return row[0] if row else ""


def get_columns(conn, database: str, schema: str, table_name: str) -> List[Dict[str, Any]]:
    """Get column metadata for a table."""
    cur = conn.cursor(DictCursor)
    cur.execute(f"""
        SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT, COMMENT
        FROM {database}.INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = '{schema}' AND TABLE_NAME = '{table_name}'
        ORDER BY ORDINAL_POSITION
    """)
    return cur.fetchall()


def get_primary_keys(conn, database: str, schema: str, table_name: str) -> List[str]:
    """Get primary key columns for a table."""
    cur = conn.cursor(DictCursor)
    cur.execute(f"SHOW PRIMARY KEYS IN {database}.{schema}.{table_name}")
    rows = cur.fetchall()
    return [r['column_name'] for r in rows]


def get_foreign_keys(conn, database: str, schema: str, table_name: str) -> List[Dict[str, str]]:
    """Get declared foreign keys for a table."""
    cur = conn.cursor(DictCursor)
    try:
        cur.execute(f"SHOW IMPORTED KEYS IN {database}.{schema}.{table_name}")
        rows = cur.fetchall()
        return [{'column': r['fk_column_name'],
                 'references_table': r['pk_table_name'],
                 'references_column': r['pk_column_name']}
                for r in rows]
    except Exception:
        return []


def get_column_cardinality(conn, database: str, schema: str,
                           table_name: str, columns: List[Dict]) -> Dict[str, int]:
    """Get approximate distinct count for key columns."""
    cardinality = {}
    string_cols = [c['COLUMN_NAME'] for c in columns
                   if 'VARCHAR' in c.get('DATA_TYPE', '') or 'TEXT' in c.get('DATA_TYPE', '')]

    if not string_cols:
        return cardinality

    # Sample up to 10 string columns
    sample_cols = string_cols[:10]
    exprs = ", ".join(f"APPROX_COUNT_DISTINCT({col}) AS {col}" for col in sample_cols)
    cur = conn.cursor(DictCursor)
    try:
        cur.execute(f"SELECT {exprs} FROM {database}.{schema}.{table_name}")
        row = cur.fetchone()
        if row:
            cardinality = {k: v for k, v in row.items() if v is not None}
    except Exception:
        pass

    return cardinality


# ---------------------------------------------------------------------------
# Inference Logic
# ---------------------------------------------------------------------------

def classify_table(table_name: str, columns: List[Dict], pks: List[str],
                   fks: List[Dict], row_count: int) -> str:
    """Classify a table as entity, relationship, or lookup."""
    col_count = len(columns)
    fk_count = len(fks)

    # Infer FKs from naming if none declared
    if fk_count == 0:
        fk_count = sum(1 for c in columns
                       if (c['COLUMN_NAME'].endswith('_ID') or c['COLUMN_NAME'].endswith('_KEY'))
                       and c['COLUMN_NAME'] not in pks)

    if row_count < 50 and col_count <= 4:
        return 'lookup'
    if fk_count >= 2 and col_count <= fk_count + 4:
        return 'relationship'
    if col_count >= 5:
        return 'entity'
    return 'lookup'


def infer_fks_from_naming(columns: List[Dict], pks: List[str],
                          all_table_names: List[str]) -> List[Dict[str, str]]:
    """Infer foreign keys from column naming patterns."""
    fks = []
    for col in columns:
        col_name = col['COLUMN_NAME']
        if col_name in pks:
            continue
        if col_name.endswith('_ID') or col_name.endswith('_KEY'):
            # Try to match to a known table
            prefix = col_name.replace('_ID', '').replace('_KEY', '')
            candidates = [t for t in all_table_names
                          if t.upper() == prefix.upper()
                          or t.upper() == prefix.upper() + 'S'
                          or t.upper() == prefix.upper() + 'ES']
            if candidates:
                fks.append({
                    'column': col_name,
                    'references_table': candidates[0],
                    'references_column': col_name,
                    'inferred': True
                })
    return fks


def detect_hierarchies(table_name: str, columns: List[Dict],
                       cardinality: Dict[str, int], row_count: int) -> List[Dict]:
    """Detect hierarchy candidates from column cardinality patterns."""
    hierarchy_keywords = ['TYPE', 'CATEGORY', 'CLASS', 'TIER', 'LEVEL',
                         'REGION', 'SECTOR', 'GROUP', 'DIVISION', 'STATUS',
                         'SEGMENT', 'SUB_CATEGORY', 'ASSET_CLASS']
    candidates = []
    for col in columns:
        col_name = col['COLUMN_NAME']
        if any(kw in col_name.upper() for kw in hierarchy_keywords):
            distinct = cardinality.get(col_name, 0)
            if 0 < distinct < row_count * 0.3:  # Low cardinality = classification
                candidates.append({
                    'column': col_name,
                    'distinct_values': distinct,
                    'ratio': round(distinct / max(row_count, 1), 3)
                })

    return candidates


def infer_entity_name(table_name: str) -> str:
    """Convert table name to PascalCase entity name."""
    # Remove trailing S for plural
    name = table_name
    if name.endswith('IES'):
        name = name[:-3] + 'Y'
    elif name.endswith('ES') and not name.endswith('SSES'):
        name = name[:-2]
    elif name.endswith('S') and not name.endswith('SS'):
        name = name[:-1]

    # Convert to PascalCase
    parts = name.split('_')
    return ''.join(p.capitalize() for p in parts)


def generate_draft_questions(tables_info: List[Dict]) -> List[Dict]:
    """Generate template business questions from schema analysis."""
    questions = []

    for table in tables_info:
        if table['classification'] != 'entity':
            continue

        entity = table['entity_name']
        dims = [c for c in table.get('hierarchy_candidates', [])]
        numerics = [c['COLUMN_NAME'] for c in table['columns']
                    if 'NUMBER' in c.get('DATA_TYPE', '') or 'DECIMAL' in c.get('DATA_TYPE', '')
                    or 'FLOAT' in c.get('DATA_TYPE', '') or 'INT' in c.get('DATA_TYPE', '')]

        # Aggregation questions
        if dims and numerics:
            dim_name = dims[0]['column'].replace('_', ' ').lower()
            num_col = numerics[0] if numerics[0] not in table.get('primary_keys', []) else (numerics[1] if len(numerics) > 1 else numerics[0])
            questions.append({
                'question': f"What is the total {num_col.replace('_', ' ').lower()} by {dim_name}?",
                'category': 'aggregation',
                'auto_generated': True
            })

        # Count question
        questions.append({
            'question': f"How many {table['name'].replace('_', ' ').lower()} are there?",
            'category': 'aggregation',
            'auto_generated': True
        })

        # Filter question
        if dims:
            dim_name = dims[0]['column'].replace('_', ' ').lower()
            questions.append({
                'question': f"Show {table['name'].replace('_', ' ').lower()} filtered by {dim_name}",
                'category': 'filter',
                'auto_generated': True
            })

    # Add generic graph questions as placeholders
    questions.append({
        'question': "How is entity A connected to entity B?",
        'category': 'graph_traversal',
        'requires_kg': True,
        'auto_generated': True,
        'placeholder': True
    })

    return questions


# ---------------------------------------------------------------------------
# Output Generation
# ---------------------------------------------------------------------------

def generate_source_ddl(conn, database: str, schema: str,
                        tables: List[Dict], output_dir: Path) -> None:
    """Generate inputs/source_ddl.sql from live schema."""
    lines = [
        f"-- Source DDL — Auto-generated from {database}.{schema}",
        f"-- Generated by generate_inputs_from_schema.py",
        ""
    ]

    for table in tables:
        ddl = get_ddl(conn, database, schema, table['name'])
        if ddl:
            lines.append(ddl)
            lines.append("")

    (output_dir / 'source_ddl.sql').write_text("\n".join(lines), encoding='utf-8')
    print(f"  Created: inputs/source_ddl.sql ({len(tables)} tables)")


def generate_config(database: str, schema: str, ontology_name: str,
                    path: str, output_dir: Path) -> None:
    """Generate inputs/config.yaml."""
    config = {
        'database': database,
        'schema': schema,
        'ontology_name': ontology_name,
        'path': path,
        'warehouse': 'SF_SANDBOX_WH',
        'generate_deployment_manifest': True,
        'include_comments_on_views': True,
        'use_create_or_replace': True,
    }
    with open(output_dir / 'config.yaml', 'w', encoding='utf-8') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)
    print(f"  Created: inputs/config.yaml (path={path})")


def generate_glossary(tables_info: List[Dict], output_dir: Path) -> None:
    """Generate inputs/business_glossary.yaml (draft)."""
    terms = []
    for table in tables_info:
        if table['classification'] == 'entity':
            entry = {
                'canonical': table['entity_name'],
                'aliases': [],
                'description': table.get('comment', '') or f"Represents {table['entity_name']} entities",
                'auto_generated': True,
                'needs_review': True,
            }
            # Generate simple alias from table name
            simple = table['name'].replace('_', ' ').lower()
            if simple != table['entity_name'].lower():
                entry['aliases'].append(simple)
            terms.append(entry)

    glossary = {
        '_meta': {
            'note': 'AUTO-GENERATED DRAFT — Review and add real business synonyms',
            'confidence': '40%',
            'action_required': 'Add domain-specific aliases, validate descriptions with SMEs',
        },
        'terms': terms,
        'abbreviations': [],
    }

    with open(output_dir / 'business_glossary.yaml', 'w', encoding='utf-8') as f:
        yaml.dump(glossary, f, default_flow_style=False, sort_keys=False)
    print(f"  Created: inputs/business_glossary.yaml ({len(terms)} terms, DRAFT)")


def generate_questions(tables_info: List[Dict], output_dir: Path) -> None:
    """Generate inputs/business_questions.yaml (template)."""
    questions = generate_draft_questions(tables_info)

    output = {
        '_meta': {
            'note': 'AUTO-GENERATED TEMPLATE — Replace with real business questions from stakeholder interviews',
            'confidence': '20%',
            'action_required': 'Replace auto-generated questions with actual user questions',
        },
        'questions': questions,
    }

    with open(output_dir / 'business_questions.yaml', 'w', encoding='utf-8') as f:
        yaml.dump(output, f, default_flow_style=False, sort_keys=False)
    print(f"  Created: inputs/business_questions.yaml ({len(questions)} questions, TEMPLATE)")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description='Generate toolkit inputs from a live Snowflake schema'
    )
    parser.add_argument('--database', required=True, help='Snowflake database name')
    parser.add_argument('--schema', required=True, help='Snowflake schema name')
    parser.add_argument('--connection', default=None, help='Snowflake connection name (from config)')
    parser.add_argument('--ontology-name', default=None, help='Ontology name prefix (default: schema name)')
    parser.add_argument('--path', default='lightweight', choices=['lightweight', 'kg', 'both'],
                        help='Ontology path: lightweight, kg, or both')
    parser.add_argument('--output-dir', default='inputs', help='Output directory (default: inputs/)')

    args = parser.parse_args()

    database = args.database.upper()
    schema = args.schema.upper()
    ontology_name = (args.ontology_name or schema).upper()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"Connecting to Snowflake...")
    conn = get_connection(args.connection)
    print(f"Connected. Introspecting {database}.{schema}...")

    # Step 1: Get all tables
    tables = get_tables(conn, database, schema)
    all_table_names = [t['name'] for t in tables]
    print(f"  Found {len(tables)} tables")

    # Step 2: Profile each table
    tables_info = []
    for table in tables:
        name = table['name']
        columns = get_columns(conn, database, schema, name)
        pks = get_primary_keys(conn, database, schema, name)
        declared_fks = get_foreign_keys(conn, database, schema, name)
        cardinality = get_column_cardinality(conn, database, schema, name, columns)
        row_count = table.get('rows', 0)

        # Infer FKs if none declared
        fks = declared_fks or infer_fks_from_naming(columns, pks, all_table_names)

        classification = classify_table(name, columns, pks, fks, row_count)
        hierarchy_candidates = detect_hierarchies(name, columns, cardinality, row_count)
        entity_name = infer_entity_name(name)

        tables_info.append({
            'name': name,
            'entity_name': entity_name,
            'columns': columns,
            'primary_keys': pks,
            'foreign_keys': fks,
            'classification': classification,
            'hierarchy_candidates': hierarchy_candidates,
            'row_count': row_count,
            'comment': table.get('comment', ''),
        })

    entities = [t for t in tables_info if t['classification'] == 'entity']
    rels = [t for t in tables_info if t['classification'] == 'relationship']
    lookups = [t for t in tables_info if t['classification'] == 'lookup']
    print(f"  Classified: {len(entities)} entities, {len(rels)} relationships, {len(lookups)} lookups")

    # Step 3: Generate outputs
    print(f"\nGenerating inputs in {output_dir}/...")
    generate_source_ddl(conn, database, schema, tables, output_dir)
    generate_config(database, schema, ontology_name, args.path, output_dir)
    generate_glossary(tables_info, output_dir)
    generate_questions(tables_info, output_dir)

    conn.close()

    print(f"\nDone! Generated 4 input files in {output_dir}/")
    print(f"")
    print(f"Next steps:")
    print(f"  1. Review inputs/config.yaml — confirm path choice (currently: {args.path})")
    print(f"  2. Review inputs/business_glossary.yaml — add real synonyms from SME interviews")
    print(f"  3. Review inputs/business_questions.yaml — replace templates with actual user questions")
    print(f"  4. Run the pipeline: open in CoCo and say 'start project'")


if __name__ == '__main__':
    main()
