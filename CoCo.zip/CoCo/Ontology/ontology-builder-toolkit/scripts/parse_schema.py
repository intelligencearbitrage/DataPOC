"""
Schema Profiler — Parses client DDL files and classifies tables.

Reads CREATE TABLE statements from inputs/source_ddl.sql, extracts table structures,
detects foreign keys, and classifies tables as entity, relationship, or lookup.

Usage:
    parser = SchemaParser()
    parser.parse_all()
    parser.save_analysis('schema_analysis.yaml')
"""

import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from base_parser import BaseParser
from utils import save_yaml


class SchemaParser(BaseParser):
    """Parses SQL DDL files and classifies tables for ontology design."""

    def discover_files(self) -> List[Path]:
        """Find DDL files in inputs/."""
        files = list(self.input_dir.glob('*.sql'))
        files += list(self.input_dir.glob('*.ddl'))
        return files

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse a DDL file and extract all CREATE TABLE statements."""
        content = file_path.read_text(encoding='utf-8')
        tables = self._extract_tables(content)
        return {'source_file': file_path.name, 'tables': tables}

    def _extract_tables(self, ddl_content: str) -> List[Dict[str, Any]]:
        """Extract all CREATE TABLE definitions from DDL content."""
        tables = []
        pattern = re.compile(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?'
            r'([A-Za-z0-9_.]+)\s*\((.*?)\);',
            re.IGNORECASE | re.DOTALL
        )

        for match in pattern.finditer(ddl_content):
            table_name = match.group(1).split('.')[-1].upper()
            body = match.group(2)
            columns = self._parse_columns(body)
            pk = self._detect_primary_key(body, columns)
            fks = self._detect_foreign_keys(body, columns)

            table_info = {
                'table_name': table_name,
                'columns': columns,
                'primary_key': pk,
                'foreign_keys': fks,
                'column_count': len(columns),
                'classification': self._classify_table(columns, pk, fks),
            }
            tables.append(table_info)

        return tables

    def _parse_columns(self, body: str) -> List[Dict[str, str]]:
        """Parse column definitions from table body."""
        columns = []
        lines = body.split(',')

        for line in lines:
            line = line.strip()
            if not line:
                continue
            if re.match(r'^\s*(CONSTRAINT|PRIMARY\s+KEY|FOREIGN\s+KEY|UNIQUE|CHECK)', line, re.IGNORECASE):
                continue

            col_match = re.match(
                r'(\w+)\s+([\w()., ]+?)(?:\s+(NOT\s+NULL|NULL|DEFAULT|AUTOINCREMENT|PRIMARY\s+KEY|REFERENCES).*)?$',
                line, re.IGNORECASE
            )
            if col_match:
                col_name = col_match.group(1).upper()
                col_type = col_match.group(2).strip().upper()
                is_nullable = 'NOT NULL' not in line.upper()
                columns.append({
                    'name': col_name,
                    'data_type': col_type,
                    'nullable': is_nullable,
                    'is_pk_candidate': col_name.endswith('_ID') or col_name.endswith('_KEY'),
                    'is_fk_candidate': (col_name.endswith('_ID') or col_name.endswith('_KEY'))
                                       and 'PRIMARY' not in line.upper(),
                })

        return columns

    def _detect_primary_key(self, body: str, columns: List[Dict]) -> Optional[str]:
        """Detect primary key from constraints or column definitions."""
        pk_match = re.search(
            r'(?:CONSTRAINT\s+\w+\s+)?PRIMARY\s+KEY\s*\(([^)]+)\)',
            body, re.IGNORECASE
        )
        if pk_match:
            return pk_match.group(1).strip().upper()

        for col in columns:
            if col['name'].endswith('_ID') and not col['nullable']:
                return col['name']

        return columns[0]['name'] if columns else None

    def _detect_foreign_keys(self, body: str, columns: List[Dict]) -> List[Dict[str, str]]:
        """Detect foreign keys from naming patterns and REFERENCES clauses."""
        fks = []

        fk_pattern = re.compile(
            r'(\w+)\s+.*?REFERENCES\s+(\w+)(?:\s*\((\w+)\))?',
            re.IGNORECASE
        )
        for match in fk_pattern.finditer(body):
            fks.append({
                'column': match.group(1).upper(),
                'references_table': match.group(2).upper(),
                'references_column': (match.group(3) or '').upper(),
            })

        if not fks:
            for col in columns:
                if col['is_fk_candidate'] and col['name'] != self._detect_primary_key(body, columns):
                    inferred_table = col['name'].replace('_ID', '').replace('_KEY', '')
                    fks.append({
                        'column': col['name'],
                        'references_table': inferred_table + 'S',
                        'references_column': col['name'],
                        'inferred': True,
                    })

        return fks

    def _classify_table(
        self, columns: List[Dict], pk: Optional[str], fks: List[Dict]
    ) -> str:
        """Classify table as entity, relationship, or lookup."""
        col_count = len(columns)
        fk_count = len(fks)

        if col_count <= 3 and fk_count == 0:
            return 'lookup'

        if fk_count >= 2 and col_count <= fk_count + 3:
            return 'relationship'

        if col_count >= 5:
            return 'entity'

        if col_count <= 5 and fk_count == 0:
            return 'lookup'

        return 'entity'

    def identify_gaps(self) -> List[Dict[str, str]]:
        """Check for common schema issues."""
        gaps = list(self.gaps)

        for source_name, source_data in self.parsed_data.items():
            tables = source_data.get('tables', [])
            for table in tables:
                if not table.get('primary_key'):
                    gaps.append({
                        'description': f"Table {table['table_name']} has no detectable primary key",
                        'recommendation': "Specify a primary key or ID column in config"
                    })
                if table['classification'] == 'entity' and len(table.get('foreign_keys', [])) == 0:
                    gaps.append({
                        'description': f"Entity table {table['table_name']} has no foreign keys (isolated)",
                        'recommendation': "Verify this entity connects to others via junction tables"
                    })

        return gaps

    def generate_analysis(self) -> Dict[str, Any]:
        """Generate structured schema analysis."""
        all_tables = []
        for source_data in self.parsed_data.values():
            all_tables.extend(source_data.get('tables', []))

        entity_tables = [t for t in all_tables if t['classification'] == 'entity']
        relationship_tables = [t for t in all_tables if t['classification'] == 'relationship']
        lookup_tables = [t for t in all_tables if t['classification'] == 'lookup']

        hierarchy_candidates = self._detect_hierarchies(entity_tables)

        return {
            'metadata': {
                'source_files': list(self.parsed_data.keys()),
                'total_tables': len(all_tables),
                'entities': len(entity_tables),
                'relationships': len(relationship_tables),
                'lookups': len(lookup_tables),
            },
            'tables': all_tables,
            'entity_candidates': [
                {'table_name': t['table_name'], 'primary_key': t['primary_key'],
                 'column_count': t['column_count']}
                for t in entity_tables
            ],
            'relationship_candidates': [
                {'table_name': t['table_name'], 'foreign_keys': t['foreign_keys']}
                for t in relationship_tables
            ],
            'hierarchy_candidates': hierarchy_candidates,
            'gaps': self.identify_gaps(),
        }

    def _detect_hierarchies(self, entity_tables: List[Dict]) -> List[Dict[str, Any]]:
        """Detect potential hierarchies from column naming patterns."""
        hierarchies = []
        hierarchy_keywords = ['TYPE', 'CATEGORY', 'CLASS', 'TIER', 'LEVEL',
                             'REGION', 'SECTOR', 'GROUP', 'DIVISION', 'STATUS']

        for table in entity_tables:
            hier_cols = []
            for col in table.get('columns', []):
                col_name = col['name']
                if any(kw in col_name for kw in hierarchy_keywords):
                    hier_cols.append(col_name)

            if len(hier_cols) >= 2:
                hierarchies.append({
                    'entity_table': table['table_name'],
                    'candidate_columns': hier_cols,
                    'suggested_name': f"{table['table_name']}Taxonomy",
                })

        return hierarchies


def main():
    """Run schema profiling on inputs/."""
    parser = SchemaParser(input_dir='inputs', output_dir='research')
    parser.parse_all()
    output_path = parser.save_analysis('schema_analysis.yaml')
    print(f"Schema analysis saved to: {output_path}")


if __name__ == '__main__':
    main()
