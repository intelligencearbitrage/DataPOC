"""
OWL/RDF Parser — Parses ontology files from Protege into ontology design YAML.

Supports: .owl (RDF/XML), .ttl (Turtle), .rdf (RDF/XML), .n3 (Notation3), .nt (N-Triples)

Extracts:
  - Classes → entity_candidates (with inheritance via rdfs:subClassOf)
  - Object Properties → relationship_candidates (with domain/range)
  - Datatype Properties → attribute_candidates (columns for views)
  - Labels/Comments → descriptions and aliases
  - Hierarchy chains → hierarchy_candidates

Prerequisites:
    pip install rdflib pyyaml

Usage:
    python scripts/parse_owl.py

    # Or specify input directory:
    python scripts/parse_owl.py --input-dir inputs/

Output:
    research/owl_analysis.yaml
"""

import argparse
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

try:
    from rdflib import Graph, Namespace, URIRef, Literal, BNode
    from rdflib.namespace import RDF, RDFS, OWL, SKOS, XSD
except ImportError:
    import sys
    print("ERROR: rdflib is required for OWL parsing.")
    print("Install with: pip install rdflib")
    sys.exit(1)

from base_parser import BaseParser
from utils import save_yaml


class OWLParser(BaseParser):
    """Parses OWL/RDF/Turtle ontology files into ontology design structures."""

    SUPPORTED_EXTENSIONS = ('.owl', '.rdf', '.ttl', '.n3', '.nt', '.xml')

    def __init__(self, input_dir: str = 'inputs', output_dir: str = 'research'):
        super().__init__(input_dir=input_dir, output_dir=output_dir)
        self.graph = Graph()

    def discover_files(self) -> List[Path]:
        """Find ontology files in inputs/."""
        files = []
        for ext in self.SUPPORTED_EXTENSIONS:
            files.extend(self.input_dir.glob(f'*{ext}'))
        return sorted(files)

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse a single ontology file."""
        fmt = self._detect_format(file_path)
        self.graph.parse(str(file_path), format=fmt)
        self.logger.info(f"  Loaded {len(self.graph)} triples from {file_path.name} (format: {fmt})")

        classes = self._extract_classes()
        object_properties = self._extract_object_properties()
        datatype_properties = self._extract_datatype_properties()
        hierarchies = self._extract_hierarchies(classes)
        aliases = self._extract_aliases()

        return {
            'source_file': file_path.name,
            'format': fmt,
            'triple_count': len(self.graph),
            'classes': classes,
            'object_properties': object_properties,
            'datatype_properties': datatype_properties,
            'hierarchies': hierarchies,
            'aliases': aliases,
        }

    def _detect_format(self, file_path: Path) -> str:
        """Detect RDF serialization format from extension."""
        ext = file_path.suffix.lower()
        format_map = {
            '.owl': 'xml',
            '.rdf': 'xml',
            '.xml': 'xml',
            '.ttl': 'turtle',
            '.n3': 'n3',
            '.nt': 'nt',
        }
        return format_map.get(ext, 'xml')

    def _get_label(self, subject: URIRef) -> str:
        """Get human-readable label for a resource."""
        for label in self.graph.objects(subject, RDFS.label):
            if isinstance(label, Literal):
                return str(label)
        # Fallback: extract local name from URI
        uri = str(subject)
        if '#' in uri:
            return uri.split('#')[-1]
        return uri.split('/')[-1]

    def _get_comment(self, subject: URIRef) -> str:
        """Get rdfs:comment for a resource."""
        for comment in self.graph.objects(subject, RDFS.comment):
            if isinstance(comment, Literal):
                return str(comment)
        return ''

    def _get_parent_classes(self, cls: URIRef) -> List[str]:
        """Get direct parent classes via rdfs:subClassOf."""
        parents = []
        for parent in self.graph.objects(cls, RDFS.subClassOf):
            if isinstance(parent, URIRef) and parent != OWL.Thing:
                parents.append(self._get_label(parent))
        return parents

    def _extract_classes(self) -> List[Dict[str, Any]]:
        """Extract all OWL classes with metadata."""
        classes = []
        seen_uris: Set[str] = set()

        for cls in self.graph.subjects(RDF.type, OWL.Class):
            if isinstance(cls, BNode):
                continue
            uri = str(cls)
            if uri in seen_uris:
                continue
            seen_uris.add(uri)

            name = self._get_label(cls)
            comment = self._get_comment(cls)
            parents = self._get_parent_classes(cls)

            # Determine if abstract (has subclasses but no direct instances)
            has_subclasses = any(True for _ in self.graph.subjects(RDFS.subClassOf, cls))
            has_instances = any(True for _ in self.graph.subjects(RDF.type, cls))
            is_abstract = has_subclasses and not has_instances

            classes.append({
                'uri': uri,
                'name': name,
                'description': comment,
                'parents': parents,
                'is_abstract': is_abstract,
                'has_subclasses': has_subclasses,
            })

        return sorted(classes, key=lambda c: c['name'])

    def _extract_object_properties(self) -> List[Dict[str, Any]]:
        """Extract OWL object properties (relationships between entities)."""
        properties = []
        seen_uris: Set[str] = set()

        for prop in self.graph.subjects(RDF.type, OWL.ObjectProperty):
            if isinstance(prop, BNode):
                continue
            uri = str(prop)
            if uri in seen_uris:
                continue
            seen_uris.add(uri)

            name = self._get_label(prop)
            comment = self._get_comment(prop)

            # Get domain (from_entity) and range (to_entity)
            domains = [self._get_label(d) for d in self.graph.objects(prop, RDFS.domain)
                       if isinstance(d, URIRef)]
            ranges = [self._get_label(r) for r in self.graph.objects(prop, RDFS.range)
                      if isinstance(r, URIRef)]

            # Check for inverse
            inverse = None
            for inv in self.graph.objects(prop, OWL.inverseOf):
                if isinstance(inv, URIRef):
                    inverse = self._get_label(inv)

            # Check for functional (many-to-one indicator)
            is_functional = (prop, RDF.type, OWL.FunctionalProperty) in self.graph
            is_inverse_functional = (prop, RDF.type, OWL.InverseFunctionalProperty) in self.graph
            is_transitive = (prop, RDF.type, OWL.TransitiveProperty) in self.graph
            is_symmetric = (prop, RDF.type, OWL.SymmetricProperty) in self.graph

            # Infer cardinality
            if is_functional and is_inverse_functional:
                cardinality = 'one-to-one'
            elif is_functional:
                cardinality = 'many-to-one'
            else:
                cardinality = 'many-to-many'

            properties.append({
                'uri': uri,
                'name': name,
                'description': comment,
                'from_entity': domains[0] if domains else None,
                'to_entity': ranges[0] if ranges else None,
                'cardinality': cardinality,
                'inverse_name': inverse,
                'is_transitive': is_transitive,
                'is_symmetric': is_symmetric,
            })

        return sorted(properties, key=lambda p: p['name'])

    def _extract_datatype_properties(self) -> List[Dict[str, Any]]:
        """Extract OWL datatype properties (attributes on entities)."""
        properties = []
        seen_uris: Set[str] = set()

        for prop in self.graph.subjects(RDF.type, OWL.DatatypeProperty):
            if isinstance(prop, BNode):
                continue
            uri = str(prop)
            if uri in seen_uris:
                continue
            seen_uris.add(uri)

            name = self._get_label(prop)
            comment = self._get_comment(prop)

            domains = [self._get_label(d) for d in self.graph.objects(prop, RDFS.domain)
                       if isinstance(d, URIRef)]
            ranges = [str(r) for r in self.graph.objects(prop, RDFS.range)
                      if isinstance(r, URIRef)]

            # Map XSD types to Snowflake types
            sf_type = self._xsd_to_snowflake(ranges[0] if ranges else '')

            properties.append({
                'uri': uri,
                'name': name,
                'description': comment,
                'entity': domains[0] if domains else None,
                'xsd_type': ranges[0] if ranges else None,
                'snowflake_type': sf_type,
            })

        return sorted(properties, key=lambda p: (p.get('entity', '') or '', p['name']))

    def _xsd_to_snowflake(self, xsd_type: str) -> str:
        """Map XSD datatype to Snowflake type."""
        type_map = {
            'string': 'STRING',
            'integer': 'INT',
            'int': 'INT',
            'long': 'BIGINT',
            'float': 'FLOAT',
            'double': 'DOUBLE',
            'decimal': 'DECIMAL',
            'boolean': 'BOOLEAN',
            'date': 'DATE',
            'dateTime': 'TIMESTAMP_NTZ',
            'time': 'TIME',
        }
        # Extract local name from XSD URI
        local = xsd_type.split('#')[-1] if '#' in xsd_type else xsd_type.split('/')[-1]
        return type_map.get(local, 'STRING')

    def _extract_hierarchies(self, classes: List[Dict]) -> List[Dict[str, Any]]:
        """Detect class hierarchies from subClassOf chains."""
        hierarchies = []
        roots: Set[str] = set()

        # Find root classes (have subclasses but no parent or parent is owl:Thing)
        for cls in classes:
            if cls['has_subclasses'] and not cls['parents']:
                roots.add(cls['name'])

        for root_name in sorted(roots):
            chain = self._trace_hierarchy(root_name, classes, depth=0, max_depth=10)
            if len(chain) > 1:
                hierarchies.append({
                    'root': root_name,
                    'depth': max(level['depth'] for level in chain),
                    'levels': chain,
                })

        return hierarchies

    def _trace_hierarchy(self, class_name: str, classes: List[Dict],
                         depth: int, max_depth: int) -> List[Dict]:
        """Recursively trace a class hierarchy downward."""
        if depth > max_depth:
            return []

        levels = [{'name': class_name, 'depth': depth}]

        children = [c['name'] for c in classes if class_name in c.get('parents', [])]
        for child in sorted(children):
            levels.extend(self._trace_hierarchy(child, classes, depth + 1, max_depth))

        return levels

    def _extract_aliases(self) -> List[Dict[str, str]]:
        """Extract alternative labels (skos:altLabel, rdfs:label variants)."""
        aliases = []

        for subject in set(self.graph.subjects()):
            if isinstance(subject, BNode):
                continue

            canonical = self._get_label(subject)
            alt_labels = set()

            # SKOS alternative labels
            for label in self.graph.objects(subject, SKOS.altLabel):
                if isinstance(label, Literal) and str(label) != canonical:
                    alt_labels.add(str(label))

            # Multiple rdfs:labels (different languages or variants)
            all_labels = [str(l) for l in self.graph.objects(subject, RDFS.label)
                         if isinstance(l, Literal)]
            for label in all_labels:
                if label != canonical:
                    alt_labels.add(label)

            for alias in alt_labels:
                aliases.append({
                    'canonical_name': canonical,
                    'alias': alias,
                })

        return sorted(aliases, key=lambda a: (a['canonical_name'], a['alias']))

    def generate_analysis(self) -> Dict[str, Any]:
        """Generate structured ontology analysis."""
        all_classes = []
        all_object_props = []
        all_datatype_props = []
        all_hierarchies = []
        all_aliases = []

        for source_data in self.parsed_data.values():
            all_classes.extend(source_data.get('classes', []))
            all_object_props.extend(source_data.get('object_properties', []))
            all_datatype_props.extend(source_data.get('datatype_properties', []))
            all_hierarchies.extend(source_data.get('hierarchies', []))
            all_aliases.extend(source_data.get('aliases', []))

        entity_candidates = [
            {
                'name': c['name'],
                'description': c['description'],
                'is_abstract': c['is_abstract'],
                'parents': c['parents'],
            }
            for c in all_classes
        ]

        relationship_candidates = [
            {
                'name': p['name'],
                'description': p['description'],
                'from_entity': p['from_entity'],
                'to_entity': p['to_entity'],
                'cardinality': p['cardinality'],
                'inverse_name': p['inverse_name'],
                'is_transitive': p['is_transitive'],
            }
            for p in all_object_props
        ]

        return {
            'metadata': {
                'source_files': list(self.parsed_data.keys()),
                'format': 'OWL/RDF',
                'total_triples': sum(d.get('triple_count', 0) for d in self.parsed_data.values()),
                'classes': len(all_classes),
                'object_properties': len(all_object_props),
                'datatype_properties': len(all_datatype_props),
                'hierarchies': len(all_hierarchies),
                'aliases': len(all_aliases),
            },
            'entity_candidates': entity_candidates,
            'relationship_candidates': relationship_candidates,
            'attribute_candidates': all_datatype_props,
            'hierarchy_candidates': all_hierarchies,
            'alias_candidates': all_aliases,
            'gaps': self.identify_gaps(),
        }

    def identify_gaps(self) -> List[Dict[str, str]]:
        """Identify gaps in the parsed ontology."""
        gaps = list(self.gaps)

        for source_data in self.parsed_data.values():
            # Classes without descriptions
            for cls in source_data.get('classes', []):
                if not cls.get('description'):
                    gaps.append({
                        'description': f"Class '{cls['name']}' has no rdfs:comment",
                        'recommendation': "Add a description in Protege or in the planning phase"
                    })

            # Properties without domain/range
            for prop in source_data.get('object_properties', []):
                if not prop.get('from_entity') or not prop.get('to_entity'):
                    gaps.append({
                        'description': f"Property '{prop['name']}' missing domain or range",
                        'recommendation': "Specify rdfs:domain and rdfs:range in the ontology"
                    })

        return gaps


def main():
    parser = argparse.ArgumentParser(description='Parse OWL/RDF ontology files')
    parser.add_argument('--input-dir', default='inputs', help='Directory with .owl/.ttl files')
    parser.add_argument('--output-dir', default='research', help='Output directory for analysis')
    args = parser.parse_args()

    owl_parser = OWLParser(input_dir=args.input_dir, output_dir=args.output_dir)
    files = owl_parser.discover_files()

    if not files:
        print(f"No ontology files found in {args.input_dir}/")
        print(f"Supported formats: {', '.join(OWLParser.SUPPORTED_EXTENSIONS)}")
        return

    owl_parser.parse_all()
    output_path = owl_parser.save_analysis('owl_analysis.yaml')
    print(f"OWL analysis saved to: {output_path}")

    # Print summary
    analysis = owl_parser.generate_analysis()
    meta = analysis['metadata']
    print(f"\nSummary:")
    print(f"  Classes (entity candidates): {meta['classes']}")
    print(f"  Object Properties (relationships): {meta['object_properties']}")
    print(f"  Datatype Properties (attributes): {meta['datatype_properties']}")
    print(f"  Hierarchies detected: {meta['hierarchies']}")
    print(f"  Aliases found: {meta['aliases']}")
    print(f"  Gaps identified: {len(analysis['gaps'])}")


if __name__ == '__main__':
    main()
