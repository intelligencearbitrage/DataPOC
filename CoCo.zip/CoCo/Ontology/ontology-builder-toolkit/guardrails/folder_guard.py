"""
Folder Guard - Enforces phase-to-folder boundary rules.

Checks that phases only write to their designated folders
as defined in GUARDRAILS.yaml folder_boundaries.
"""

import sys
from pathlib import Path
from typing import Dict, List

from logger import setup_guard_logger, get_project_root, load_guardrails_config


def get_folder_boundaries(config: dict) -> Dict[str, List[str]]:
    """Extract folder boundaries from GUARDRAILS.yaml."""
    boundaries = {}
    fb = config.get('folder_boundaries', {})
    for phase_name, phase_config in fb.items():
        if phase_name == 'immutable':
            continue
        if isinstance(phase_config, dict):
            boundaries[phase_name] = phase_config.get('write', [])
        elif isinstance(phase_config, list):
            boundaries[phase_name] = phase_config
    return boundaries


def check_file_in_boundary(
    file_path: str,
    allowed_folders: List[str],
    project_root: Path
) -> bool:
    """Check if a file path falls within any of the allowed folders."""
    rel_path = str(Path(file_path).relative_to(project_root))
    rel_path = rel_path.replace('\\', '/')

    for folder in allowed_folders:
        folder = folder.replace('\\', '/')
        if rel_path.startswith(folder):
            return True
    return False


def validate_folder_boundaries(project_root: Path) -> list:
    """Validate that the folder structure matches expected boundaries."""
    issues = []
    config = load_guardrails_config()
    boundaries = get_folder_boundaries(config)

    if not boundaries:
        issues.append({
            'severity': 'WARNING',
            'file': 'GUARDRAILS.yaml',
            'message': 'No folder_boundaries defined',
            'suggestion': 'Define folder_boundaries in GUARDRAILS.yaml'
        })
        return issues

    # Check that all designated folders exist
    all_folders = set()
    for phase, folders in boundaries.items():
        for folder in folders:
            all_folders.add(folder)

    for folder in all_folders:
        folder_path = project_root / folder
        if not folder_path.exists():
            issues.append({
                'severity': 'WARNING',
                'file': folder,
                'message': f'Designated folder does not exist: {folder}',
                'suggestion': f'Create the {folder} directory'
            })

    return issues


def main():
    """Run folder guard validation."""
    logger = setup_guard_logger('folder_guard')
    root = get_project_root()

    logger.info("Validating folder boundaries...")
    issues = validate_folder_boundaries(root)

    errors = [i for i in issues if i['severity'] == 'ERROR']
    warnings = [i for i in issues if i['severity'] == 'WARNING']

    for issue in errors:
        logger.error(issue['message'])
    for issue in warnings:
        logger.warning(issue['message'])

    if errors:
        logger.error(f"Folder guard FAILED: {len(errors)} error(s)")
        return False
    elif warnings:
        logger.warning(f"Folder guard PASSED with {len(warnings)} warning(s)")
        return True
    else:
        logger.info("Folder guard PASSED")
        return True


if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
