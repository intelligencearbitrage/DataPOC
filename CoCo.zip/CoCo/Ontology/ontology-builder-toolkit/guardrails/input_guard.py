"""
Input Guard - Validates that prompts.md has the required sections.

Checks that developers have filled in the prompts.md template
before the pipeline starts working.
"""

import sys
from pathlib import Path

from logger import setup_guard_logger, get_project_root


REQUIRED_SECTIONS = [
    '## Objective',
    '## Source Materials',
    '## Deliverables',
    '## Components',
    '## Success Criteria',
]

PLACEHOLDER_MARKERS = [
    '[YOUR PROJECT NAME]',
    '[DESCRIBE YOUR',
    '[Description]',
    '[Excel/SQL/JSON/XML/CSV]',
    '[Component',
    '[Criterion',
    '[Constraint',
]


def validate_prompts(prompts_path: Path) -> list:
    """Validate prompts.md content."""
    issues = []

    if not prompts_path.exists():
        issues.append({
            'severity': 'ERROR',
            'file': str(prompts_path),
            'message': 'prompts.md not found',
            'suggestion': 'Create prompts.md from the template'
        })
        return issues

    content = prompts_path.read_text(encoding='utf-8')

    # Check required sections exist
    for section in REQUIRED_SECTIONS:
        if section not in content:
            issues.append({
                'severity': 'ERROR',
                'file': str(prompts_path),
                'message': f'Missing required section: {section}',
                'suggestion': f'Add {section} to prompts.md'
            })

    # Check for unfilled placeholders
    for marker in PLACEHOLDER_MARKERS:
        if marker in content:
            issues.append({
                'severity': 'WARNING',
                'file': str(prompts_path),
                'message': f'Unfilled placeholder found: {marker}',
                'suggestion': f'Replace "{marker}" with your project-specific content'
            })

    return issues


def main():
    """Run input guard validation."""
    logger = setup_guard_logger('input_guard')
    root = get_project_root()
    prompts_path = root / 'prompts.md'

    logger.info("Validating prompts.md...")
    issues = validate_prompts(prompts_path)

    errors = [i for i in issues if i['severity'] == 'ERROR']
    warnings = [i for i in issues if i['severity'] == 'WARNING']

    for issue in errors:
        logger.error(issue['message'])
    for issue in warnings:
        logger.warning(issue['message'])

    if errors:
        logger.error(f"Input guard FAILED: {len(errors)} error(s)")
        return False
    elif warnings:
        logger.warning(f"Input guard PASSED with {len(warnings)} warning(s)")
        return True
    else:
        logger.info("Input guard PASSED")
        return True


if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
