"""
Phase Guard - Enforces phase dependency rules.

Checks that prerequisites for each phase are met before
allowing that phase to proceed. Uses completion markers
defined in GUARDRAILS.yaml.
"""

import sys
from pathlib import Path

from logger import setup_guard_logger, get_project_root, load_guardrails_config


def check_phase_prerequisites(project_root: Path) -> list:
    """Check that phase prerequisites are satisfied."""
    issues = []
    config = load_guardrails_config()
    phase_gates = config.get('phase_gates', {})

    if not phase_gates:
        issues.append({
            'severity': 'WARNING',
            'file': 'GUARDRAILS.yaml',
            'message': 'No phase_gates defined',
            'suggestion': 'Define phase_gates in GUARDRAILS.yaml'
        })
        return issues

    # Check completion markers based on phase output directories
    phase_outputs = {
        'gate_1': 'research/',
        'gate_2': 'plans/',
        'gate_3': 'scripts/',
        'gate_4': 'testscripts/',
    }

    completed_phases = set()
    for gate_name, output_dir in phase_outputs.items():
        dir_path = project_root / output_dir
        if dir_path.exists():
            real_files = [
                f for f in dir_path.iterdir()
                if f.name != '.gitkeep'
            ]
            if real_files:
                completed_phases.add(gate_name)

    # Report which gates are not yet satisfied
    for gate_name, gate_config in phase_gates.items():
        before_phase = gate_config.get('before_phase', '')
        if before_phase and gate_name not in completed_phases:
            issues.append({
                'severity': 'INFO',
                'file': phase_outputs.get(gate_name, ''),
                'message': (
                    f'Gate "{gate_config.get("name", gate_name)}" not yet passed: '
                    f'output directory has no content'
                ),
                'suggestion': f'Complete the phase before {before_phase}'
            })

    return issues


def get_current_phase(project_root: Path) -> str:
    """Determine the current phase based on which directories have content."""
    phases_in_order = [
        ('review', 'testscripts/'),
        ('build', 'scripts/'),
        ('planning', 'plans/'),
        ('research', 'research/'),
    ]

    for phase_name, output_dir in phases_in_order:
        dir_path = project_root / output_dir
        if dir_path.exists():
            real_files = [f for f in dir_path.iterdir() if f.name != '.gitkeep']
            if real_files:
                return phase_name

    return "not_started"


def main():
    """Run phase guard validation."""
    logger = setup_guard_logger('phase_guard')
    root = get_project_root()

    logger.info("Validating phase dependencies...")
    current = get_current_phase(root)
    logger.info(f"Current phase: {current}")

    issues = check_phase_prerequisites(root)

    errors = [i for i in issues if i['severity'] == 'ERROR']
    infos = [i for i in issues if i['severity'] == 'INFO']

    for issue in errors:
        logger.error(issue['message'])
    for issue in infos:
        logger.info(issue['message'])

    if errors:
        logger.error(f"Phase guard FAILED: {len(errors)} error(s)")
        return False
    else:
        logger.info(f"Phase guard PASSED ({len(infos)} pending prerequisites)")
        return True


if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
