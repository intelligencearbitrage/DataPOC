# Review Phase

Use this skill during Phase 4 of the pipeline — validating all artifacts and verifying deliverables.

---

## Your Role

You are conducting the **Review phase**. Your job is to validate everything produced by the pipeline: research completeness, plan correctness, script quality, and output accuracy.

---

## Inputs You Read

| Source | Purpose |
|--------|---------|
| `prompts.md` | Original requirements and success criteria |
| `GUARDRAILS.yaml` | Quality standards to check against |
| `research/` | Phase 1 output — were findings complete? |
| `plans/` | Phase 2 output — is the plan sound? |
| `scripts/` | Phase 3 output — do scripts meet standards? |
| `output/` | Runtime output — do deliverables match requirements? |
| `knowledgebase/` | Reference materials for accuracy verification |
| `inputs/` | Source data for completeness verification |
| `thoughts/build_report.yaml` | Build results from `build_all.py` |

---

## Process

### 1. Verify Deliverables Exist

Check every deliverable listed in `prompts.md`:
- Does the file exist in `output/`?
- Is it non-empty and well-formed?
- Does it match the expected format?

### 2. Verify Success Criteria

For each success criterion in `prompts.md`:
- Can it be verified automatically? If so, verify it.
- What evidence supports that it's met?
- If not met, what's missing?

### 3. Verify Completeness Against Source

Compare `output/` against `inputs/`:
- Is all source data accounted for in the output?
- Are there items in the source that don't appear in the output? (potential data loss)
- Are there items in the output that don't appear in the source? (potential hallucination)

### 4. Verify Standards Compliance

Check output against `knowledgebase/` rules:
- Naming conventions followed?
- Data type mappings correct?
- Required fields present?
- Structure matches expected format?

### 5. Snowflake Validation

If output contains SQL/DDL:
```
snowflake_sql_execute(sql=<content_of_sql_file>, only_compile=true)
```

Verify every SQL file compiles. Report compilation errors as HIGH severity issues.

### 6. Run Guardrails

```bash
python guardrails/run_guardrails.py
```

Report any guardrail failures.

---

## Output: Review Report

Write to `testscripts/review_report.yaml`:

```yaml
review_report:
  timestamp: "YYYY-MM-DD HH:MM:SS"
  overall_verdict: PASS | FAIL

  deliverables:
    - file: "output/path/to/file.ext"
      exists: true | false
      valid_format: true | false
      notes: "Any issues"

  success_criteria:
    - criterion: "From prompts.md"
      met: true | false
      evidence: "How this was verified"
      notes: "Additional context"

  completeness:
    source_items_total: 0
    source_items_in_output: 0
    coverage_percent: 0.0
    missing_items:
      - source: "inputs/file.ext"
        item: "What's missing"
        severity: HIGH | MEDIUM | LOW

  standards_compliance:
    naming_conventions: PASS | FAIL
    data_type_mappings: PASS | FAIL
    required_fields: PASS | FAIL
    notes: []

  sql_validation:
    files_checked: 0
    compilation_pass: 0
    compilation_fail: 0
    errors:
      - file: "output/path.sql"
        error: "compilation error message"

  guardrails:
    overall: PASS | FAIL
    details: "Summary from guardrails run"

  issues:
    - id: "R-001"
      severity: ERROR | WARNING | INFO
      category: "missing_content | incorrect_output | standards_violation | compilation_error"
      description: "What's wrong"
      file: "Which file"
      suggestion: "How to fix"

  summary:
    total_issues: 0
    errors: 0
    warnings: 0
    info: 0
    recommendation: "APPROVE | FIX_REQUIRED | NEEDS_DISCUSSION"
```

---

## Handling Issues Found

| Severity | Action |
|----------|--------|
| ERROR | Must be fixed before approval. Report clearly. |
| WARNING | Should be fixed but not blocking. Note in report. |
| INFO | Observation only. May inform future improvements. |

If errors are found:
- Document them clearly in the review report
- The orchestrator will present them to the user at Gate 4
- The user decides whether to fix (go back to Phase 3) or accept as-is

---

## Quality Checklist (Self-Review)

Before completing Phase 4:
- [ ] `testscripts/review_report.yaml` exists and is complete
- [ ] Every deliverable in prompts.md is checked
- [ ] Every success criterion is verified
- [ ] Source-to-output completeness is measured
- [ ] Standards compliance is checked
- [ ] SQL compilation is verified (if applicable)
- [ ] Guardrails have been run
- [ ] All issues have severity, description, and suggestion
- [ ] Overall verdict is honest (FAIL if any ERRORs exist)

---

## Folder Boundaries

- **Write to**: `testscripts/`
- **Never write to**: `research/`, `plans/`, `scripts/`, `output/`, `knowledgebase/`, `inputs/`
