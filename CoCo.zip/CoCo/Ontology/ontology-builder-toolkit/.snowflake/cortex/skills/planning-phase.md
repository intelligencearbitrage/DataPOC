# Planning Phase

Use this skill during Phase 2 of the pipeline — synthesizing research findings into actionable plans.

---

## Your Role

You are conducting the **Planning phase**. Your job is to synthesize all research findings from `research/` into a coherent master plan and component plans in `plans/`.

---

## Inputs You Read

| Source | Purpose |
|--------|---------|
| `research/` | All structured findings from Phase 1 |
| `research/expert/` | Any expert consultation results |
| `prompts.md` | Requirements — deliverables, components, success criteria |
| `knowledgebase/` | Reference materials (for verification) |
| `GUARDRAILS.yaml` | Quality standards and constraints |

---

## Process

### 1. Synthesize Research

Read all YAML files in `research/`. For each:
- Extract key findings relevant to the deliverables
- Note gaps that need resolution
- Identify conflicts between sources

### 2. Resolve Conflicts

When research sources disagree:
- Determine which source is authoritative (check `prompts.md` for hierarchy)
- Document the conflict and resolution in the plan
- If unclear, use `ask_user_question` to get direction

### 3. Create MASTER_PLAN.yaml

This is the single source of truth for Phase 3 (Build):

```yaml
metadata:
  date: "YYYY-MM-DD"
  based_on:
    - "research/file1.yaml"
    - "research/file2.yaml"
  conflicts_resolved:
    - description: "What conflicted"
      resolution: "How resolved"
      authority: "Which source won"

objective: "Restate the objective from prompts.md"

architecture:
  approach: "High-level approach description"
  data_flow: "inputs/ → scripts/ → output/"
  key_decisions:
    - decision: "What was decided"
      rationale: "Why"
      alternatives_considered: ["Alt 1", "Alt 2"]

components:
  - name: "component_name"
    purpose: "What this component does"
    script_name: "generate_component_name.py"
    base_class: "BaseParser | BaseGenerator"
    inputs:
      - path: "inputs/file.ext"
        usage: "What data is extracted"
      - path: "knowledgebase/reference.yaml"
        usage: "What rules are applied"
    outputs:
      - path: "output/deliverable.ext"
        format: "SQL | YAML | JSON | MD"
        description: "What this file contains"
    logic:
      - step: "1. Read input file"
        detail: "Parse X format, extract Y"
      - step: "2. Apply transformation"
        detail: "Map types using knowledgebase/type_mappings.yaml"
      - step: "3. Generate output"
        detail: "Produce Snowflake DDL following naming conventions"
    dependencies: ["other_component_name"]
    complexity: LOW | MEDIUM | HIGH
    known_gaps:
      - "Gap from research that affects this component"

success_criteria:
  - criterion: "From prompts.md"
    how_verified: "Specific check to perform"
    component: "Which component produces this"

execution_order:
  - "component_1 (no dependencies)"
  - "component_2 (depends on component_1)"
  - "component_3 (no dependencies, can run parallel)"

risks:
  - risk: "What could go wrong"
    likelihood: LOW | MEDIUM | HIGH
    mitigation: "How to handle it"
```

### 4. Create Component Plans (for complex components)

If a component has HIGH complexity or needs detailed specification, create a separate file:
`plans/component_name_plan.yaml`

### 5. Verify Completeness

Cross-check the plan against `prompts.md`:
- Every deliverable has a component that produces it
- Every success criterion has a verification method
- Every component in prompts.md is in the plan

---

## Snowflake Enhancements

When the project targets Snowflake:
- Use `snowflake_product_docs` to verify DDL syntax choices
- Note which outputs will need `snowflake_sql_execute(only_compile=true)` validation
- Reference Snowflake-specific data types, features, or limitations in the plan

---

## Devil's Advocate Challenge

After the plan is complete, the orchestrator will spawn a Devil's Advocate subagent to challenge it. Prepare for these challenges by ensuring:
- Every decision has a rationale
- Alternatives were considered
- Edge cases are acknowledged
- The plan maps completely to requirements

If the DA returns FAIL, you must address every blocking weakness before the plan can be approved.

---

## Quality Checklist (Self-Review)

Before completing Phase 2:
- [ ] `plans/MASTER_PLAN.yaml` exists and is complete
- [ ] Every deliverable in `prompts.md` has a component
- [ ] Every component has inputs, outputs, and logic steps
- [ ] Conflicts between research sources are resolved and documented
- [ ] Execution order accounts for dependencies
- [ ] Success criteria have specific verification methods
- [ ] Known gaps from research are acknowledged with mitigations
- [ ] No fabricated logic — everything traces to research findings

---

## Folder Boundaries

- **Write to**: `plans/`
- **Never write to**: `research/`, `scripts/`, `output/`, `knowledgebase/`, `inputs/`
