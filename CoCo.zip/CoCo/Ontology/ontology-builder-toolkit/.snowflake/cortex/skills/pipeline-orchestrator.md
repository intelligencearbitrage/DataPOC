# Pipeline Orchestrator

Use this skill when the user says "start project", "run pipeline", "orchestrate", or "begin the 4-phase workflow".

---

## Overview

You are orchestrating a 4-phase pipeline that turns requirements (`prompts.md`) into runnable Python scripts that produce deliverables. The phases are:

1. **Research** — Analyze `knowledgebase/` materials, produce structured findings
2. **Planning** — Synthesize research into actionable plans with a master plan
3. **Build** — Create Python scripts that generate the deliverables
4. **Review** — Validate everything, run scripts, verify output

Each phase is separated by a **quality gate** requiring user approval.

---

## Step 1: Initialize

Read these files to understand the project:

1. `prompts.md` — what to build, source materials, deliverables, success criteria
2. `GUARDRAILS.yaml` — quality rules, folder boundaries, phase gates
3. Scan `knowledgebase/` — list all reference materials available

Then create a todo list (`system_todo_write`) with all phases broken into tasks:

```
Phase 1: Research
- Analyze each file in knowledgebase/
- Document findings in research/ as YAML
- Identify gaps and assumptions
- Run guardrails check
- Gate 1: Present research summary for user review

Phase 2: Planning
- Synthesize research into MASTER_PLAN.yaml
- Create component plans for each deliverable
- Spawn devil's advocate subagent to challenge the plan
- Gate 2 (MANDATORY): Present plan for user approval

Phase 3: Build
- Create scripts for each component (extending BaseParser/BaseGenerator)
- For each script: spawn peer-review subagent
- For each script: spawn devil's advocate subagent
- Run build_all.py to verify scripts work
- Gate 3: Present build output for user review

Phase 4: Review
- Validate all deliverables against success criteria
- Validate generated SQL compiles (if applicable)
- Write review report to testscripts/
- Gate 4: Present final review for user approval
```

---

## Step 2: Execute Phase 1 — Research

Load the `research-phase` skill mentally (read `.snowflake/cortex/skills/research-phase.md`).

For each file in `knowledgebase/`:
1. Read the file
2. Extract key information: structure, relationships, standards, rules
3. Note naming conventions, data types, hierarchies, dependencies
4. Identify gaps — what's missing or ambiguous?

Write findings to `research/` as YAML files with this structure:
```yaml
metadata:
  source_file: "knowledgebase/filename.ext"
  date: "YYYY-MM-DD"
  confidence: HIGH | MEDIUM | LOW
summary: "One-paragraph summary of what was found"
findings:
  - category: "..."
    detail: "..."
    source_reference: "line/section in source"
gaps:
  - description: "What's missing or unclear"
    impact: "How this affects the deliverables"
    recommendation: "How to resolve"
```

**Snowflake enhancement:** If the project involves Snowflake objects, use `snowflake_object_search` to discover existing schemas/tables and `snowflake_product_docs` to research relevant features.

**Clarifications:** If you encounter business/domain ambiguity, use `ask_user_question` immediately. Do not assume.

After all research is complete, run guardrails:
```bash
python guardrails/run_guardrails.py
```

---

## Step 3: Gate 1 — Research Review

Use `ask_user_question` to present a summary:
- Number of files analyzed
- Key findings (bullet points)
- Gaps identified
- Questions that need answers

Options: "Approve and continue to Planning" / "I have feedback"

If the user has feedback, incorporate it and update research files before proceeding.

---

## Step 4: Execute Phase 2 — Planning

Load the `planning-phase` skill mentally.

1. Read all files in `research/`
2. Cross-reference findings — resolve conflicts between sources
3. Create `plans/MASTER_PLAN.yaml`:

```yaml
metadata:
  date: "YYYY-MM-DD"
  based_on: ["research/file1.yaml", "research/file2.yaml"]
objective: "Restate from prompts.md"
components:
  - name: "component_name"
    purpose: "What this component does"
    script: "scripts/generate_component_name.py"
    inputs: ["inputs/...", "knowledgebase/..."]
    outputs: ["output/..."]
    dependencies: []
success_criteria:
  - criterion: "From prompts.md"
    how_verified: "How to check"
```

4. Create individual component plan files in `plans/` for complex components.

5. **Spawn Devil's Advocate subagent:**

```
task(
  description: "DA challenges plan",
  subagent_type: "generalPurpose",
  prompt: """
  You are the Devil's Advocate. Review this plan for weaknesses.

  PLAN: [paste MASTER_PLAN.yaml content]
  REQUIREMENTS: [paste prompts.md content]
  RESEARCH: [paste key research findings]

  Challenge:
  1. Are decisions backed by evidence from research/?
  2. Are alternative approaches considered?
  3. Are ALL requirements in prompts.md addressed?
  4. Are edge cases and failure modes handled?
  5. Is anything over-engineered or under-specified?

  Return a structured verdict:
  - VERDICT: PASS or FAIL
  - STRENGTHS: What's solid
  - WEAKNESSES: What needs fixing (if FAIL, these are blocking)
  - SUGGESTIONS: Non-blocking improvements
  """
)
```

If DA returns FAIL: address the weaknesses, update the plan, re-run DA. Repeat until PASS.

---

## Step 5: Gate 2 — Plan Approval (MANDATORY)

This is the highest-leverage checkpoint. A wrong plan wastes all of Phase 3.

Use `ask_user_question` to present:
- The master plan summary
- Component breakdown
- DA verdict and any resolved issues
- Any remaining concerns

The user MUST explicitly approve before Phase 3 begins. If they request changes, update the plan and re-present.

---

## Step 6: Execute Phase 3 — Build

Load the `build-phase` skill mentally.

For each component in the master plan:
1. Create a Python script in `scripts/` that extends `BaseParser` or `BaseGenerator`
2. The script must:
   - Read from `inputs/` and/or `knowledgebase/`
   - Apply transformation logic based on the plan
   - Write deliverables to `output/`
   - Follow all code quality standards from CLAUDE.md

3. **For each script, spawn two subagents in parallel:**

Peer Review:
```
task(
  description: "Peer review script_name.py",
  subagent_type: "generalPurpose",
  readonly: true,
  prompt: """
  Review this Python script for quality, correctness, and plan adherence.

  SCRIPT: [paste script content]
  PLAN: [paste relevant component plan]
  STANDARDS: type hints, docstrings, pathlib, error handling, idempotent, no hardcoded values

  Check:
  1. Does it implement the plan correctly?
  2. Does it handle edge cases and errors?
  3. Does it follow the code standards?
  4. Is it idempotent and reproducible?

  Return: PASS or FAIL with specific issues to fix.
  """
)
```

Devil's Advocate:
```
task(
  description: "DA challenges script_name.py",
  subagent_type: "generalPurpose",
  readonly: true,
  prompt: """
  Challenge this script's assumptions and logic.

  SCRIPT: [paste script content]
  SOURCE DATA DESCRIPTION: [describe what's in inputs/]
  EXPECTED OUTPUT: [describe what should be in output/]

  Challenge:
  1. What happens with malformed/missing input?
  2. Are there silent data-loss scenarios?
  3. Does the logic correctly handle all known patterns from research?
  4. Are there assumptions that should be explicit?

  Return: PASS or FAIL with specific concerns.
  """
)
```

4. If either review returns FAIL, fix the issues and re-run the failing review.

5. After all scripts pass review, run:
```bash
python scripts/build_all.py
```

6. **Snowflake enhancement:** If scripts produce SQL/DDL, validate with:
```
snowflake_sql_execute(sql=<generated_sql>, only_compile=true)
```

---

## Step 7: Gate 3 — Build Review

Use `ask_user_question` to present:
- Scripts created and their purposes
- Peer review and DA results
- Build output (success/failure)
- Any generated output in `output/`

---

## Step 8: Execute Phase 4 — Review

Load the `review-phase` skill mentally.

1. Verify all deliverables in `output/` exist and match `prompts.md` requirements
2. Check each success criterion from `prompts.md`
3. Run content guardrails on output
4. If SQL output exists, validate it compiles against Snowflake
5. Write `testscripts/review_report.yaml`:

```yaml
review_report:
  timestamp: "YYYY-MM-DD HH:MM:SS"
  deliverables_verified:
    - file: "output/..."
      exists: true
      valid: true
      notes: ""
  success_criteria:
    - criterion: "From prompts.md"
      met: true | false
      evidence: "How verified"
  issues:
    - severity: ERROR | WARNING
      description: "..."
      file: "..."
      suggestion: "..."
  overall: PASS | FAIL
```

---

## Step 9: Gate 4 — Final Approval

Use `ask_user_question` to present:
- Review report summary
- All success criteria status
- Any remaining issues
- Option to proceed to Layer 2 (agentic loop) for refinement

---

## Step 10: (Optional) Layer 2 — Agentic Loop

If the user wants automated refinement, load the `agentic-loop` skill.

---

## Key Rules

- **Never skip a gate.** Even if you're confident, the user must approve.
- **Gate 2 is MANDATORY.** No exceptions.
- **DA FAIL is a hard block.** Fix the issues before proceeding.
- **Write to the correct folders only.** Respect GUARDRAILS.yaml boundaries.
- **Scripts produce deliverables, not you directly.** Never write to `output/` yourself.
- **Evidence over assumption.** Every decision traces to a source file.
- **Use `ask_user_question` for all gates and clarifications.** Never ask in plain text.
