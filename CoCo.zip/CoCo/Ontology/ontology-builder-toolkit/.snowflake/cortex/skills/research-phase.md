# Research Phase

Use this skill during Phase 1 of the pipeline — analyzing reference materials in `knowledgebase/` and producing structured findings.

---

## Your Role

You are conducting the **Research phase**. Your job is to thoroughly analyze all materials in `knowledgebase/` and produce structured findings in `research/`.

---

## Inputs You Read

| Source | Purpose |
|--------|---------|
| `knowledgebase/` | All reference materials — standards, conventions, type mappings, schemas, examples |
| `prompts.md` | Requirements — tells you what to look for and what matters |
| `GUARDRAILS.yaml` | Quality standards — tells you what format your output must follow |

---

## Process

### 1. Discover

List all files in `knowledgebase/`. For each file, note:
- File format (YAML, MD, SQL, JSON, Excel, etc.)
- Apparent purpose (from filename and first few lines)
- Size/complexity

### 2. Analyze Each File

For each file, extract:
- **Structure**: How is the information organized? Tables, hierarchies, key-value pairs?
- **Content**: What specific information does it contain? Data types, naming rules, mappings?
- **Relationships**: How does this file relate to others? Does it reference or depend on other files?
- **Relevance**: Which deliverables (from `prompts.md`) does this inform?

### 3. Cross-Reference

After analyzing all files individually:
- Are there conflicts between sources? (e.g., two files define different naming conventions)
- Are there redundancies?
- What's the authoritative source for each type of information?

### 4. Identify Gaps

For each deliverable in `prompts.md`, ask:
- Do I have enough information to build this?
- What's missing from the reference materials?
- What assumptions would I have to make?

---

## Output Format

Write one YAML file per source file (or logical group) to `research/`:

```yaml
metadata:
  source_file: "knowledgebase/filename.ext"
  date: "YYYY-MM-DD"
  confidence: HIGH | MEDIUM | LOW
  relevance_to:
    - "component_name from prompts.md"

summary: |
  One-paragraph summary of what this file contains and how it's relevant
  to the project requirements.

findings:
  - category: "data_types | naming | structure | relationships | rules"
    detail: "Specific finding"
    source_reference: "line number, section name, or cell reference"
    implications: "What this means for the deliverables"

gaps:
  - description: "What's missing or unclear"
    impact: HIGH | MEDIUM | LOW
    affects: "Which deliverable or component"
    recommendation: "How to resolve (clarify with user / assume X / research further)"
```

---

## Snowflake Enhancements

When the project involves Snowflake:

- **Schema discovery**: Use `snowflake_object_search` to find existing tables, views, or schemas that relate to the project
- **Feature research**: Use `snowflake_product_docs` to look up Snowflake-specific syntax, data types, or features mentioned in the knowledgebase
- **Validation context**: Note which generated SQL will need compilation validation later

---

## Quality Checklist (Self-Review)

Before completing Phase 1:
- [ ] Every file in `knowledgebase/` has been analyzed
- [ ] All findings are in `research/` as YAML
- [ ] Each finding references its source (file + location)
- [ ] Gaps are documented with impact assessment
- [ ] No fabricated information — everything traces to a source
- [ ] Confidence levels are honest (MEDIUM/LOW when uncertain)
- [ ] Format matches GUARDRAILS.yaml content_standards

---

## Handling Ambiguity

- **Technical ambiguity** (e.g., unclear file format): Make a reasonable assumption, document it as LOW confidence, proceed.
- **Business/domain ambiguity** (e.g., which naming convention to use when sources conflict): Use `ask_user_question` immediately. Do not assume business decisions.
- **Missing information** (e.g., no type mapping for a specific data type): Document as a gap with HIGH impact. The planning phase will need to address this.

---

## Folder Boundaries

- **Write to**: `research/`
- **Never write to**: `plans/`, `scripts/`, `output/`, `knowledgebase/`, `inputs/`
