# Build Phase

Use this skill during Phase 3 of the pipeline — creating Python scripts that produce deliverables.

---

## Your Role

You are conducting the **Build phase**. Your job is to create Python scripts in `scripts/` that, when run, produce the deliverables defined in the master plan.

---

## Key Principle

**You write CODE (scripts). Scripts produce DELIVERABLES.**

Never write directly to `output/`. Always create a script that does it — making deliverables reproducible without AI.

---

## Inputs You Read

| Source | Purpose |
|--------|---------|
| `plans/MASTER_PLAN.yaml` | Blueprint — what to build, in what order |
| `plans/*.yaml` | Detailed component plans |
| `knowledgebase/` | Reference materials the scripts will use at runtime |
| `scripts/base_parser.py` | Base class for input-processing scripts |
| `scripts/base_generator.py` | Base class for output-generating scripts |
| `scripts/utils.py` | Shared utilities (YAML I/O, logging, paths) |

---

## Process

### 1. Read the Plan

Load `plans/MASTER_PLAN.yaml`. For each component in `execution_order`:
- Understand what the script must do
- Identify inputs it reads and outputs it produces
- Note the logic steps and any dependencies

### 2. Create Each Script

For each component, create `scripts/generate_<component_name>.py` (or `scripts/parse_<component_name>.py` for input parsers):

```python
"""
<Component Name> - <one-line description>.

Reads: <input files>
Produces: <output files>
"""

from pathlib import Path
from typing import Any, Dict, List

from base_generator import BaseGenerator  # or BaseParser
from utils import load_yaml, save_yaml, setup_logging


class <ComponentName>Generator(BaseGenerator):
    """Generates <deliverable> from <inputs>."""

    def __init__(self):
        super().__init__(plans_dir='plans', output_dir='output')
        self.knowledgebase_dir = Path('knowledgebase')

    def generate(self) -> None:
        """Generate the <deliverable>."""
        # 1. Load plans and reference data
        plan = self.load_master_plan()
        reference = load_yaml(self.knowledgebase_dir / 'reference.yaml')

        # 2. Process inputs
        # ... transformation logic ...

        # 3. Generate output
        output_content = self._build_output(...)
        self.save_output(output_content, '<deliverable_path>')


def main():
    """Entry point for build_all.py discovery."""
    generator = <ComponentName>Generator()
    generator.generate()


if __name__ == '__main__':
    main()
```

### 3. Follow Code Standards

Every script MUST:
- [ ] Extend `BaseParser` or `BaseGenerator`
- [ ] Have a module-level docstring
- [ ] Have type hints on all functions
- [ ] Have Google-style docstrings on public methods
- [ ] Use `pathlib` for all file paths
- [ ] Include `try/except` for file I/O operations
- [ ] Read configuration from plans (no hardcoded values)
- [ ] Be idempotent (safe to re-run — overwrite, don't append)
- [ ] Have a `main()` function (for `build_all.py` discovery)
- [ ] Be independently runnable (`if __name__ == '__main__': main()`)

### 4. Handle the Data Flow Correctly

```
knowledgebase/  ──(rules/standards)──→  script  ──→  output/
inputs/         ──(source data)──────→
plans/          ──(configuration)────→
```

- Scripts reference `knowledgebase/` for **rules** (type mappings, naming conventions)
- Scripts read `inputs/` for **source data** to transform
- Scripts read `plans/` for **configuration** (what to produce, in what structure)
- Scripts write ONLY to `output/`

### 5. Verify the Build

After all scripts are written:
```bash
python scripts/build_all.py
```

Check:
- All scripts discovered and run successfully
- Output files appear in `output/`
- No errors in `thoughts/build_report.yaml`

### 6. Snowflake Enhancement: Validate SQL Output

If any script produces SQL/DDL:
```
snowflake_sql_execute(sql=<generated_sql_content>, only_compile=true)
```

This validates the SQL compiles without executing it. Fix any syntax errors before marking the script as complete.

---

## Per-Script Review Process

After completing each script, the orchestrator spawns:
1. **Peer Reviewer** — checks code quality, plan adherence, edge cases
2. **Devil's Advocate** — challenges assumptions and logic

Both must PASS before the script is considered done. If either fails:
- Read the specific issues
- Fix the script
- The orchestrator will re-run the failing review

---

## Quality Checklist (Self-Review)

Before completing Phase 3:
- [ ] Every component in the master plan has a script
- [ ] All scripts follow naming convention: `generate_*.py` or `parse_*.py`
- [ ] All scripts extend the correct base class
- [ ] All scripts pass code standards (type hints, docstrings, pathlib, error handling)
- [ ] `build_all.py` runs without errors
- [ ] Output files are produced in `output/`
- [ ] Generated SQL compiles (if applicable)
- [ ] All peer reviews have PASS verdict
- [ ] All DA challenges have PASS verdict

---

## Folder Boundaries

- **Write to**: `scripts/`
- **Never write to**: `research/`, `plans/`, `output/` (directly), `knowledgebase/`, `inputs/`
- **Note**: Scripts you create will write to `output/` when *run* — that's correct. But YOU don't write to `output/` during the build phase.
