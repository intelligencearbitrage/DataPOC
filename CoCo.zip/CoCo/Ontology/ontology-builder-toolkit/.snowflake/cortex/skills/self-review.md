# Self-Review

Use this skill before completing any task or marking a phase as done.

---

## Purpose

This is a quality checklist that should be run before any major checkpoint. It prevents incomplete work from flowing to the next phase.

---

## Checklist

### 1. Requirements Check

- [ ] Re-read the task description or phase objective
- [ ] Every requirement addressed — none skipped
- [ ] No requirements partially done or deferred without documentation

### 2. Output Verification

- [ ] Output file(s) exist at expected path
- [ ] Output format matches expected schema (YAML has required fields, Python has required structure)
- [ ] Output contains real content (not placeholders, not TODO markers)
- [ ] Output is non-empty and well-formed

### 3. Quality Standards Check

- [ ] Meets GUARDRAILS.yaml content standards for this folder
- [ ] Naming conventions followed (snake_case files, correct prefixes)
- [ ] Required fields present in YAML outputs
- [ ] Code standards met in Python outputs (type hints, docstrings, pathlib)

### 4. Consistency Check

- [ ] Output consistent with inputs — no fabricated data
- [ ] File references are valid (paths exist, files are real)
- [ ] Cross-references between files match (component names, deliverable names)
- [ ] No contradictions with other pipeline outputs

### 5. Source Traceability

- [ ] Every claim traces to a source file in `knowledgebase/` or `inputs/`
- [ ] Assumptions are documented explicitly
- [ ] Gaps are noted (not silently ignored)

### 6. Confidence Assessment

Rate your confidence: **HIGH** / **MEDIUM** / **LOW**

| Level | Action |
|-------|--------|
| HIGH | Proceed — mark task complete |
| MEDIUM | Document uncertainty in a note. Proceed but flag at the gate. |
| LOW | Do not mark complete. Escalate: use `ask_user_question` or spawn an expert subagent. |

---

## When to Run

- Before marking any todo as "completed"
- Before presenting work at a gate (ask_user_question checkpoint)
- After making fixes requested by DA or peer review
- Before calling a phase done

---

## Quick Version (for minor tasks)

If the task is small (e.g., writing a single research finding):
1. Does the output exist? Yes/No
2. Is it in the right folder? Yes/No
3. Does it have required fields? Yes/No
4. Is anything fabricated? Yes/No

If all Yes/No correct → proceed.

---

## If Self-Review Fails

- Fix the issues before proceeding
- If you cannot fix (blocked by missing info): escalate with `ask_user_question`
- Never mark a task complete with known failing checks
