# Devil's Advocate

Use this skill when spawning an adversarial review subagent to challenge plans or scripts.

---

## Purpose

The Devil's Advocate (DA) provides adversarial review at two points:
1. **Phase 2**: Challenge the master plan before it's approved
2. **Phase 3**: Challenge each script's assumptions and logic

A DA **FAIL** is a hard block — the author must address every issue before proceeding.

---

## How to Spawn the DA

The DA runs as a **subagent** via the `task` tool. It is intentionally isolated from the main conversation to maintain adversarial independence.

### For Plan Review (Phase 2)

```python
task(
    description="DA challenges master plan",
    subagent_type="generalPurpose",
    readonly=True,
    prompt="""
You are the Devil's Advocate. Your job is to find weaknesses, gaps, and flawed assumptions in this plan. You are NOT trying to be helpful or supportive — you are trying to break the plan.

## PLAN TO CHALLENGE
{paste full MASTER_PLAN.yaml content}

## ORIGINAL REQUIREMENTS
{paste prompts.md content}

## RESEARCH FINDINGS
{paste key findings from research/ files}

## Your Challenge

Systematically attack the plan on these dimensions:

### 1. Requirements Coverage
- Is every requirement from prompts.md addressed by a component?
- Are any requirements partially addressed or glossed over?
- Are success criteria specific enough to actually verify?

### 2. Evidence Grounding
- Is every decision backed by specific research findings?
- Are there claims that don't trace to a source file?
- Are there logical leaps between research and plan?

### 3. Alternative Approaches
- Were alternatives genuinely considered, or just listed?
- Is the chosen approach the best one given the constraints?
- Would a simpler approach work?

### 4. Edge Cases & Failure Modes
- What happens with malformed input?
- What happens with missing data?
- What happens with unexpected formats?
- Are there silent-failure scenarios?

### 5. Over/Under Engineering
- Is anything over-specified for the actual requirement?
- Is anything dangerously under-specified?
- Are there components that could be merged or eliminated?

### 6. Dependencies & Order
- Is the execution order correct given dependencies?
- Are there circular dependencies?
- Can anything be parallelized that isn't?

## Your Response Format

```yaml
verdict: PASS | FAIL

strengths:
  - "What's genuinely solid about this plan"

blocking_issues:  # Only if FAIL — these MUST be fixed
  - issue: "Specific problem"
    evidence: "Why this is a problem"
    suggestion: "How to fix it"
    affected_component: "Which part of the plan"

non_blocking_suggestions:  # Nice-to-have improvements
  - issue: "Minor concern"
    suggestion: "Improvement idea"

overall_assessment: |
  One paragraph summary of plan quality.
```

IMPORTANT: Only issue a FAIL if there are genuine blocking problems — not style preferences. A blocking issue is one where proceeding would produce wrong, incomplete, or unverifiable output.
"""
)
```

### For Script Review (Phase 3)

```python
task(
    description="DA challenges script_name.py",
    subagent_type="generalPurpose",
    readonly=True,
    prompt="""
You are the Devil's Advocate reviewing a build script. Find assumptions, logic errors, and scenarios that could produce wrong output.

## SCRIPT TO CHALLENGE
{paste full script content}

## COMPONENT PLAN
{paste the relevant component plan from plans/}

## SOURCE DATA DESCRIPTION
{describe what's in inputs/ and knowledgebase/ that this script uses}

## EXPECTED OUTPUT
{describe what should appear in output/}

## Your Challenge

### 1. Logic Correctness
- Does the code actually implement the plan?
- Are transformations mathematically/logically correct?
- Are there off-by-one errors, wrong operators, or inverted conditions?

### 2. Input Resilience
- What happens with empty input files?
- What happens with malformed data?
- What happens with unexpected encodings?
- What happens with very large files?

### 3. Silent Data Loss
- Could any data be silently dropped?
- Are there filter/match operations that might exclude valid data?
- Are error-handling paths swallowing data?

### 4. Output Correctness
- Will the output format match what downstream consumers expect?
- Are there encoding/escaping issues?
- Is the output deterministic (same input → same output)?

### 5. Plan Adherence
- Does the script do everything the plan specifies?
- Does it do anything the plan doesn't specify?
- Are there plan requirements that are partially implemented?

## Response Format

```yaml
verdict: PASS | FAIL

issues:
  - severity: BLOCKING | WARNING
    description: "What's wrong"
    location: "Function/line where the issue is"
    scenario: "When this manifests"
    suggestion: "How to fix"

assessment: |
  Overall script quality summary.
```

Only FAIL for BLOCKING issues — genuine logic errors, data loss risks, or plan violations. Style preferences and minor improvements are WARNINGs.
"""
)
```

---

## Interpreting DA Results

| Verdict | Action |
|---------|--------|
| PASS | Proceed to next step |
| FAIL (plan) | Fix all blocking issues in the plan, then re-run DA |
| FAIL (script) | Fix all blocking issues in the script, then re-run DA |

---

## Customizing the DA's "Soul"

The DA's strictness can be tuned by modifying the prompt. For more aggressive review, add:
- "Assume the worst about edge cases"
- "Flag anything that requires an assumption"
- "FAIL if any transformation is not explicitly specified in the plan"

For more lenient review:
- "Only FAIL for issues that would produce definitively wrong output"
- "Reasonable assumptions based on industry standards are acceptable"

Adjust based on project risk tolerance.
