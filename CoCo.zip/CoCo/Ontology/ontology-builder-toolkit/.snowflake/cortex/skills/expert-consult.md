# Expert Consultation

Use this skill when domain expertise is needed that goes beyond what's in `knowledgebase/`.

---

## Purpose

Expert consultation provides specialized knowledge on demand. In the original Agent Teams model, these were separate agents. In CoCo, they are spawned as **readonly subagents** that research a specific question and return findings.

---

## Three Expert Types

### 1. Standards Expert

Domain: compliance, regulations, industry best practices, naming conventions.

```python
task(
    description="Consult standards expert",
    subagent_type="generalPurpose",
    readonly=True,
    prompt="""
You are a Standards Expert. Provide authoritative guidance on standards, compliance, and best practices.

## QUESTION
{specific question about standards}

## CONTEXT
- Project: {project description from prompts.md}
- Domain: {relevant domain}
- Current approach: {what's being considered}
- Reference materials available: {list knowledgebase/ files}

## RESEARCH APPROACH
1. Check if Snowflake documentation addresses this (use snowflake_product_docs if relevant)
2. Apply industry standard practices for this domain
3. Check for regulatory or compliance implications
4. Note any platform-specific constraints

## RESPONSE FORMAT
```yaml
question: "Restated question"
recommendation:
  approach: "Recommended approach"
  rationale: "Why this is the right choice"
  standards_referenced:
    - "Standard/regulation/best practice"
  caveats: ["Any exceptions or edge cases"]
  confidence: HIGH | MEDIUM | LOW
alternatives:
  - approach: "Alternative"
    tradeoff: "Why not this one"
```
"""
)
```

### 2. Architecture Expert

Domain: design patterns, system structure, technical approach, scalability.

```python
task(
    description="Consult architecture expert",
    subagent_type="generalPurpose",
    readonly=True,
    prompt="""
You are an Architecture Expert. Provide guidance on design decisions, patterns, and technical approach.

## QUESTION
{specific architecture question}

## CONTEXT
- Project: {project description}
- Current architecture: {describe current approach}
- Constraint: {relevant constraints}
- Scale: {data volume, complexity expectations}

## RESPONSE FORMAT
```yaml
question: "Restated question"
recommendation:
  pattern: "Recommended pattern/approach"
  rationale: "Why this fits"
  diagram: |
    Textual description of the architecture
  tradeoffs:
    - pro: "Advantage"
      con: "Disadvantage"
  implementation_notes:
    - "Practical consideration"
  confidence: HIGH | MEDIUM | LOW
```
"""
)
```

### 3. Quality Expert

Domain: testing strategy, validation approaches, defining "done".

```python
task(
    description="Consult quality expert",
    subagent_type="generalPurpose",
    readonly=True,
    prompt="""
You are a Quality Expert. Define what "done" means and how to verify it.

## QUESTION
{specific quality/testing question}

## CONTEXT
- Project: {project description}
- Deliverables: {what's being produced}
- Success criteria: {from prompts.md}
- Available validation tools: Python scripts, Snowflake SQL compilation, guardrails

## RESPONSE FORMAT
```yaml
question: "Restated question"
recommendation:
  testing_strategy: "Approach to validation"
  verification_methods:
    - check: "What to verify"
      method: "How to verify"
      tool: "Python | SQL | Manual"
      automated: true | false
  acceptance_criteria:
    - criterion: "Specific measurable criterion"
      threshold: "What 'pass' looks like"
  confidence: HIGH | MEDIUM | LOW
```
"""
)
```

---

## When to Consult

| Situation | Expert |
|-----------|--------|
| Naming convention conflict between sources | Standards |
| Compliance or regulatory question | Standards |
| How to structure the script pipeline | Architecture |
| Which base class to use | Architecture |
| Design pattern choice | Architecture |
| What checks to include in review | Quality |
| How to measure output completeness | Quality |
| Whether a gap is blocking or acceptable | Quality |

---

## Saving Expert Results

Expert consultation results should be saved to `research/expert/` as YAML:

```yaml
consultation:
  expert_type: "standards | architecture | quality"
  date: "YYYY-MM-DD"
  question: "What was asked"
  recommendation: "Summary of advice"
  confidence: "HIGH | MEDIUM | LOW"
  impact_on_plan: "How this affects the approach"
```

This ensures expert advice is preserved and can be referenced by later phases.

---

## Snowflake Enhancement

For Snowflake-specific questions, expert subagents can be enhanced:
- Standards: "Use `snowflake_product_docs` to verify Snowflake naming conventions"
- Architecture: "Use `snowflake_product_docs` to research available Snowflake features"
- Quality: "Consider using `snowflake_sql_execute(only_compile=true)` for DDL validation"
