# Agentic Loop (Layer 2)

Use this skill after Phase 4 completes, when the user wants automated output refinement.

---

## Overview

The Agentic Loop is an **optional quality layer** that validates output against source data and iteratively refines it. It sits on top of the scripts layer and patches `output/` files directly.

```
output/ (from scripts)
    │
    ▼
┌──────────────┐
│  VALIDATE    │  Compare output/ vs inputs/ + knowledgebase/
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ HUMAN REVIEW │  User decides: accept / refine / provide feedback
└──────┬───────┘
       │ (if refine)
       ▼
┌──────────────────────────────────────┐
│  AUTOMATED LOOP (max 3 iterations)   │
│  REFINE → RE-VALIDATE → REFINE...   │
└──────────────────────────────────────┘
       │
       ▼
┌──────────────┐
│ FINAL REVIEW │  User accepts final output
└──────────────┘
```

---

## Prerequisites

Before starting the agentic loop:
- Phase 4 (Review) must be complete
- `output/` must contain deliverables
- `inputs/` must contain the source data (ground truth)
- `testscripts/review_report.yaml` should exist (from Phase 4)

---

## Step 1: Initial Validation

Compare every file in `output/` against the source data in `inputs/` and rules in `knowledgebase/`.

### What to Check

| Check | Source of Truth | Method |
|-------|----------------|--------|
| Completeness | `inputs/` | Every item in source appears in output |
| Accuracy | `inputs/` + `knowledgebase/` | Mappings/transformations are correct |
| Standards compliance | `knowledgebase/` | Naming, types, formats follow rules |
| SQL validity | Snowflake engine | `snowflake_sql_execute(sql, only_compile=true)` |

### Snowflake-Enhanced Validation

For SQL/DDL output:
```python
# Validate each SQL file compiles
for sql_file in output_dir.glob('**/*.sql'):
    content = sql_file.read_text()
    # Use CoCo's snowflake_sql_execute with only_compile=true
    # Report compilation errors as HIGH severity issues
```

For semantic comparison (when string-matching isn't enough):
```python
# Use Cortex AI for semantic comparison
# task(subagent_type="generalPurpose", prompt="Compare these two structures semantically...")
```

### Validation Report Format

```yaml
validation_report:
  timestamp: "YYYY-MM-DD HH:MM:SS"
  overall_accuracy: 87.5  # percentage of checks passed
  total_checks: 40
  passed: 35
  failed: 5

  issues:
    - id: "V-001"
      severity: HIGH | MEDIUM | LOW
      category: "missing_content | incorrect_mapping | naming_violation | sql_error"
      description: "What's wrong"
      source_file: "inputs/source.ext (line/section)"
      output_file: "output/target.ext (line/section)"
      expected: "What should be there"
      actual: "What's actually there"
      fix_type: "add | modify | remove"

  passed_checks:
    - "Description of what passed"

  sql_validation:
    files_checked: 5
    compilation_pass: 4
    compilation_fail: 1
    errors:
      - file: "output/schema.sql"
        error: "Snowflake compilation error message"
```

---

## Step 2: Human Review (First Pass)

Present the validation report to the user via `ask_user_question`:

```python
ask_user_question(questions=[{
    "header": "Validation",
    "question": f"Validation found {n_issues} issues ({n_high} high severity). "
                f"Overall accuracy: {accuracy}%. How would you like to proceed?",
    "type": "options",
    "options": [
        {"label": "Accept output as-is", "description": "No refinement needed"},
        {"label": "Refine automatically", "description": f"Run automated fix loop (max 3 iterations)"},
        {"label": "I have feedback", "description": "Add guidance for the refiner"}
    ]
}])
```

If the user provides feedback, validate it before accepting:

### Feedback Validation

| Check | Rule | On Failure |
|-------|------|------------|
| Relevance | Feedback relates to issues in the report or output files | Reject — ask user to clarify |
| Actionability | Feedback can be applied as an output patch | Reject — explain what's not actionable |
| Source consistency | Feedback doesn't contradict `inputs/` or `knowledgebase/` | Reject — explain the contradiction |

---

## Step 3: Automated Refinement Loop

The loop runs **uninterrupted** (no human interaction during iterations).

### Loop Logic

```
for iteration in range(1, max_iterations + 1):
    1. REFINE: Patch output/ files to fix identified issues
    2. RE-VALIDATE: Re-run validation on patched output
    3. CHECK:
       - All issues fixed? → EXIT loop (success)
       - Accuracy improved? → continue to next iteration
       - Accuracy regressed? → ROLLBACK + EXIT (regression breaker)
       - Same issues failing twice? → Skip those issues, mark unresolved
       - Max iterations reached? → EXIT loop
```

### Refiner Rules (from GUARDRAILS.yaml)

| Rule | Constraint |
|------|-----------|
| Output-only writes | Can ONLY modify files in `output/` |
| Diff size cap | Max 50 lines changed per fix |
| Source-grounded | Every patch must reference specific source data |
| No unrelated changes | Only fix the identified issue, no "improvements" |
| No script modification | Never touch `scripts/`, `inputs/`, or `knowledgebase/` |

### How to Refine

For each issue:
1. Read the source data referenced in the issue
2. Read the current output file
3. Determine the minimal patch to fix the issue
4. Apply the patch using the `edit` tool (for text files) or rewrite (for structured data)
5. Log the change

### Snowflake-Enhanced Refinement

For SQL fixes:
1. Apply the patch
2. Re-validate with `snowflake_sql_execute(sql, only_compile=true)`
3. If still fails, try an alternative fix
4. If the fix requires knowledge beyond what's available, mark as unresolved

---

## Step 4: Final Human Review

After the loop exits, present results:

```python
ask_user_question(questions=[{
    "header": "Refinement Complete",
    "question": f"Loop completed ({iterations} iterations). "
                f"Accuracy: {start_accuracy}% → {final_accuracy}%. "
                f"{issues_fixed} issues fixed, {issues_remaining} remaining. "
                f"How would you like to proceed?",
    "type": "options",
    "options": [
        {"label": "Accept output", "description": "Output is good enough"},
        {"label": "Run more iterations", "description": "Try to fix remaining issues"},
        {"label": "I have feedback", "description": "Add guidance and re-run"},
        {"label": "Fix scripts instead", "description": "Go back to Phase 3 to fix root cause"}
    ]
}])
```

---

## Logging

All actions are logged to `thoughts/logs/agentic/`:

```
thoughts/logs/agentic/
├── run_YYYYMMDD_HHMMSS/
│   ├── initial_validation.yaml
│   ├── human_review_1.yaml
│   ├── feedback_validation.yaml (if feedback provided)
│   ├── iteration_1_refine.yaml
│   ├── iteration_1_validate.yaml
│   ├── iteration_2_refine.yaml
│   ├── iteration_2_validate.yaml
│   ├── accuracy_progression.yaml
│   └── run_summary.yaml
```

### Accuracy Progression Format

```yaml
progression:
  - stage: "initial"
    accuracy: 87.5
    issues_found: 5
  - stage: "iteration_1"
    accuracy: 93.0
    issues_fixed: 3
    issues_remaining: 2
  - stage: "iteration_2"
    accuracy: 95.5
    issues_fixed: 1
    issues_remaining: 1
trend: "improving"
exit_reason: "max_iterations | all_fixed | regression | stale"
```

---

## Safety Guardrails

| Guardrail | What Happens |
|-----------|-------------|
| Max iterations reached (default: 3) | Loop exits → human review |
| Accuracy regresses | Stop immediately → human review |
| Same issue fails twice | Skip it, mark unresolved |
| Diff > 50 lines | Flag for human review instead of auto-applying |
| Patch not source-grounded | Reject the patch |
| Write outside output/ | Hard block |

---

## Exit Conditions

| Condition | Result |
|-----------|--------|
| User accepts after initial validation | Done — no refinement |
| All issues fixed during loop | Done — present final output |
| Max iterations with remaining issues | Present residual issues to user |
| Accuracy regression | Rollback last iteration, present to user |
| User chooses "fix scripts" | Return to Phase 3 workflow |
