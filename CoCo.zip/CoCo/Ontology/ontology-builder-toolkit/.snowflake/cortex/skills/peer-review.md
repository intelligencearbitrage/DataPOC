# Peer Review

Use this skill when spawning a peer-review subagent to review individual scripts during Phase 3.

---

## Purpose

The Peer Reviewer checks each script for:
- Code quality and standards compliance
- Plan adherence (does it do what the plan says?)
- Edge case handling
- Reproducibility and idempotency

Unlike the Devil's Advocate (which challenges assumptions), the Peer Reviewer focuses on **implementation quality**.

---

## How to Spawn a Peer Review

```python
task(
    description="Peer review generate_<name>.py",
    subagent_type="generalPurpose",
    readonly=True,
    prompt="""
You are a Peer Reviewer. Review this script for quality, correctness, and adherence to the project's coding standards.

## SCRIPT TO REVIEW
{paste full script content}

## COMPONENT PLAN
{paste the relevant component plan this script implements}

## CODING STANDARDS

The script must:
1. Extend BaseParser or BaseGenerator
2. Have a module-level docstring explaining what it does
3. Have type hints on ALL function signatures
4. Have Google-style docstrings on all public methods
5. Use pathlib for all file paths (no os.path or string concatenation)
6. Include try/except for file I/O operations
7. Read configuration from plans/ (no hardcoded paths, values, or magic numbers)
8. Be idempotent (overwrite, don't append; safe to re-run)
9. Have a main() function as entry point
10. Be independently runnable (if __name__ == '__main__': main())
11. Use the utilities from utils.py (load_yaml, save_yaml, setup_logging)

## REVIEW CHECKLIST

### Standards Compliance
- [ ] Module docstring present and descriptive
- [ ] Type hints on all functions
- [ ] Docstrings on public methods
- [ ] pathlib used (no os.path)
- [ ] Error handling on file operations
- [ ] No hardcoded values
- [ ] Extends correct base class
- [ ] Has main() entry point
- [ ] Idempotent behavior

### Plan Adherence
- [ ] Reads the correct input files (as specified in plan)
- [ ] Applies the correct transformations (as specified in plan)
- [ ] Produces the correct output files (as specified in plan)
- [ ] Handles all cases mentioned in the plan
- [ ] Doesn't do things not in the plan (scope creep)

### Code Quality
- [ ] Functions are focused (one responsibility)
- [ ] Variable names are descriptive
- [ ] No code duplication (DRY)
- [ ] Reasonable function length (< 50 lines)
- [ ] Logical structure and flow

### Edge Cases
- [ ] Handles missing input files gracefully
- [ ] Handles empty input files
- [ ] Handles unexpected data formats
- [ ] Produces meaningful error messages

## RESPONSE FORMAT

```yaml
verdict: PASS | FAIL

standards_compliance:
  passed: ["list of standards met"]
  failed: ["list of standards violated"]

plan_adherence:
  correct: ["what's correctly implemented"]
  missing: ["what's in the plan but not in the script"]
  extra: ["what's in the script but not in the plan"]

issues:
  - severity: BLOCKING | WARNING | SUGGESTION
    description: "What's wrong"
    location: "Function or line"
    fix: "How to resolve"

overall: |
  Summary assessment.
```

Only FAIL if there are BLOCKING issues: missing standards compliance, plan violations, or bugs that would produce wrong output. Style suggestions and minor improvements are SUGGESTION level.
"""
)
```

---

## When to Run

- Once per script, after the builder completes it
- Runs in parallel with the Devil's Advocate for the same script
- Both must PASS independently before Gate 3

---

## Handling Results

| Verdict | Action |
|---------|--------|
| PASS | Script is approved; move to next script |
| FAIL | Fix all BLOCKING issues, then re-run peer review |

If a script fails both Peer Review and DA, prioritize DA issues first (they're usually more fundamental), then fix peer review issues.
