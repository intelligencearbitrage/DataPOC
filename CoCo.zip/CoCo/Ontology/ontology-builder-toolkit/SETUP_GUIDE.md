# Setup Guide — CoCo Toolkit Template

## Prerequisites

| Requirement | Version | Purpose |
|-------------|---------|---------|
| Cortex Code (CoCo) Desktop | Latest | IDE and AI orchestration |
| Python | 3.8+ | Script execution |
| PyYAML | Any | YAML I/O in scripts/guardrails |
| Snowflake connection | Active | SQL validation, Cortex AI (optional) |

Install Python dependency:
```bash
pip install pyyaml
```

---

## Step 1: Copy the Template

Copy the `coco-toolkit-template/` folder and rename it for your project:

```bash
cp -r coco-toolkit-template/ my-accelerator/
cd my-accelerator/
```

---

## Step 2: Configure Your Project

### 2.1 Fill `prompts.md`

This is the most important step. Open `prompts.md` and fill in:
- **Objective**: What you're building (one sentence)
- **Source Materials**: What reference materials you'll provide in `knowledgebase/`
- **Deliverables**: What files should appear in `output/` after running scripts
- **Components**: Logical breakdown into script-sized pieces
- **Success Criteria**: How to know the output is correct
- **Constraints**: Technical or business rules

### 2.2 Populate `knowledgebase/`

Add your reference materials:
- Standards documents (naming conventions, coding standards)
- Type mappings (e.g., source-to-target data type maps)
- Example files (gold-standard examples of expected output)
- Schemas (source system schemas, target schemas)
- Rules (business rules, transformation rules)

### 2.3 Populate `inputs/`

Add the source data that scripts will process at runtime:
- Source DDL files
- Data model files (Excel, XML, JSON)
- Configuration files
- Any data that needs to be transformed

### 2.4 Update `GUARDRAILS.yaml`

Change the project name and customize any rules:
```yaml
project:
  name: "Your Project Name"
```

---

## Step 3: Snowflake Configuration (Optional)

If using Snowflake-enhanced features, ensure your CoCo connection is active:
- Warehouse: Used for SQL compilation validation
- Database/Schema: Used for `snowflake_object_search` during research

Add Snowflake details to `prompts.md`:
```markdown
## Snowflake Configuration (Optional)
| Setting | Value |
|---------|-------|
| Target database | `MY_DB` |
| Target schema | `MY_SCHEMA` |
| Warehouse | `MY_WH` |
| Validate DDL? | Yes |
```

---

## Step 4: Run the Pipeline

In CoCo, type:

```
start project
```

This invokes the `pipeline-orchestrator` skill, which will:
1. Read your `prompts.md` and `GUARDRAILS.yaml`
2. Create a todo list with all phases
3. Begin Phase 1 (Research)

---

## Step 5: Interact at Gates

The pipeline will pause at quality gates and ask for your input:

| Gate | When | What You'll See |
|------|------|-----------------|
| Gate 1 | After research | Summary of findings, gaps identified |
| Gate 2 (mandatory) | After planning | Master plan, DA verdict, component breakdown |
| Gate 3 | After build | Scripts created, review results, build output |
| Gate 4 | After review | Review report, success criteria status |

At each gate, you can:
- **Approve** and continue to the next phase
- **Provide feedback** to improve the current phase
- **Request changes** before proceeding

---

## Step 6: Run Scripts (After Pipeline Completes)

Once all gates pass, you have runnable scripts:

```bash
python scripts/build_all.py
```

This discovers all `generate_*.py` scripts and runs them, producing deliverables in `output/`.

---

## Step 7: Optional — Agentic Refinement Loop

If you want automated output refinement:

```
run agentic loop
```

This invokes the `agentic-loop` skill, which validates output against source data and iteratively patches issues.

---

## Customization Guide

### Adding Domain-Specific Skills

Create new skills in `.snowflake/cortex/skills/`:

```markdown
# My Custom Skill

Use this skill when [trigger condition].

---

## Instructions

[What CoCo should do when this skill is active]
```

### Adjusting Devil's Advocate Strictness

Edit `.snowflake/cortex/skills/devils-advocate.md` to tune:
- More aggressive: "Assume the worst about edge cases"
- More lenient: "Only FAIL for definitively wrong output"

### Adding Guardrail Checks

Add Python checks to `guardrails/`:
1. Create `guardrails/my_guard.py` following the pattern in existing guards
2. Import it in `guardrails/run_guardrails.py`
3. Add it to the `guards` list

### Customizing Phase Behavior

Each phase skill (`.snowflake/cortex/skills/*-phase.md`) can be modified:
- Change output format requirements
- Add/remove quality checks
- Adjust Snowflake integration points

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "No generate_*.py scripts found" | Pipeline hasn't completed Phase 3 yet |
| Guardrails failing on placeholders | Fill in `prompts.md` — replace all `[...]` markers |
| SQL validation failing | Check Snowflake connection is active |
| DA keeps failing | Review DA feedback — fix the specific issues raised |
| Scripts produce empty output | Check that `inputs/` has data and `plans/` has component plans |

---

## Architecture at a Glance

```
prompts.md (requirements)
    +
knowledgebase/ (reference)     ──→  Phase 1-4 Pipeline  ──→  scripts/
    +                                                           │
GUARDRAILS.yaml (rules)                                         │
                                                                ▼
                                              python scripts/build_all.py
                                                                │
inputs/ (source data) ──────────────────────────────────────────┘
                                                                │
                                                                ▼
                                                            output/
                                                          (deliverables)
                                                                │
                                                     [optional agentic loop]
                                                                │
                                                                ▼
                                                         output/ (refined)
```

---

## Comparison: Claude Code Agent Teams vs CoCo

| Feature | Original (Agent Teams) | CoCo Port |
|---------|----------------------|-----------|
| Agent definitions | `.claude/agents/*.md` | `.snowflake/cortex/skills/*.md` |
| Orchestration | Autonomous lead agent + shared task list | Sequential skill-guided workflow |
| Task tracking | TaskCreate/TaskUpdate (dependency graph) | `system_todo_write` (flat list) |
| Parallel execution | 11 agents polling independently | Subagents spawned for reviews |
| Quality gates | Task-based human checkpoints | `ask_user_question` gates |
| DA/Peer Review | Separate autonomous agents | Subagents via `task` tool |
| Snowflake integration | None | SQL validation, Cortex AI, object search |
| Memory | Per-agent project memory | `/memories/` system |
| Rules | Path-scoped auto-loaded | Embedded in skill files + CLAUDE.md |
