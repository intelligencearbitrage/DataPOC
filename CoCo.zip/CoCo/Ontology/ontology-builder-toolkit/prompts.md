# Project Requirements — Ontology Builder Toolkit

---

## Objective

Build a **reusable ontology-on-Snowflake stack** from client source table DDL definitions. The pipeline analyzes source schemas, proposes an ontology design (entity types, relationships, hierarchies, aliases), and generates deployable Snowflake SQL for the full stack: ontology metadata tables, convenience/abstract views, a Cortex Analyst semantic view, and a Cortex Agent — with an optional Knowledge Graph extension (KG_NODE/KG_EDGE + traversal procedures).

---

## Source Materials

### knowledgebase/ — Reference Knowledge

| File | Contains |
|------|----------|
| `knowledgebase/ontology_ddl_templates.sql` | CREATE TABLE DDL for ONT_ENTITY_TYPES, ONT_RELATIONSHIP_TYPES, ONT_HIERARCHIES, ONT_ALIASES, KG_NODE, KG_EDGE |
| `knowledgebase/ontology_design_patterns.md` | Rules for entity classification, relationship naming, hierarchy design, alias mapping |
| `knowledgebase/decision_framework.md` | When to use lightweight (Phase A) vs full KG (Phase B) — signals, trade-offs |
| `knowledgebase/semantic_view_patterns.sql` | CREATE SEMANTIC VIEW DDL examples with all clause types |
| `knowledgebase/agent_spec_patterns.yaml` | CREATE AGENT FROM SPECIFICATION examples with tool routing |
| `knowledgebase/naming_conventions.md` | Naming rules for all generated objects (views, tables, agents) |
| `knowledgebase/owl_import_patterns.md` | OWL → Snowflake mapping rules, XSD type conversion, merge rules for OWL + schema |
| `knowledgebase/schema_introspection_reference.md` | What the schema introspection script infers, confidence levels, command-line usage |

### inputs/ — Source Data to Process

| File | Format | Contains | Required? |
|------|--------|----------|-----------|
| `inputs/source_ddl.sql` | SQL DDL | CREATE TABLE statements for the client's source tables | Yes (auto-generated via `generate_inputs_from_schema.py` or manual) |
| `inputs/business_glossary.yaml` | YAML | Business term definitions, synonyms, and abbreviations | Yes (draft auto-generated, needs SME review) |
| `inputs/business_questions.yaml` | YAML | Natural language questions users want the agent to answer | Yes (template auto-generated, needs real questions) |
| `inputs/config.yaml` | YAML | Target database, schema, ontology name, path choice (lightweight/KG/both) | Yes (auto-generated) |
| `inputs/*.owl` or `*.ttl` | OWL/RDF/Turtle | Formal ontology from Protege or industry standard (FIBO, SNOMED, etc.) | Optional — alternative/supplement to schema-first discovery |

**Three ways to populate inputs/:**
1. **Auto-generate from Snowflake schema** — `python scripts/generate_inputs_from_schema.py --database X --schema Y`
2. **Import from OWL/Protege** — Place `.owl`/`.ttl` files in `inputs/`, run `python scripts/parse_owl.py`
3. **Manually create** — Write the YAML/SQL files by hand (smallest schemas only)

---

## Deliverables

| Deliverable | Format | Location | Description |
|-------------|--------|----------|-------------|
| Schema creation | SQL | `output/00_create_schema.sql` | CREATE DATABASE/SCHEMA if needed |
| Ontology metadata | SQL | `output/01_ontology_metadata.sql` | ONT_ENTITY_TYPES, ONT_RELATIONSHIP_TYPES, ONT_HIERARCHIES, ONT_ALIASES with INSERT statements |
| Convenience views | SQL | `output/02_convenience_views.sql` | V_* entity views, V_* relationship views, VW_ONT_* abstract views |
| Semantic view | SQL | `output/03_semantic_view.sql` | CREATE SEMANTIC VIEW with TABLES, RELATIONSHIPS, FACTS, DIMENSIONS, METRICS, AI_SQL_GENERATION |
| Cortex Agent | SQL | `output/04_cortex_agent.sql` | CREATE AGENT FROM SPECIFICATION with tools and routing |
| KG tables (optional) | SQL | `output/05_kg_tables.sql` | KG_NODE + KG_EDGE creation + data loading |
| KG procedures (optional) | SQL | `output/06_kg_procedures.sql` | FIND_PATH, GET_CONNECTED_ENTITIES, GET_BLAST_RADIUS stored procedures |
| Deployment manifest | YAML | `output/deployment_manifest.yaml` | Ordered list of scripts to execute, object inventory |

---

## Components

1. **Schema Profiler** (`parse_schema.py`) — Reads source DDL from `inputs/`, extracts table structures, detects FKs, classifies tables as entity/relationship/lookup, identifies hierarchies from column patterns.

2. **Ontology Metadata Generator** (`generate_ontology_metadata.py`) — Produces ONT_ENTITY_TYPES, ONT_RELATIONSHIP_TYPES, ONT_HIERARCHIES, ONT_ALIASES INSERT statements based on the approved plan.

3. **View Generator** (`generate_views.py`) — Produces convenience views (one per entity), relationship views (one per relationship), and abstract views (cross-entity unions) as CREATE VIEW DDL.

4. **Semantic View Generator** (`generate_semantic_view.py`) — Produces CREATE SEMANTIC VIEW DDL with proper TABLES, RELATIONSHIPS, FACTS, DIMENSIONS, METRICS clauses, AI_SQL_GENERATION, and AI_QUESTION_CATEGORIZATION instructions.

5. **Agent Generator** (`generate_agent.py`) — Produces CREATE AGENT FROM SPECIFICATION DDL with tool definitions, routing instructions, and sample questions.

6. **KG Generator** (`generate_kg.py`, optional) — Produces KG_NODE/KG_EDGE table DDL, data-loading INSERT...SELECT statements, bidirectional edge view, and traversal stored procedures. Only invoked if config.yaml specifies `path: kg` or `path: both`.

7. **Ontology Validator** (`validate_ontology.py`) — Cross-checks generated SQL: all entities map to source tables, all relationships reference valid entities, SQL compiles, semantic view covers all business questions.

---

## Success Criteria

- [ ] Every source table in `inputs/source_ddl.sql` is classified and mapped to at least one ontology entity
- [ ] All generated SQL compiles against Snowflake (`only_compile=true`)
- [ ] ONT_ENTITY_TYPES covers all identified entities with descriptions
- [ ] ONT_RELATIONSHIP_TYPES covers all detected relationships with cardinality
- [ ] Semantic view has at least one metric per business question category
- [ ] Agent spec routes questions to the correct tool
- [ ] All business terms from `inputs/business_glossary.yaml` appear as aliases or synonyms
- [ ] If KG path is selected: KG_NODE count matches source entity count, KG_EDGE covers all relationships
- [ ] Deployment manifest lists scripts in correct execution order

---

## Constraints

- Output DDL must be Snowflake-compatible (tested with `only_compile=true`)
- Semantic view must not exceed 50 columns (Cortex Analyst practical limit)
- All scripts must be idempotent (use CREATE OR REPLACE)
- No hardcoded values in generator scripts — all configuration comes from `plans/` and `inputs/config.yaml`
- Scripts must handle domains from 3 tables to 50+ tables
- Generated SQL uses fully qualified object names (`DATABASE.SCHEMA.OBJECT`)
- No external Python dependencies beyond PyYAML and pathlib (standard library)

---

## Out of Scope

- Deploying generated SQL to production (scripts produce files only; deployment is a manual step)
- SPCS/NetworkX container setup (advanced graph algorithms)
- Identity resolution / entity matching across systems
- Data quality profiling (DQ is separate from ontology design)
- Streaming/real-time KG updates

---

## Snowflake Configuration

| Setting | Value |
|---------|-------|
| Target database | Specified in `inputs/config.yaml` |
| Target schema | Specified in `inputs/config.yaml` |
| Warehouse | `SF_SANDBOX_WH` (for compilation testing) |
| Validate DDL? | Yes (`only_compile=true`) |
| Execute DDL? | No (scripts produce files; user deploys manually) |
