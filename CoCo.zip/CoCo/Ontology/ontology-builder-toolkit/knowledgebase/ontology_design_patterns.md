# Ontology Design Patterns

## Entity Classification Rules

When profiling source tables, classify each table using these rules:

### Entity Tables (become ONT_ENTITY_TYPES)
- Has a single-column primary key (e.g., CUSTOMER_ID, PRODUCT_ID)
- Contains descriptive attributes (name, type, status, dates)
- Typically has 10+ columns
- Row count represents distinct business objects
- Examples: CUSTOMERS, PRODUCTS, ACCOUNTS, EMPLOYEES, BRANCHES

### Relationship/Junction Tables (become ONT_RELATIONSHIP_TYPES)
- Has two or more foreign key columns as composite key
- Primarily connects two entity tables
- May have additional attributes on the relationship (dates, amounts, status)
- Examples: ORDER_ITEMS (Order × Product), ACCOUNT_HOLDINGS (Account × Instrument)

### Lookup/Reference Tables (become ONT_HIERARCHIES or dimensions)
- Low row count (<100 rows typically)
- Contains codes and descriptions
- Used for classification/categorization
- Examples: STATUS_CODES, REGIONS, CATEGORIES, TIERS

### Transaction/Event Tables (become entities with temporal dimension)
- Has a timestamp/date column
- High row count, growing over time
- Each row represents an event, not a persistent entity
- Examples: TRANSACTIONS, LOG_ENTRIES, ORDERS, SHIPMENTS

---

## Relationship Naming Conventions

| Pattern | Verb | Example |
|---------|------|---------|
| Parent owns child | `owns` | Customer owns Account |
| Container holds item | `holds` | Account holds Instrument |
| Entity located at place | `located_at` / `transacts_at` | Customer transacts_at Branch |
| Entity reports to entity | `reports_to` | Employee reports_to Manager |
| Entity supplies entity | `supplies` | Supplier supplies Material |
| Transfer between same type | `transfers_to` | Account transfers_to Account |
| Person-to-person | Use specific verb | `spouse_of`, `parent_of`, `beneficiary_of` |

### Rules:
- Always `snake_case`
- Always define an `INVERSE_NAME` (e.g., owns → owned_by)
- Use active voice for the forward direction
- Cardinality: `one-to-one`, `one-to-many`, `many-to-many`
- Mark `IS_TEMPORAL = TRUE` if the relationship has start/end dates

---

## Hierarchy Design Patterns

A hierarchy is a classification tree where each entity can be grouped at multiple levels.

### How to Identify Hierarchies
- Look for columns that classify the same entity at different granularities
- Example: REGION > STATE > CITY > BRANCH (geographic hierarchy for Branch entity)
- Example: ASSET_CLASS > CATEGORY > SUB_CATEGORY > INSTRUMENT (instrument taxonomy)

### Rules:
- Level 1 is always the broadest (top of tree)
- Level N (deepest) is typically the entity itself or its most specific classification
- Not all branches reach the same depth (ragged hierarchies are ok)
- Each hierarchy belongs to one entity type

### Common Hierarchy Patterns:
| Domain | Hierarchy | Levels |
|--------|-----------|--------|
| Finance | Instrument taxonomy | Asset Class > Category > Sub-Category > Security |
| Finance | Customer tier | Tier > Sub-Tier > Customer Type |
| Supply Chain | Product category | Division > Category > Sub-Category > SKU |
| Supply Chain | Geography | Region > Country > State > City > Site |
| Healthcare | Organization | System > Hospital > Department > Unit |
| HR | Org structure | Division > Department > Team > Role |

---

## Alias Mapping Patterns

Aliases map business vocabulary to canonical ontology terms.

### Categories of Aliases:
1. **Entity synonyms**: "client" = Customer, "vendor" = Supplier
2. **Contextual aliases**: "portfolio" = Account (when account_type = 'Brokerage')
3. **Abbreviations**: "PB" = "Private Banking", "HNW" = "High Net Worth"
4. **Role-based terms**: "security" = Instrument, "stock" = Instrument (when asset_class = 'Equity')
5. **Metric aliases**: "AUM" = "assets under management" (sum of balances + holdings)

### Rules:
- Every alias must map to exactly one canonical entity/relationship/concept
- Include the CONTEXT column to disambiguate (e.g., "fund" = Instrument when asset_class IN ('Mutual Fund', 'ETF'))
- Source aliases from: business glossary, user interviews, existing reports/dashboards

---

## Abstract Entity Design

Abstract entities group concrete entities for cross-type reasoning.

### When to Create Abstract Entities:
- Two or more concrete entities share the same attributes or represent the same business concept at a higher level
- Users ask questions that span multiple concrete types (e.g., "show all financial entities" meaning both customers and counterparties)

### Pattern:
```sql
CREATE VIEW VW_ONT_{ABSTRACT_NAME} AS
SELECT id, name, 'ConcreteType1' AS entity_class, shared_attr1, shared_attr2
FROM source_1
UNION ALL
SELECT id, name, 'ConcreteType2' AS entity_class, shared_attr1, shared_attr2
FROM source_2;
```

### Examples:
- `VW_ONT_FINANCIAL_ENTITY` = Customer UNION Supplier UNION Counterparty
- `VW_ONT_FINANCIAL_ASSET` = Account UNION Instrument
- `VW_ONT_LOCATION` = Branch UNION Warehouse UNION Office
