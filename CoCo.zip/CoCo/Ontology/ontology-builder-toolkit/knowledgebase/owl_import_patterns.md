# OWL Import Patterns

## Overview

When a client provides a formal ontology file (built in Protege, or an industry standard like
FIBO/SNOMED/GS1), the `parse_owl.py` script extracts structured information and maps it to
the toolkit's ontology design format.

## Supported File Formats

| Extension | Format | Common Source |
|-----------|--------|---------------|
| `.owl` | RDF/XML | Protege default export |
| `.rdf` | RDF/XML | Generic RDF tools |
| `.ttl` | Turtle | Compact human-readable RDF |
| `.n3` | Notation3 | Extended Turtle |
| `.nt` | N-Triples | Line-based RDF |

## OWL → Ontology Toolkit Mapping

### Classes → Entity Types

| OWL Construct | Toolkit Mapping | Notes |
|---------------|-----------------|-------|
| `owl:Class` | ONT_ENTITY_TYPES row | One entity type per class |
| `rdfs:subClassOf` | PARENT_ENTITY column | Inheritance chain |
| Class with subclasses but no instances | IS_ABSTRACT = TRUE | Abstract parent type |
| `rdfs:label` | ENTITY_NAME | Canonical name |
| `rdfs:comment` | DESCRIPTION | What it represents |

### Object Properties → Relationship Types

| OWL Construct | Toolkit Mapping | Notes |
|---------------|-----------------|-------|
| `owl:ObjectProperty` | ONT_RELATIONSHIP_TYPES row | One relationship per property |
| `rdfs:domain` | FROM_ENTITY | Source of the relationship |
| `rdfs:range` | TO_ENTITY | Target of the relationship |
| `owl:inverseOf` | INVERSE_NAME | Reverse relationship |
| `owl:FunctionalProperty` | CARDINALITY = 'many-to-one' | Functional = single-valued |
| `owl:InverseFunctionalProperty` | (with Functional) = 'one-to-one' | Both = bijection |
| `owl:TransitiveProperty` | IS_TEMPORAL or hierarchy flag | Triggers KG traversal design |
| `owl:SymmetricProperty` | INVERSE_NAME = same name | e.g., "spouse_of" |

### Datatype Properties → View Columns

| OWL Construct | Toolkit Mapping | Notes |
|---------------|-----------------|-------|
| `owl:DatatypeProperty` | Column in V_* view | Attribute on an entity |
| `rdfs:domain` | Which entity/view it belongs to | Maps to source table column |
| `rdfs:range` (XSD type) | Snowflake data type | See type mapping below |

### XSD → Snowflake Type Mapping

| XSD Type | Snowflake Type |
|----------|---------------|
| `xsd:string` | STRING |
| `xsd:integer` / `xsd:int` | INT |
| `xsd:long` | BIGINT |
| `xsd:float` | FLOAT |
| `xsd:double` | DOUBLE |
| `xsd:decimal` | DECIMAL |
| `xsd:boolean` | BOOLEAN |
| `xsd:date` | DATE |
| `xsd:dateTime` | TIMESTAMP_NTZ |
| `xsd:time` | TIME |

### Labels & Annotations → Aliases

| OWL Construct | Toolkit Mapping |
|---------------|-----------------|
| `skos:altLabel` | ONT_ALIASES row |
| Multiple `rdfs:label` (different languages) | ONT_ALIASES (context = language) |
| `skos:prefLabel` | Primary canonical name |
| `skos:definition` | DESCRIPTION |

## The Merge Problem: OWL + Schema

An OWL file defines **what things mean** but not **where they're stored**. The planning
phase must align both:

```
OWL Analysis (what)          Schema Analysis (where)
─────────────────            ──────────────────────
Class: Customer              Table: CUSTOMERS (11 cols)
Class: Account               Table: ACCOUNTS (8 cols)
Property: owns               FK: ACCOUNTS.CUSTOMER_ID → CUSTOMERS
Property: hasBalance         Column: ACCOUNTS.BALANCE
```

### Merge Rules for Planning Phase:

1. **Every OWL class should map to a source table** — if no table matches, flag as a gap
2. **Every source table should map to an OWL class** — unmapped tables may be lookups or events
3. **OWL properties override inferred relationships** — if OWL says "owns", use that verb even if the FK pattern suggests "belongs_to"
4. **OWL descriptions override inferred descriptions** — formal definitions are authoritative
5. **Unmapped OWL classes become abstract entities** — they exist for reasoning but have no physical table

## Common Industry Ontologies

| Domain | Ontology | Key Concepts | Where to Get It |
|--------|----------|-------------|-----------------|
| Finance | FIBO | Instruments, Contracts, Parties, Regulations | https://spec.edmcouncil.org/fibo/ |
| Healthcare | SNOMED CT | Clinical terms, anatomy, diseases | https://www.snomed.org/ |
| Supply Chain | GS1 | Products, packaging, locations | https://www.gs1.org/ |
| Life Sciences | Gene Ontology | Genes, pathways, biological processes | http://geneontology.org/ |
| General | Schema.org | Organizations, events, products | https://schema.org/ |

## Usage in the Toolkit

```bash
# 1. Place OWL file in inputs/
cp my_domain_ontology.owl inputs/

# 2. Also generate DDL inputs (for physical mapping)
python scripts/generate_inputs_from_schema.py --database DB --schema SCHEMA

# 3. Parse the OWL (produces research/owl_analysis.yaml)
python scripts/parse_owl.py

# 4. The planning phase merges owl_analysis.yaml + schema_analysis.yaml
#    into a unified MASTER_PLAN.yaml
```
