# Decision Framework: Lightweight vs Full Knowledge Graph

## The Core Question

> Does the client need to answer questions that require **multi-hop relationship traversal**?

If YES → Phase B (Full KG) is needed.
If NO → Phase A (Lightweight) is sufficient.

---

## Phase A: Lightweight Ontology (Default)

### Use When:
- Primary use case is analytics/reporting (aggregations, filters, rankings)
- Data relationships are simple (star/snowflake schema with direct JOINs)
- No requirement for "how are X and Y connected?" questions
- Speed to value is the priority
- Client data is already well-modeled
- Budget/timeline is constrained

### What It Provides:
- Ontology metadata tables (declarative business definitions)
- Convenience/abstract views (clean query interface)
- Semantic view for Cortex Analyst (natural language → SQL)
- Cortex Agent (orchestrates questions)

### What It Cannot Do:
- Multi-hop traversal ("how are these two entities connected?")
- Impact/blast radius analysis ("what's affected if X fails?")
- Network analysis (centrality, community detection, clustering)
- Arbitrary-depth hierarchy expansion beyond simple parent-child

---

## Phase B: Full Knowledge Graph (Add-on)

### Use When (any of these signals):
- Domain is relationship-heavy (supply chain, fraud, patient journeys, org charts)
- Users ask "how are things connected?" or "what's the path between X and Y?"
- Impact/risk analysis is required ("what breaks if this supplier goes down?")
- Identity resolution is needed (same entity in multiple source systems)
- Hierarchy expansion beyond simple parent-child (transitive closure at arbitrary depth)
- Network analysis matters (most-connected entities, communities, influence)

### What It Adds (on top of Phase A):
- KG_NODE + KG_EDGE universal graph tables
- Bidirectional edge view for traversal
- FIND_PATH stored procedure (recursive CTE path finding)
- GET_CONNECTED_ENTITIES procedure (neighborhood expansion)
- GET_BLAST_RADIUS procedure (impact analysis)
- KG-specific semantic view for graph structure queries

### Trade-offs:
| Dimension | Phase A | Phase B |
|-----------|---------|---------|
| Data duplication | None | Yes (KG tables copy entity data) |
| Maintenance | Low | Medium (KG must be refreshed when source changes) |
| Query types | Aggregation, filter, rank | + Path finding, blast radius, neighborhoods |
| Performance | Fast (standard SQL) | Varies (recursive CTEs can be expensive) |
| Complexity | Low | Medium-high |

---

## Decision Matrix

```
                      Relationship Complexity
                  Low                        High
              ┌────────────────────┬────────────────────┐
  High        │  Phase A           │  Phase A + B       │
  Analytics   │  (Semantic View    │  (Full KG +        │
  Demand      │   handles it)      │   Semantic View)   │
              ├────────────────────┼────────────────────┤
  Low         │  Phase A           │  Phase B only if   │
  Analytics   │  (sufficient)      │  traversal needed  │
  Demand      │                    │                    │
              └────────────────────┴────────────────────┘
```

---

## Red Flags That Indicate KG Is Needed

1. Client uses phrases like "trace the connection" or "follow the chain"
2. Compliance requires showing all related entities (AML, KYC)
3. Supply chain resilience analysis (supplier dependency mapping)
4. Fraud detection patterns (ring detection, unusual connections)
5. Organizational influence mapping (who reports to whom, N levels deep)
6. Patent/citation networks (what references what, transitively)

---

## Implementation Guidance for config.yaml

```yaml
# inputs/config.yaml
ontology:
  path: "lightweight"   # Options: lightweight, kg, both
  # If "both": Phase A is deployed first, Phase B adds KG on top
  # If "lightweight": Only Phase A artifacts generated
  # If "kg": Both Phase A AND Phase B (KG requires Phase A as foundation)
```

Phase B is ALWAYS additive — it never replaces Phase A. The semantic view handles 80% of questions; the KG handles the remaining 20% that require traversal.
