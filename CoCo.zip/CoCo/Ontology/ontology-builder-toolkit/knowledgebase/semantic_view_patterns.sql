-- Semantic View DDL Patterns
-- Reference examples for the generate_semantic_view.py script.
-- Source: Snowflake documentation for CREATE SEMANTIC VIEW

-- =============================================================================
-- PATTERN 1: Basic semantic view with tables, relationships, dimensions, metrics
-- =============================================================================

CREATE OR REPLACE SEMANTIC VIEW {DATABASE}.{SCHEMA}.{ONTOLOGY_NAME}_SEMANTIC_VIEW

  TABLES (
    {entity_alias} AS {DATABASE}.{SCHEMA}.{VIEW_NAME}
      PRIMARY KEY ({pk_column})
      WITH SYNONYMS ('{synonym1}', '{synonym2}')
      COMMENT = '{description of what this entity represents}'
    -- Repeat for each logical table
  )

  RELATIONSHIPS (
    {relationship_name} AS
      {child_table_alias} ({fk_column}) REFERENCES {parent_table_alias}
    -- Repeat for each relationship
  )

  FACTS (
    {table_alias}.{fact_name} AS {column_or_expression}
      COMMENT = '{what this measures}'
    -- Repeat for each fact
  )

  DIMENSIONS (
    {table_alias}.{dim_name} AS {column_or_expression}
      WITH SYNONYMS = ('{synonym}')
      COMMENT = '{what this categorizes}'
    -- Repeat for each dimension
  )

  METRICS (
    {table_alias}.{metric_name} AS {AGG_FUNCTION}({fact_or_column})
      COMMENT = '{business meaning}'
    -- Repeat for each metric
  )

  COMMENT = '{overall semantic view description}'

  AI_SQL_GENERATION '{instructions for SQL generation behavior}'

  AI_QUESTION_CATEGORIZATION '{instructions for question routing/rejection}';


-- =============================================================================
-- PATTERN 2: Key rules for semantic view design
-- =============================================================================

-- RULE: Practical limit of ~50 columns across all tables
-- RULE: Every table needs a PRIMARY KEY
-- RULE: RELATIONSHIPS define how tables JOIN (foreign key references)
-- RULE: FACTS are raw values/expressions (not aggregated)
-- RULE: DIMENSIONS are categorical/temporal columns for grouping
-- RULE: METRICS are aggregated expressions (SUM, AVG, COUNT, etc.)
-- RULE: AI_SQL_GENERATION guides Cortex Analyst behavior (ordering, rounding, disambiguation)
-- RULE: AI_QUESTION_CATEGORIZATION rejects out-of-scope questions
-- RULE: Synonyms on tables and dimensions improve natural language matching
-- RULE: COMMENT on every object improves Cortex Analyst accuracy significantly

-- =============================================================================
-- PATTERN 3: Derived metrics (cross-table calculations)
-- =============================================================================

-- Derived metrics are NOT scoped to a table. They combine metrics from multiple tables:
-- METRICS (
--   table_a.metric_1 AS SUM(table_a.value),
--   table_b.metric_2 AS SUM(table_b.value),
--   combined_total AS table_a.metric_1 + table_b.metric_2
-- )

-- =============================================================================
-- PATTERN 4: AI instructions best practices
-- =============================================================================

-- AI_SQL_GENERATION examples:
--   'Round all monetary values to 2 decimal places.'
--   'When grouping by tier, order as: Ultra HNW, Private Banking, Premium, Standard.'
--   'When asked about total assets or AUM, sum account balances plus holdings market value.'
--   'Always include a date filter when querying transactions unless the user explicitly says all time.'

-- AI_QUESTION_CATEGORIZATION examples:
--   'This view covers financial services data. Reject questions about weather, sports, or general knowledge.'
--   'If the user asks about a specific customer without providing a name or ID, ask them to clarify.'
--   'Reject questions that would require real-time market data not available in this dataset.'
