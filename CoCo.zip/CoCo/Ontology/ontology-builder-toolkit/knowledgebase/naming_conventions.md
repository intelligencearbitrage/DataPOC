# Naming Conventions for Generated Ontology Objects

## General Rules
- All Snowflake objects use UPPER_CASE (Snowflake default)
- Python scripts use snake_case
- YAML keys use snake_case
- Entity type names in metadata use PascalCase (e.g., "Customer", "FinancialEntity")
- Relationship names in metadata use snake_case (e.g., "owns", "transfers_to")

## Object Naming Patterns

### Ontology Metadata Tables
```
{SCHEMA}.ONT_ENTITY_TYPES
{SCHEMA}.ONT_RELATIONSHIP_TYPES
{SCHEMA}.ONT_HIERARCHIES
{SCHEMA}.ONT_ALIASES
```

### Convenience Views (one per concrete entity)
```
{SCHEMA}.V_{ENTITY_NAME}
```
Examples: `V_CUSTOMER`, `V_ACCOUNT`, `V_INSTRUMENT`, `V_BRANCH`

### Relationship Views (one per relationship type)
```
{SCHEMA}.V_{RELATIONSHIP_NAME}
```
Examples: `V_OWNS`, `V_HOLDS`, `V_TRANSFERS_TO`

### Abstract Views (cross-entity unions)
```
{SCHEMA}.VW_ONT_{ABSTRACT_ENTITY_NAME}
```
Examples: `VW_ONT_FINANCIAL_ENTITY`, `VW_ONT_FINANCIAL_ASSET`, `VW_ONT_LOCATION`

### Knowledge Graph Tables
```
{SCHEMA}.KG_NODE
{SCHEMA}.KG_EDGE
{SCHEMA}.V_KG_EDGE_BIDIR
```

### KG Node IDs
```
{ENTITY_TYPE_ABBREVIATION}-{source_primary_key}
```
Examples: `CUST-42`, `ACCT-677`, `INST-5`, `BRANCH-12`

Abbreviation rules:
- Use first 4-6 characters of entity name
- Must be unique across all entity types
- Common abbreviations: CUST, ACCT, INST, BRANCH, PROD, ORDER, SUPP

### Semantic Views
```
{SCHEMA}.{ONTOLOGY_NAME}_SEMANTIC_VIEW       (Phase A base)
{SCHEMA}.{ONTOLOGY_NAME}_KG_SEMANTIC_VIEW    (Phase B graph)
```

### Cortex Agents
```
{SCHEMA}.{ONTOLOGY_NAME}_AGENT               (Phase A)
{SCHEMA}.{ONTOLOGY_NAME}_AGENT_KG            (Phase B)
```

### Stored Procedures (KG traversal)
```
{SCHEMA}.FIND_PATH(source_node_id, target_node_id, max_hops)
{SCHEMA}.GET_CONNECTED_ENTITIES(start_node_id, max_hops, edge_type_filter)
{SCHEMA}.GET_BLAST_RADIUS(start_node_id, max_hops)
```

## Script Naming (in scripts/ directory)
```
parse_schema.py          — Schema profiler
generate_ontology_metadata.py  — ONT_* tables
generate_views.py        — V_* and VW_ONT_* views
generate_semantic_view.py — Semantic view DDL
generate_agent.py        — Agent DDL
generate_kg.py           — KG tables + procedures (optional)
validate_ontology.py     — Cross-check validator
```

## Output File Naming (in output/ directory)
```
00_create_schema.sql
01_ontology_metadata.sql
02_convenience_views.sql
03_semantic_view.sql
04_cortex_agent.sql
05_kg_tables.sql         (optional, Phase B)
06_kg_procedures.sql     (optional, Phase B)
deployment_manifest.yaml
```
The numeric prefix ensures correct execution order.
