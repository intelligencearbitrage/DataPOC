# Schema Introspection Reference

## Overview

The `generate_inputs_from_schema.py` script connects to a live Snowflake schema and
auto-generates toolkit input files. This document explains what it does, what it infers,
and what it cannot infer (requiring human input).

## What Gets Auto-Generated

| Output File | Completeness | What's Automated | What Needs Human Review |
|-------------|-------------|------------------|------------------------|
| `source_ddl.sql` | 100% | Exact DDL via `GET_DDL()` | Nothing — verbatim from Snowflake |
| `config.yaml` | 80% | Database, schema, warehouse, ontology name | `path` choice (lightweight vs KG) |
| `business_glossary.yaml` | 40% | Table/column comments, inferred entity names | Real business synonyms, domain abbreviations |
| `business_questions.yaml` | 20% | Template questions from column analysis | Actual user questions from interviews |

## Snowflake Commands Used

| Command | What It Provides |
|---------|-----------------|
| `SHOW TABLES IN schema` | Table list with row counts and comments |
| `GET_DDL('TABLE', name)` | Complete CREATE TABLE statement |
| `INFORMATION_SCHEMA.COLUMNS` | Column names, types, nullability, comments |
| `SHOW PRIMARY KEYS IN table` | Declared primary keys |
| `SHOW IMPORTED KEYS IN table` | Declared foreign keys |
| `APPROX_COUNT_DISTINCT(col)` | Column cardinality (for hierarchy detection) |

## Inference Rules

### Table Classification

| Rule | Classification | Confidence |
|------|---------------|-----------|
| Row count < 50 AND column count ≤ 4 | Lookup | 90% |
| ≥2 FK columns AND column count ≤ FK count + 4 | Relationship/Junction | 85% |
| Column count ≥ 5 | Entity | 85% |
| Everything else | Lookup | 70% |

### Foreign Key Detection (When Not Declared)

1. Column ends with `_ID` or `_KEY` AND is not the primary key
2. Check if column name prefix matches a known table name (e.g., `CUSTOMER_ID` → CUSTOMERS)
3. If match found → inferred FK with `inferred: true` flag

**False positive risk:** ~25%. A column called `ORDER_ID` in a SHIPMENTS table might be a FK, or might be a shipment's own order reference that doesn't point to an ORDERS table.

### Hierarchy Detection

A column is a hierarchy candidate when:
1. Its name contains a hierarchy keyword: TYPE, CATEGORY, CLASS, TIER, LEVEL, REGION, SECTOR, GROUP, DIVISION, STATUS, SEGMENT
2. Its cardinality is < 30% of the table's row count (low cardinality = classification)

Multiple hierarchy candidates on the same table suggest a multi-level hierarchy.

### Entity Name Inference

Table name → PascalCase singular:
- `CUSTOMERS` → `Customer`
- `ACCOUNT_HOLDINGS` → `AccountHolding`
- `CATEGORIES` → `Category`

Rules: Strip trailing S/ES/IES, split on `_`, capitalize each part.

## Command-Line Usage

```bash
# Basic — introspect a schema with defaults
python scripts/generate_inputs_from_schema.py --database COCO_RD --schema FINSERV_ONTOLOGY

# Full options
python scripts/generate_inputs_from_schema.py \
  --database COCO_RD \
  --schema FINSERV_ONTOLOGY \
  --connection my_conn \
  --ontology-name FINSERV \
  --path both \
  --output-dir inputs/

# Using a different connection
python scripts/generate_inputs_from_schema.py --database CLIENT_DB --schema RAW --connection client_prod
```

## Prerequisites

```bash
pip install snowflake-connector-python pyyaml
```

Must have a Snowflake connection configured in `~/.snowflake/connections.toml` or `~/.snowflake/config.toml`.

## Output Example

After running against a 7-table schema:

```
Connecting to Snowflake...
Connected. Introspecting COCO_RD.FINSERV_ONTOLOGY...
  Found 7 tables
  Classified: 7 entities, 0 relationships, 0 lookups

Generating inputs in inputs/...
  Created: inputs/source_ddl.sql (7 tables)
  Created: inputs/config.yaml (path=both)
  Created: inputs/business_glossary.yaml (7 terms, DRAFT)
  Created: inputs/business_questions.yaml (15 questions, TEMPLATE)

Done! Generated 4 input files in inputs/

Next steps:
  1. Review inputs/config.yaml — confirm path choice (currently: both)
  2. Review inputs/business_glossary.yaml — add real synonyms from SME interviews
  3. Review inputs/business_questions.yaml — replace templates with actual user questions
  4. Run the pipeline: open in CoCo and say 'start project'
```
